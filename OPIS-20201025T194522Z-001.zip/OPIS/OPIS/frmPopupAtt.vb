﻿Public Class frmPopupAtt

    Private dt1, dt2 As DataTable

    Private Sub frmPopupAtt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Public Sub New(ByVal strFrom As String, ByVal strTo As String, ByVal strStatus As String, ByVal strDeploy As String, ByVal dtStatus As DataTable, ByVal dtDeploy As DataTable)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        dt1 = dtStatus
        dt2 = dtDeploy

        Me.cbo1.DataSource = dt1
        Me.cbo1.DisplayMember = "expr1"
        Me.cbo1.ValueMember = "expr1"

        Me.cbo2.DataSource = dt2
        Me.cbo2.DisplayMember = "expr1"
        Me.cbo2.ValueMember = "expr1"

        Label1.Text = strFrom
        Label2.Text = strTo
        Label3.Text = strStatus
        Label4.Text = strDeploy

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If System.DateTime.Compare(NumericUpDown1.Value & ":" & NumericUpDown3.Value, NumericUpDown2.Value & ":" & NumericUpDown4.Value) = 1 Then
            MsgBox("ERROR : Duty timings are invalid as starting time is greater than ending time!", MsgBoxStyle.OkOnly)
            Me.DialogResult = Windows.Forms.DialogResult.Cancel
            Exit Sub
        Else
            Me.DialogResult = Windows.Forms.DialogResult.OK
        End If
        CType(Owner, frmAttendance).strfrom = NumericUpDown1.Value & ":" & NumericUpDown3.Value & ":0"
        CType(Owner, frmAttendance).strto = NumericUpDown2.Value & ":" & NumericUpDown4.Value & ":0"
        CType(Owner, frmAttendance).strstatus = Me.cbo1.SelectedValue
        CType(Owner, frmAttendance).strdeploy = Me.cbo2.SelectedValue
        'Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

    End Sub

    Private Sub cbo1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbo1.SelectedIndexChanged
        If System.String.Compare(cbo1.SelectedValue, "1P:Duty:Yes") = 1 Then
            NumericUpDown1.Value = 0
            NumericUpDown2.Value = 0
            NumericUpDown3.Value = 0
            NumericUpDown4.Value = 0
            NumericUpDown1.Enabled = False
            NumericUpDown2.Enabled = False
            NumericUpDown3.Enabled = False
            NumericUpDown4.Enabled = False
        Else
            NumericUpDown1.Enabled = True
            NumericUpDown2.Enabled = True
            NumericUpDown3.Enabled = True
            NumericUpDown4.Enabled = True
        End If
    End Sub
End Class