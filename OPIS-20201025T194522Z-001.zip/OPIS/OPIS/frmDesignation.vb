﻿Imports System.Data.SqlClient
Imports System.IO

Public Class frmDesignation

    Private dtbrowse, dtbrowsedetail As DataTable
    Private dbms As DML
    Private Ind As Integer


    Private Sub frmDesignation_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            dbms = New DML()
            dtbrowse = dbms.getDataTable("Select  DesigID+' --- '+Description as Expr1,DesigId, Description, Billable,DutyHoursinDay from dbo.tblDesignation")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("DesigId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing
        Ind = -1

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "DesigId"

        gbxEmployee.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"

    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow

        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtDesigId.Text = dr("DesigId")
                Me.txtDesc.Text = "" & dr("Description")
                Me.cboBillable.Text = "" & dr("Billable")
                Me.cboDutyHrs.Text = "" & dr("DutyHoursinDay")
                dtbrowsedetail = dbms.getDataTable("Select SalaryBreakUpId,DesigId, Description, Amount, BreakUpStatus from tblSalaryBreakUp Where DesigId='" & cboBrowse.SelectedValue & "'")

                dgvSalaryBreakUp.DataSource = dtbrowsedetail
                dgvSalaryBreakUp.ReadOnly = True
                Me.gbxEmployee.Enabled = True
                Me.txtDesigId.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgvSalaryBreakUp_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvSalaryBreakUp.CellClick
        Ind = e.RowIndex
    End Sub



    Private Sub dgvSalaryBreakUp_CellMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvSalaryBreakUp.CellMouseDoubleClick

        Ind = e.RowIndex
        Me.txtSDesc.Text = dtbrowsedetail.Rows(e.RowIndex)(2)
        Me.txtAmount.Text = dtbrowsedetail.Rows(e.RowIndex)(3)
        Me.cboStatus.Text = dtbrowsedetail.Rows(e.RowIndex)(4)

    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If MsgBox("Please confirm to Edit Salary BreakUp?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then


                dtbrowsedetail.Rows(Ind)(2) = Me.txtSDesc.Text
                dtbrowsedetail.Rows(Ind)(3) = Me.txtAmount.Text
                dtbrowsedetail.Rows(Ind)(4) = Me.cboStatus.Text

                dbms.execSql("Update tblSalaryBreakUp Set Description='" & Me.txtSDesc.Text & "', Amount=" & Me.txtAmount.Text & ", BreakUpStatus='" & Me.cboStatus.Text & "' where SalaryBreakUpId='" & dtbrowsedetail.Rows(Ind)(0) & "' and DesigId='" & dtbrowsedetail.Rows(Ind)(1) & "'")

                'Refresh DataTable
                dtbrowsedetail = dbms.getDataTable("Select SalaryBreakUpId,DesigId, Description, Amount, BreakUpStatus from tblSalaryBreakUp Where DesigId='" & cboBrowse.SelectedValue & "'")
                dgvSalaryBreakUp.DataSource = dtbrowsedetail
                dgvSalaryBreakUp.ReadOnly = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtDesigId.Text = ""
                Me.txtDesc.Text = ""
                Me.cboBillable.Text = ""
                Me.txtSDesc.Text = ""
                Me.txtAmount.Text = ""
                Me.cboStatus.Text = ""
                Me.dtbrowsedetail = Nothing
                dgvSalaryBreakUp.DataSource = Nothing
                Me.gbxBrowse.Enabled = True
                Me.gbxEmployee.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("Update tblDesignation Set Description='" & Me.txtDesc.Text & "', Billable='" & Me.cboBillable.Text & "', DutyHoursinDay=" & cboDutyHrs.Text & " where DesigId='" & Me.txtDesigId.Text & "'")
                Else
                    dbms.execSql("Insert into tblDesignation (DesigId,Description,Billable,DutyHoursinDay) values ('" & Me.txtDesigId.Text & "','" & txtDesc.Text & "','" & cboBillable.Text & "'," & cboDutyHrs.Text & ")")
                End If
                Me.gbxBrowse.Enabled = True
                Me.gbxEmployee.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        frmDesignation_Load(Nothing, Nothing)
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Try
            If MsgBox("Please confirm to Save Salary BreakUp?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Dim SBUID As String
                SBUID = dbms.generateId("SalaryBreakUpId")
                dbms.execSql("Insert into tblSalaryBreakUp (SalaryBreakUpId,DesigId,Description,Amount,BreakUpStatus) Values ('" & SBUID & "','" & txtDesigId.Text & "','" & Me.txtSDesc.Text & "', " & Me.txtAmount.Text & ", '" & Me.cboStatus.Text & "')")
                'Refresh DataTable
                dtbrowsedetail = dbms.getDataTable("Select SalaryBreakUpId,DesigId, Description, Amount, BreakUpStatus from tblSalaryBreakUp Where DesigId='" & cboBrowse.SelectedValue & "'")
                dgvSalaryBreakUp.DataSource = dtbrowsedetail
                dgvSalaryBreakUp.ReadOnly = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("DesigId")
            Me.txtDesigId.Text = "" & SBUID
            Me.txtDesc.Text = ""
            Me.cboBillable.Text = ""
            dtbrowsedetail = dbms.getDataTable("Select SalaryBreakUpId,DesigId, Description, Amount, BreakUpStatus from tblSalaryBreakUp Where DesigId='" & txtDesigId.Text & "'")
            dgvSalaryBreakUp.DataSource = dtbrowsedetail
            dgvSalaryBreakUp.ReadOnly = True
            Me.gbxEmployee.Enabled = True
            Me.txtDesigId.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        Try
            If MsgBox("Please confirm to Delete Salary BreakUp?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If Ind < 0 Then
                    MsgBox("No Record is selected to delete in a Grid!")
                Else
                    dbms.execSql("Delete from tblSalaryBreakUp where SalaryBreakUpId='" & dtbrowsedetail.Rows(Ind)(0) & "'")
                    dtbrowsedetail = dbms.getDataTable("Select SalaryBreakUpId,DesigId, Description, Amount, BreakUpStatus from tblSalaryBreakUp Where DesigId='" & cboBrowse.SelectedValue & "'")
                    dgvSalaryBreakUp.DataSource = dtbrowsedetail
                    dgvSalaryBreakUp.ReadOnly = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub txtDesc_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDesc.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub txtSDesc_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSDesc.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub txtAmount_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtAmount.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
            e.Handled = True
        End If
    End Sub


    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub
End Class