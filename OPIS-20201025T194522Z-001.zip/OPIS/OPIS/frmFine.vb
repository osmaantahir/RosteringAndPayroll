﻿Public Class frmFine
    Private dtbrowse, dtEmp, dtemp1 As DataTable
    Private dbms As DML

    Private Sub frmFine_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' FineId, EmpId, DateOfFine, Remarks, ImposedBy

        Try
            dbms = New DML()
            Dim str As String

            str = "SELECT dbo.tblFines.FineId + ' : [' + dbo.tblEmployee.EmpId + '] ' + dbo.tblEmployee.FName + ' ' + dbo.tblEmployee.LName + ' : ' + dbo.tblFines.Remarks AS Expr1, "
            str = str & " dbo.tblFines.FineId, dbo.tblFines.EmpId, dbo.tblFines.DateOfFine, dbo.tblFines.Remarks, dbo.tblFines.ImposedBy, dbo.tblFines.FineAmount"
            str = str & " FROM dbo.tblFines INNER JOIN"
            str = str & " dbo.tblEmployee ON dbo.tblFines.EmpId = dbo.tblEmployee.EmpId"

            dtbrowse = dbms.getDataTable(str)
            dtEmp = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")
            dtemp1 = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")

            Me.cboEmp.DataSource = dtEmp
            Me.cboEmp.DisplayMember = "Expr1"
            Me.cboEmp.ValueMember = "EmpId"

            Me.cboImposed.DataSource = dtemp1
            Me.cboImposed.DisplayMember = "Expr1"
            Me.cboImposed.ValueMember = "EmpId"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("FineId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "FineId"

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow

        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtFineId.Text = "" & dr("FineId")
                Me.cboEmp.SelectedValue = "" & dr("EmpId")
                Me.dtpFineDate.Value = "" & dr("DateOfFine")
                Me.txtRemarks.Text = "" & dr("Remarks")
                Me.cboImposed.SelectedValue = "" & dr("ImposedBy")
                Me.txtFineAmount.Text = "" & dr("FineAmount")

                Me.gbxDetail.Enabled = True
                Me.txtFineId.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtFineId.Text = ""
                Me.cboEmp.SelectedValue = -1
                Me.dtpFineDate.Value = Today
                Me.txtRemarks.Text = ""
                Me.cboImposed.SelectedValue = -1
                Me.txtFineAmount.Text = "0"

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("LeaveId")
            Me.txtFineId.Text = "" & SBUID
            Me.cboEmp.SelectedValue = -1
            Me.dtpFineDate.Value = Today
            Me.txtRemarks.Text = ""
            Me.cboImposed.SelectedValue = -1

            Me.gbxDetail.Enabled = True
            Me.txtFineId.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("Update tblFines Set EmpId='" & Me.cboEmp.SelectedValue & "', DateOfFine='" & Me.dtpFineDate.Value & "',Remarks='" & Me.txtRemarks.Text & "',ImposedBy='" & Me.cboImposed.SelectedValue & "',FineAmount=" & txtFineAmount.Text & " where FineId='" & Me.txtFineId.Text & "'")
                Else
                    dbms.execSql("Insert into tblFines (FineId, EmpId, DateOfFine, Remarks, ImposedBy,FineAmount) values ('" & Me.txtFineId.Text & "','" & Me.cboEmp.SelectedValue & "','" & Me.dtpFineDate.Value & "','" & Me.txtRemarks.Text & "','" & Me.cboImposed.SelectedValue & "'," & txtFineAmount.Text & ")")
                End If
                Me.txtFineId.Text = ""
                Me.cboEmp.SelectedValue = -1
                Me.dtpFineDate.Value = Today
                Me.txtRemarks.Text = ""
                Me.cboImposed.SelectedValue = -1
                Me.txtFineAmount.Text = "0"

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        frmFine_Load(Nothing, Nothing)
    End Sub

    Private Sub txtRemarks_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRemarks.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtFineAmount_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFineAmount.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
            e.Handled = True
        End If
    End Sub

End Class