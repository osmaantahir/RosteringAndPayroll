﻿Public Class frmTransfer
    Private dtbrowse, dtEmp, dtOffice As DataTable
    Private dbms As DML
    Private Sub frmTransfer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            dbms = New DML()
            Dim str As String
            str = "SELECT dbo.tblTransfer.TransferId + ': [' + dbo.tblTransfer.EmpId + '] ' + dbo.tblEmployee.FName + ' ' + dbo.tblEmployee.LName + ' : ' + dbo.tblOffice.Description AS expr1, "
            str = str & " dbo.tblTransfer.TransferId, dbo.tblTransfer.EmpId, dbo.tblTransfer.OfficeId, dbo.tblTransfer.DateOfTransfer, dbo.tblTransfer.Remarks"
            str = str & " FROM dbo.tblTransfer INNER JOIN"
            str = str & " dbo.tblEmployee ON dbo.tblTransfer.EmpId = dbo.tblEmployee.EmpId INNER JOIN"
            str = str & " dbo.tblOffice ON dbo.tblTransfer.OfficeId = dbo.tblOffice.OfficeId"

            dtbrowse = dbms.getDataTable(str)
            dtEmp = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")
            dtOffice = dbms.getDataTable("Select '['+OfficeId+'] '+Description as Expr1, OfficeId from tblOffice")

            Me.cboEmp.DataSource = dtEmp
            Me.cboEmp.DisplayMember = "Expr1"
            Me.cboEmp.ValueMember = "EmpId"

            Me.cboOff.DataSource = dtOffice
            Me.cboOff.DisplayMember = "Expr1"
            Me.cboOff.ValueMember = "OfficeId"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("TransferId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "TransferId"

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow

        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtTransferId.Text = "" & dr("TransferId")
                Me.cboEmp.SelectedValue = "" & dr("EmpId")
                Me.cboOff.SelectedValue = "" & dr("OfficeId")
                Me.dtpDoT.Value = "" & dr("DateOfTransfer")
                Me.txtRemarks.Text = "" & dr("Remarks")

                Me.gbxDetail.Enabled = True
                Me.txtTransferId.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtTransferId.Text = ""
                Me.txtRemarks.Text = ""
                Me.dtpDoT.Text = Today

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("TransferId")
            Me.txtTransferId.Text = "" & SBUID
            Me.dtpDoT.Text = Today
            Me.txtRemarks.Text = ""

            Me.gbxDetail.Enabled = True
            Me.txtTransferId.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("Update tblTransfer Set EmpId='" & Me.cboEmp.SelectedValue & "', OfficeId='" & Me.cboOff.SelectedValue & "',DateOfTransfer='" & Me.dtpDoT.Value & "',Remarks='" & Me.txtRemarks.Text & "' where TransferId='" & Me.txtTransferId.Text & "'")
                Else
                    dbms.execSql("Insert into tblTransfer (TransferId,EmpId,OfficeId,DateOfTransfer,Remarks) values ('" & Me.txtTransferId.Text & "','" & Me.cboEmp.SelectedValue & "','" & Me.cboOff.SelectedValue & "','" & Me.dtpDoT.Value & "','" & Me.txtRemarks.Text & "')")
                End If
                Me.txtTransferId.Text = ""
                Me.txtRemarks.Text = ""
                Me.dtpDoT.Text = Today

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        frmTransfer_Load(Nothing, Nothing)
    End Sub

    Private Sub txtRemarks_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRemarks.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtRemarks_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRemarks.TextChanged

    End Sub
End Class