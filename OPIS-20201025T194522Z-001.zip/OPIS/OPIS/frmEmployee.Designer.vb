﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxEmployee = New System.Windows.Forms.GroupBox()
        Me.cboMarried = New System.Windows.Forms.ComboBox()
        Me.txtPhotoURL = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.cboBaseLoc = New System.Windows.Forms.ComboBox()
        Me.pboEmployee = New System.Windows.Forms.PictureBox()
        Me.dtpDoB = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblDoB = New System.Windows.Forms.Label()
        Me.lblBaseLocation = New System.Windows.Forms.Label()
        Me.lblCurrAdd = New System.Windows.Forms.Label()
        Me.lblPermAdd = New System.Windows.Forms.Label()
        Me.lblContacts = New System.Windows.Forms.Label()
        Me.lblNIC = New System.Windows.Forms.Label()
        Me.lblLName = New System.Windows.Forms.Label()
        Me.lblFName = New System.Windows.Forms.Label()
        Me.lblEmpId = New System.Windows.Forms.Label()
        Me.txtCurrAdd = New System.Windows.Forms.TextBox()
        Me.txtPermAdd = New System.Windows.Forms.TextBox()
        Me.txtContacts = New System.Windows.Forms.TextBox()
        Me.txtNIC = New System.Windows.Forms.TextBox()
        Me.txtLName = New System.Windows.Forms.TextBox()
        Me.txtFName = New System.Windows.Forms.TextBox()
        Me.txtEmpId = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.ofd = New System.Windows.Forms.OpenFileDialog()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.ssp.SuspendLayout()
        Me.gbxEmployee.SuspendLayout()
        CType(Me.pboEmployee, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbxBrowse.SuspendLayout()
        Me.SuspendLayout()
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 468)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(681, 22)
        Me.ssp.TabIndex = 4
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'gbxEmployee
        '
        Me.gbxEmployee.Controls.Add(Me.cboMarried)
        Me.gbxEmployee.Controls.Add(Me.txtPhotoURL)
        Me.gbxEmployee.Controls.Add(Me.Button1)
        Me.gbxEmployee.Controls.Add(Me.cboBaseLoc)
        Me.gbxEmployee.Controls.Add(Me.pboEmployee)
        Me.gbxEmployee.Controls.Add(Me.dtpDoB)
        Me.gbxEmployee.Controls.Add(Me.Label12)
        Me.gbxEmployee.Controls.Add(Me.Label11)
        Me.gbxEmployee.Controls.Add(Me.lblDoB)
        Me.gbxEmployee.Controls.Add(Me.lblBaseLocation)
        Me.gbxEmployee.Controls.Add(Me.lblCurrAdd)
        Me.gbxEmployee.Controls.Add(Me.lblPermAdd)
        Me.gbxEmployee.Controls.Add(Me.lblContacts)
        Me.gbxEmployee.Controls.Add(Me.lblNIC)
        Me.gbxEmployee.Controls.Add(Me.lblLName)
        Me.gbxEmployee.Controls.Add(Me.lblFName)
        Me.gbxEmployee.Controls.Add(Me.lblEmpId)
        Me.gbxEmployee.Controls.Add(Me.txtCurrAdd)
        Me.gbxEmployee.Controls.Add(Me.txtPermAdd)
        Me.gbxEmployee.Controls.Add(Me.txtContacts)
        Me.gbxEmployee.Controls.Add(Me.txtNIC)
        Me.gbxEmployee.Controls.Add(Me.txtLName)
        Me.gbxEmployee.Controls.Add(Me.txtFName)
        Me.gbxEmployee.Controls.Add(Me.txtEmpId)
        Me.gbxEmployee.Controls.Add(Me.cmdCancel)
        Me.gbxEmployee.Controls.Add(Me.cmdSave)
        Me.gbxEmployee.Location = New System.Drawing.Point(12, 79)
        Me.gbxEmployee.Name = "gbxEmployee"
        Me.gbxEmployee.Size = New System.Drawing.Size(657, 370)
        Me.gbxEmployee.TabIndex = 5
        Me.gbxEmployee.TabStop = False
        Me.gbxEmployee.Text = "Employee Details"
        '
        'cboMarried
        '
        Me.cboMarried.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMarried.FormattingEnabled = True
        Me.cboMarried.Items.AddRange(New Object() {"Single", "Married", "Divorced", ""})
        Me.cboMarried.Location = New System.Drawing.Point(115, 284)
        Me.cboMarried.Name = "cboMarried"
        Me.cboMarried.Size = New System.Drawing.Size(198, 21)
        Me.cboMarried.TabIndex = 9
        '
        'txtPhotoURL
        '
        Me.txtPhotoURL.Enabled = False
        Me.txtPhotoURL.Location = New System.Drawing.Point(369, 45)
        Me.txtPhotoURL.Name = "txtPhotoURL"
        Me.txtPhotoURL.Size = New System.Drawing.Size(262, 20)
        Me.txtPhotoURL.TabIndex = 29
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(524, 64)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(107, 35)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Browse Photo"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'cboBaseLoc
        '
        Me.cboBaseLoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBaseLoc.FormattingEnabled = True
        Me.cboBaseLoc.Items.AddRange(New Object() {"Karachi", "Lahore", "Islamabad", "RawalPindi", "Faisalabad", "Multan", "Gujranwala", "Sialkot", "Gujrat", "Quetta", "Peshawar", "Hydrabad", "Sheikhupura", ""})
        Me.cboBaseLoc.Location = New System.Drawing.Point(115, 231)
        Me.cboBaseLoc.Name = "cboBaseLoc"
        Me.cboBaseLoc.Size = New System.Drawing.Size(198, 21)
        Me.cboBaseLoc.TabIndex = 7
        '
        'pboEmployee
        '
        Me.pboEmployee.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pboEmployee.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pboEmployee.Location = New System.Drawing.Point(393, 105)
        Me.pboEmployee.Name = "pboEmployee"
        Me.pboEmployee.Size = New System.Drawing.Size(212, 206)
        Me.pboEmployee.TabIndex = 26
        Me.pboEmployee.TabStop = False
        '
        'dtpDoB
        '
        Me.dtpDoB.Location = New System.Drawing.Point(115, 258)
        Me.dtpDoB.Name = "dtpDoB"
        Me.dtpDoB.Size = New System.Drawing.Size(198, 20)
        Me.dtpDoB.TabIndex = 8
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(366, 29)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(35, 13)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "Photo"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(11, 290)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(42, 13)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Married"
        '
        'lblDoB
        '
        Me.lblDoB.AutoSize = True
        Me.lblDoB.Location = New System.Drawing.Point(11, 264)
        Me.lblDoB.Name = "lblDoB"
        Me.lblDoB.Size = New System.Drawing.Size(66, 13)
        Me.lblDoB.TabIndex = 21
        Me.lblDoB.Text = "Date of Birth"
        '
        'lblBaseLocation
        '
        Me.lblBaseLocation.AutoSize = True
        Me.lblBaseLocation.Location = New System.Drawing.Point(10, 234)
        Me.lblBaseLocation.Name = "lblBaseLocation"
        Me.lblBaseLocation.Size = New System.Drawing.Size(75, 13)
        Me.lblBaseLocation.TabIndex = 20
        Me.lblBaseLocation.Text = "Base Location"
        '
        'lblCurrAdd
        '
        Me.lblCurrAdd.AutoSize = True
        Me.lblCurrAdd.Location = New System.Drawing.Point(10, 208)
        Me.lblCurrAdd.Name = "lblCurrAdd"
        Me.lblCurrAdd.Size = New System.Drawing.Size(82, 13)
        Me.lblCurrAdd.TabIndex = 19
        Me.lblCurrAdd.Text = "Current Address"
        '
        'lblPermAdd
        '
        Me.lblPermAdd.AutoSize = True
        Me.lblPermAdd.Location = New System.Drawing.Point(10, 182)
        Me.lblPermAdd.Name = "lblPermAdd"
        Me.lblPermAdd.Size = New System.Drawing.Size(99, 13)
        Me.lblPermAdd.TabIndex = 18
        Me.lblPermAdd.Text = "Permanent Address"
        '
        'lblContacts
        '
        Me.lblContacts.AutoSize = True
        Me.lblContacts.Location = New System.Drawing.Point(10, 156)
        Me.lblContacts.Name = "lblContacts"
        Me.lblContacts.Size = New System.Drawing.Size(49, 13)
        Me.lblContacts.TabIndex = 17
        Me.lblContacts.Text = "Contacts"
        '
        'lblNIC
        '
        Me.lblNIC.AutoSize = True
        Me.lblNIC.Location = New System.Drawing.Point(10, 130)
        Me.lblNIC.Name = "lblNIC"
        Me.lblNIC.Size = New System.Drawing.Size(25, 13)
        Me.lblNIC.TabIndex = 16
        Me.lblNIC.Text = "NIC"
        '
        'lblLName
        '
        Me.lblLName.AutoSize = True
        Me.lblLName.Location = New System.Drawing.Point(10, 104)
        Me.lblLName.Name = "lblLName"
        Me.lblLName.Size = New System.Drawing.Size(58, 13)
        Me.lblLName.TabIndex = 15
        Me.lblLName.Text = "Last Name"
        '
        'lblFName
        '
        Me.lblFName.AutoSize = True
        Me.lblFName.Location = New System.Drawing.Point(10, 78)
        Me.lblFName.Name = "lblFName"
        Me.lblFName.Size = New System.Drawing.Size(57, 13)
        Me.lblFName.TabIndex = 14
        Me.lblFName.Text = "First Name"
        '
        'lblEmpId
        '
        Me.lblEmpId.AutoSize = True
        Me.lblEmpId.Location = New System.Drawing.Point(10, 52)
        Me.lblEmpId.Name = "lblEmpId"
        Me.lblEmpId.Size = New System.Drawing.Size(67, 13)
        Me.lblEmpId.TabIndex = 13
        Me.lblEmpId.Text = "Employee ID"
        '
        'txtCurrAdd
        '
        Me.txtCurrAdd.Location = New System.Drawing.Point(115, 201)
        Me.txtCurrAdd.MaxLength = 50
        Me.txtCurrAdd.Name = "txtCurrAdd"
        Me.txtCurrAdd.Size = New System.Drawing.Size(198, 20)
        Me.txtCurrAdd.TabIndex = 6
        '
        'txtPermAdd
        '
        Me.txtPermAdd.Location = New System.Drawing.Point(115, 175)
        Me.txtPermAdd.MaxLength = 50
        Me.txtPermAdd.Name = "txtPermAdd"
        Me.txtPermAdd.Size = New System.Drawing.Size(198, 20)
        Me.txtPermAdd.TabIndex = 5
        '
        'txtContacts
        '
        Me.txtContacts.Location = New System.Drawing.Point(115, 149)
        Me.txtContacts.MaxLength = 50
        Me.txtContacts.Name = "txtContacts"
        Me.txtContacts.Size = New System.Drawing.Size(198, 20)
        Me.txtContacts.TabIndex = 4
        '
        'txtNIC
        '
        Me.txtNIC.Location = New System.Drawing.Point(115, 123)
        Me.txtNIC.MaxLength = 50
        Me.txtNIC.Name = "txtNIC"
        Me.txtNIC.Size = New System.Drawing.Size(198, 20)
        Me.txtNIC.TabIndex = 3
        '
        'txtLName
        '
        Me.txtLName.Location = New System.Drawing.Point(115, 97)
        Me.txtLName.MaxLength = 50
        Me.txtLName.Name = "txtLName"
        Me.txtLName.Size = New System.Drawing.Size(198, 20)
        Me.txtLName.TabIndex = 2
        '
        'txtFName
        '
        Me.txtFName.Location = New System.Drawing.Point(115, 71)
        Me.txtFName.MaxLength = 50
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(198, 20)
        Me.txtFName.TabIndex = 1
        '
        'txtEmpId
        '
        Me.txtEmpId.Location = New System.Drawing.Point(115, 45)
        Me.txtEmpId.MaxLength = 50
        Me.txtEmpId.Name = "txtEmpId"
        Me.txtEmpId.Size = New System.Drawing.Size(198, 20)
        Me.txtEmpId.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(556, 330)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(95, 34)
        Me.cmdCancel.TabIndex = 12
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(462, 329)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(90, 35)
        Me.cmdSave.TabIndex = 11
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'ofd
        '
        Me.ofd.FileName = "ofd"
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(12, 4)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(657, 69)
        Me.gbxBrowse.TabIndex = 31
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(540, 15)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(462, 15)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(450, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'frmEmployee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(681, 490)
        Me.Controls.Add(Me.gbxBrowse)
        Me.Controls.Add(Me.gbxEmployee)
        Me.Controls.Add(Me.ssp)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmEmployee"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Employee"
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxEmployee.ResumeLayout(False)
        Me.gbxEmployee.PerformLayout()
        CType(Me.pboEmployee, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbxBrowse.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub




    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents gbxEmployee As System.Windows.Forms.GroupBox
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents txtCurrAdd As System.Windows.Forms.TextBox
    Friend WithEvents txtPermAdd As System.Windows.Forms.TextBox
    Friend WithEvents txtContacts As System.Windows.Forms.TextBox
    Friend WithEvents txtNIC As System.Windows.Forms.TextBox
    Friend WithEvents txtLName As System.Windows.Forms.TextBox
    Friend WithEvents txtFName As System.Windows.Forms.TextBox
    Friend WithEvents txtEmpId As System.Windows.Forms.TextBox



    Friend WithEvents lblBaseLocation As System.Windows.Forms.Label
    Friend WithEvents lblCurrAdd As System.Windows.Forms.Label
    Friend WithEvents lblPermAdd As System.Windows.Forms.Label
    Friend WithEvents lblContacts As System.Windows.Forms.Label
    Friend WithEvents lblNIC As System.Windows.Forms.Label
    Friend WithEvents lblLName As System.Windows.Forms.Label
    Friend WithEvents lblFName As System.Windows.Forms.Label
    Friend WithEvents lblEmpId As System.Windows.Forms.Label





    Friend WithEvents dtpDoB As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lblDoB As System.Windows.Forms.Label
    Friend WithEvents pboEmployee As System.Windows.Forms.PictureBox
    Friend WithEvents ofd As System.Windows.Forms.OpenFileDialog
    Friend WithEvents cboBaseLoc As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtPhotoURL As System.Windows.Forms.TextBox
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents cboMarried As System.Windows.Forms.ComboBox
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox
End Class
