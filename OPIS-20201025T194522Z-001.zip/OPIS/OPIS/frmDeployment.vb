﻿Public Class frmDeployment

    Private dtbrowse, dtPost As DataTable
    Private dbms As DML

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        '"Update tblDeployment Set PostId='" & Me.cboPost.SelectedValue & "', DesigId='"&Me.cboDesig.Text&"', TimeFrom='"&Me.dtpStarts.Text&"', TimeTo='"&Me.dtpEnds.Text&"', Remarks='"&Me.txtRemarks.Text&"', Armed='"&Me.cboArmed.Text&"' Where DeployID='"&Me.txtDeployID.Text&"'" 
        'Insert into tblDeployment (DeployID, PostId, DesigId, TimeFrom, TimeTo, Remarks, Armed) values ('"& Me.txtDeployID.Text &"','"& Me.cboDesig.Text &"','"& Me.dtpStarts.Text &"','"& Me.dtpEnds.Text &"','"& Me.txtRemarks.Text &"','"& Me.cboArmed.Text &"')"
        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("Update tblDeployment Set PostId='" & Me.cboPost.SelectedValue & "', DesigId='" & Me.cboDesig.Text & "', TimeFrom='" & Me.dtpStarts.Text & "', TimeTo='" & Me.dtpEnds.Text & "', Remarks='" & Me.txtRemarks.Text & "', Armed='" & Me.cboArmed.Text & "', Rate=" & Me.txtRate.Text & " Where DeployID='" & Me.txtDeployID.Text & "'")
                Else
                    dbms.execSql("Insert into tblDeployment (DeployID, PostId, DesigId, TimeFrom, TimeTo, Remarks, Armed,Rate) values ('" & Me.txtDeployID.Text & "','" & Me.cboPost.SelectedValue & "','" & Me.cboDesig.Text & "','" & Me.dtpStarts.Text & "','" & Me.dtpEnds.Text & "','" & Me.txtRemarks.Text & "','" & Me.cboArmed.Text & "'," & Me.txtRate.Text & ")")
                End If
                Me.txtDeployID.Text = ""
                Me.cboPost.SelectedValue = -1
                Me.cboDesig.Text = ""
                Me.txtRemarks.Text = ""
                Me.cboArmed.Text = ""
                Me.dtpStarts.Text = Now.ToLocalTime
                Me.dtpEnds.Text = Now.ToLocalTime
                Me.txtRate.Text = ""

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        frmDeployment_Load(Nothing, Nothing)
    End Sub

    Private Sub frmDeployment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DeployID, PostId, DesigId, TimeFrom, TimeTo, Remarks, Armed

        Try
            dbms = New DML()
            Dim str As String

            str = "SELECT  '[' + dbo.tblDeployment.DeployID + '] ' + dbo.tblDeployment.Remarks + ' : [' + dbo.tblPosts.PostNumber + '] ' + dbo.tblPosts.Description + ' : [' + dbo.tblLocations.LocationId"
            str = str & " + '] ' + dbo.tblLocations.Description + ' : [' + dbo.tblContract.ContractId + '] ' + dbo.tblContract.ScopeOfWork + ' : [' + dbo.tblCustomer.CustId + '] ' + dbo.tblCustomer.Name"
            str = str & " AS Expr1,dbo.tblDeployment.Rate,dbo.tblDeployment.DeployID, dbo.tblDeployment.PostId, dbo.tblDeployment.DesigId, dbo.tblDeployment.TimeFrom, dbo.tblDeployment.TimeTo,dbo.tblDeployment.Remarks, dbo.tblDeployment.Armed"
            str = str & " FROM dbo.tblLocations INNER JOIN"
            str = str & " dbo.tblDeployment INNER JOIN"
            str = str & " dbo.tblPosts ON dbo.tblDeployment.PostId = dbo.tblPosts.PostId ON dbo.tblLocations.LocationId = dbo.tblPosts.LocationId INNER JOIN"
            str = str & " dbo.tblContract ON dbo.tblLocations.ContractId = dbo.tblContract.ContractId INNER JOIN"
            str = str & " dbo.tblCustomer ON dbo.tblContract.CustId = dbo.tblCustomer.CustId"

            dtbrowse = dbms.getDataTable(str)

            dtPost = dbms.getDataTable("Select '['+PostId+'] '+Description as Expr1,PostId from tblPosts")

            Me.cboPost.DataSource = dtPost
            Me.cboPost.DisplayMember = "Expr1"
            Me.cboPost.ValueMember = "PostId"

            Me.cboPost.SelectedValue = -1

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("DeployId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "DeployId"

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow
        'DeployID, PostId, DesigId, TimeFrom, TimeTo, Remarks, Armed
        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtDeployID.Text = "" & dr("DeployId")
                Me.cboPost.SelectedValue = "" & dr("PostId")
                Me.cboDesig.Text = "" & dr("DesigId")
                Me.txtRemarks.Text = "" & dr("Remarks")
                Me.cboArmed.Text = "" & dr("Armed")
                Me.dtpStarts.Text = "" & dr("TimeFrom")
                Me.dtpEnds.Text = "" & dr("TimeTo")
                Me.txtRate.Text = "" & dr("Rate")

                Me.gbxDetail.Enabled = True
                Me.txtDeployID.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtDeployID.Text = ""
                Me.cboPost.SelectedValue = -1
                Me.cboDesig.Text = ""
                Me.txtRemarks.Text = ""
                Me.cboArmed.Text = ""
                Me.dtpStarts.Text = Now.ToLocalTime
                Me.dtpEnds.Text = Now.ToLocalTime
                Me.txtRate.Text = ""

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("DeployId")
            Me.txtDeployID.Text = "" & SBUID
            Me.cboPost.SelectedValue = -1
            Me.cboDesig.Text = ""
            Me.txtRemarks.Text = ""
            Me.cboArmed.Text = ""
            Me.dtpStarts.Text = Now.ToLocalTime
            Me.dtpEnds.Text = Now.ToLocalTime
            Me.txtRate.Text = ""

            Me.gbxDetail.Enabled = True
            Me.txtDeployID.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub txtRemarks_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRemarks.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtRate_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRate.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
            e.Handled = True
        End If
    End Sub


End Class