﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOffice
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTypeOfOffice = New System.Windows.Forms.Label()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblNam = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.cboOfficeType = New System.Windows.Forms.ComboBox()
        Me.txtFax = New System.Windows.Forms.TextBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.txtAdd = New System.Windows.Forms.TextBox()
        Me.txtDesc = New System.Windows.Forms.TextBox()
        Me.lblOfficeId = New System.Windows.Forms.Label()
        Me.txtOfficeId = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.gbxBrowse.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.gbxDetail.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTypeOfOffice
        '
        Me.lblTypeOfOffice.AutoSize = True
        Me.lblTypeOfOffice.Location = New System.Drawing.Point(10, 164)
        Me.lblTypeOfOffice.Name = "lblTypeOfOffice"
        Me.lblTypeOfOffice.Size = New System.Drawing.Size(76, 13)
        Me.lblTypeOfOffice.TabIndex = 45
        Me.lblTypeOfOffice.Text = "Type Of Office"
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(2, 0)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(651, 66)
        Me.gbxBrowse.TabIndex = 39
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(556, 19)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(475, 19)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(450, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Location = New System.Drawing.Point(10, 138)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(24, 13)
        Me.lblFax.TabIndex = 39
        Me.lblFax.Text = "Fax"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(10, 112)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(38, 13)
        Me.lblPhone.TabIndex = 38
        Me.lblPhone.Text = "Phone"
        '
        'lblNam
        '
        Me.lblNam.AutoSize = True
        Me.lblNam.Location = New System.Drawing.Point(10, 60)
        Me.lblNam.Name = "lblNam"
        Me.lblNam.Size = New System.Drawing.Size(60, 13)
        Me.lblNam.TabIndex = 36
        Me.lblNam.Text = "Description"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(10, 86)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblAddress.TabIndex = 37
        Me.lblAddress.Text = "Address"
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 317)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(651, 22)
        Me.ssp.TabIndex = 41
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.cboOfficeType)
        Me.gbxDetail.Controls.Add(Me.lblTypeOfOffice)
        Me.gbxDetail.Controls.Add(Me.lblFax)
        Me.gbxDetail.Controls.Add(Me.lblPhone)
        Me.gbxDetail.Controls.Add(Me.lblAddress)
        Me.gbxDetail.Controls.Add(Me.lblNam)
        Me.gbxDetail.Controls.Add(Me.txtFax)
        Me.gbxDetail.Controls.Add(Me.txtPhone)
        Me.gbxDetail.Controls.Add(Me.txtAdd)
        Me.gbxDetail.Controls.Add(Me.txtDesc)
        Me.gbxDetail.Controls.Add(Me.lblOfficeId)
        Me.gbxDetail.Controls.Add(Me.txtOfficeId)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(2, 74)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(651, 233)
        Me.gbxDetail.TabIndex = 40
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Details"
        '
        'cboOfficeType
        '
        Me.cboOfficeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOfficeType.FormattingEnabled = True
        Me.cboOfficeType.Items.AddRange(New Object() {"Head Office", "Region", "Branch", "Zone", ""})
        Me.cboOfficeType.Location = New System.Drawing.Point(115, 156)
        Me.cboOfficeType.Name = "cboOfficeType"
        Me.cboOfficeType.Size = New System.Drawing.Size(273, 21)
        Me.cboOfficeType.TabIndex = 46
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(115, 131)
        Me.txtFax.MaxLength = 50
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(273, 20)
        Me.txtFax.TabIndex = 4
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(115, 105)
        Me.txtPhone.MaxLength = 50
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(273, 20)
        Me.txtPhone.TabIndex = 3
        '
        'txtAdd
        '
        Me.txtAdd.Location = New System.Drawing.Point(115, 79)
        Me.txtAdd.MaxLength = 255
        Me.txtAdd.Name = "txtAdd"
        Me.txtAdd.Size = New System.Drawing.Size(273, 20)
        Me.txtAdd.TabIndex = 2
        '
        'txtDesc
        '
        Me.txtDesc.Location = New System.Drawing.Point(115, 53)
        Me.txtDesc.MaxLength = 50
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(273, 20)
        Me.txtDesc.TabIndex = 1
        '
        'lblOfficeId
        '
        Me.lblOfficeId.AutoSize = True
        Me.lblOfficeId.Location = New System.Drawing.Point(10, 34)
        Me.lblOfficeId.Name = "lblOfficeId"
        Me.lblOfficeId.Size = New System.Drawing.Size(49, 13)
        Me.lblOfficeId.TabIndex = 13
        Me.lblOfficeId.Text = "Office ID"
        '
        'txtOfficeId
        '
        Me.txtOfficeId.Location = New System.Drawing.Point(115, 27)
        Me.txtOfficeId.MaxLength = 50
        Me.txtOfficeId.Name = "txtOfficeId"
        Me.txtOfficeId.Size = New System.Drawing.Size(273, 20)
        Me.txtOfficeId.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(556, 187)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(475, 186)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'frmOffice
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(651, 339)
        Me.Controls.Add(Me.gbxBrowse)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxDetail)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmOffice"
        Me.Text = "frmOffice"
        Me.gbxBrowse.ResumeLayout(False)
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblTypeOfOffice As System.Windows.Forms.Label




    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox

    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents lblNam As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel




    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox





    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtPhone As System.Windows.Forms.TextBox
    Friend WithEvents txtAdd As System.Windows.Forms.TextBox
    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents lblOfficeId As System.Windows.Forms.Label
    Friend WithEvents txtOfficeId As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cboOfficeType As System.Windows.Forms.ComboBox

End Class
