﻿Public Class MDI

    Public stuser As String
    Public stdb As String


    Private Sub SetupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetupToolStripMenuItem.Click
        Dim hnd As New frmEmployee()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub ReportsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub DesignationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DesignationToolStripMenuItem.Click
        Dim hnd As New frmDesignation()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub PromotionDemotionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PromotionDemotionToolStripMenuItem.Click
        Dim hnd As New frmPromotion()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub CustomerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomerToolStripMenuItem.Click
        Dim hnd As New frmCustomer()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub OfficeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OfficeToolStripMenuItem.Click
        Dim hnd As New frmOffice()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub TransferToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TransferToolStripMenuItem.Click
        Dim hnd As New frmTransfer()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub EmploymentRecruitmentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EmploymentRecruitmentToolStripMenuItem.Click
        Dim hnd As New frmEmployment()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub LeavesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LeavesToolStripMenuItem.Click
        Dim hnd As New frmLeave()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub FinesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FinesToolStripMenuItem.Click
        Dim hnd As New frmFine()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub ContractsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContractsToolStripMenuItem.Click
        Dim hnd As New frmContract()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub LocationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LocationToolStripMenuItem.Click
        Dim hnd As New frmLocation()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub PostsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PostsToolStripMenuItem.Click
        Dim hnd As New frmPost()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub DeploymentShiftsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeploymentShiftsToolStripMenuItem.Click
        Dim hnd As New frmDeployment()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub ResourceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResourceToolStripMenuItem.Click
        Dim hnd As New frmResource()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub ScheduleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScheduleToolStripMenuItem.Click
        Dim hnd As New frmSchedule()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub

    Private Sub AttendanceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AttendanceToolStripMenuItem.Click
        Dim hnd As New frmAttendance()
        hnd.MdiParent = Me
        hnd.Show()
    End Sub


    Private Sub MDI_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim hnd As New Splash
        hnd.ShowDialog()
        Dim hnd1 As New Logon
        hnd1.Owner = Me
        hnd1.ShowDialog()
        StatusStrip1.Items(0).Text = "USER LOGGED IN : " & stuser
        Dim db As New DML
        stdb = db.getDatabaseInfo()
        StatusStrip1.Items(1).Text = "DATABASE INFO : " & stdb
        StatusStrip1.Items(2).Text = "CONNECTED WITH DATABASE = " & Authorization

    End Sub

    Private Sub StatusStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles StatusStrip1.ItemClicked

    End Sub

    Private Sub QuitApplicationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QuitApplicationToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ScheduleToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScheduleToolStripMenuItem1.Click
        Dim hnd As New frmRep
        hnd.rep = 1
        hnd.Show()
    End Sub

    Private Sub EstablishmentListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EstablishmentListToolStripMenuItem.Click
        Dim hnd As New frmRep
        hnd.rep = 2
        hnd.Show()
    End Sub

    Private Sub CustomerLocationsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomerLocationsToolStripMenuItem.Click
        Dim hnd As New frmRep
        hnd.rep = 3
        hnd.Show()
    End Sub

    Private Sub PayrollToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PayrollToolStripMenuItem.Click
        Dim hnd As New frmPayroll()
        'hnd.MdiParent = Me
        hnd.ShowDialog()

        Dim hnd1 As New frmRep
        hnd1.rep = 4
        hnd1.Show()
    End Sub

    Private Sub SalarySheetToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SalarySheetToolStripMenuItem.Click
        Dim hnd As New frmRep
        hnd.rep = 4
        hnd.Show()
    End Sub
End Class
