﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPost
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.txtDesc = New System.Windows.Forms.TextBox()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.txtPostNumber = New System.Windows.Forms.TextBox()
        Me.cboLocation = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.lblCustId = New System.Windows.Forms.Label()
        Me.txtPostId = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.gbxDetail.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.gbxBrowse.SuspendLayout()
        Me.SuspendLayout()
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'txtDesc
        '
        Me.txtDesc.Location = New System.Drawing.Point(145, 105)
        Me.txtDesc.MaxLength = 50
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(311, 20)
        Me.txtDesc.TabIndex = 74
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.txtDesc)
        Me.gbxDetail.Controls.Add(Me.txtPostNumber)
        Me.gbxDetail.Controls.Add(Me.cboLocation)
        Me.gbxDetail.Controls.Add(Me.Label3)
        Me.gbxDetail.Controls.Add(Me.lblFax)
        Me.gbxDetail.Controls.Add(Me.lblPhone)
        Me.gbxDetail.Controls.Add(Me.lblAddress)
        Me.gbxDetail.Controls.Add(Me.txtRemarks)
        Me.gbxDetail.Controls.Add(Me.lblCustId)
        Me.gbxDetail.Controls.Add(Me.txtPostId)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(4, 73)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(693, 197)
        Me.gbxDetail.TabIndex = 46
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Details"
        '
        'txtPostNumber
        '
        Me.txtPostNumber.Location = New System.Drawing.Point(145, 52)
        Me.txtPostNumber.MaxLength = 50
        Me.txtPostNumber.Name = "txtPostNumber"
        Me.txtPostNumber.Size = New System.Drawing.Size(311, 20)
        Me.txtPostNumber.TabIndex = 71
        '
        'cboLocation
        '
        Me.cboLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLocation.FormattingEnabled = True
        Me.cboLocation.Location = New System.Drawing.Point(145, 78)
        Me.cboLocation.Name = "cboLocation"
        Me.cboLocation.Size = New System.Drawing.Size(311, 21)
        Me.cboLocation.TabIndex = 69
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 13)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "Post Number"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Location = New System.Drawing.Point(11, 134)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(49, 13)
        Me.lblFax.TabIndex = 39
        Me.lblFax.Text = "Remarks"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(10, 111)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(60, 13)
        Me.lblPhone.TabIndex = 38
        Me.lblPhone.Text = "Description"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(12, 81)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(48, 13)
        Me.lblAddress.TabIndex = 37
        Me.lblAddress.Text = "Location"
        '
        'txtRemarks
        '
        Me.txtRemarks.Location = New System.Drawing.Point(145, 131)
        Me.txtRemarks.MaxLength = 255
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(311, 20)
        Me.txtRemarks.TabIndex = 4
        '
        'lblCustId
        '
        Me.lblCustId.AutoSize = True
        Me.lblCustId.Location = New System.Drawing.Point(12, 30)
        Me.lblCustId.Name = "lblCustId"
        Me.lblCustId.Size = New System.Drawing.Size(42, 13)
        Me.lblCustId.TabIndex = 13
        Me.lblCustId.Text = "Post ID"
        '
        'txtPostId
        '
        Me.txtPostId.Location = New System.Drawing.Point(145, 27)
        Me.txtPostId.MaxLength = 50
        Me.txtPostId.Name = "txtPostId"
        Me.txtPostId.Size = New System.Drawing.Size(311, 20)
        Me.txtPostId.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(605, 153)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(522, 152)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(605, 15)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 280)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(708, 22)
        Me.ssp.TabIndex = 47
        Me.ssp.Text = "StatusStrip1"
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(522, 15)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(510, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(4, 0)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(693, 66)
        Me.gbxBrowse.TabIndex = 45
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'frmPost
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(708, 302)
        Me.Controls.Add(Me.gbxDetail)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxBrowse)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmPost"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmPost"
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxBrowse.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox


    Friend WithEvents txtPostNumber As System.Windows.Forms.TextBox

    Friend WithEvents cboLocation As System.Windows.Forms.ComboBox

    Friend WithEvents Label3 As System.Windows.Forms.Label


    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label

    Friend WithEvents txtRemarks As System.Windows.Forms.TextBox
    Friend WithEvents lblCustId As System.Windows.Forms.Label
    Friend WithEvents txtPostId As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
End Class
