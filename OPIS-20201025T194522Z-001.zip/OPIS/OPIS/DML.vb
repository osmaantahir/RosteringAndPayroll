﻿Imports System.Data.SqlClient
Imports System.IO
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Purpose:To provide interface b/w application and SQL Server
' PRE:Should have Database in SQL Server Named "Payroll"
' POST:You will get the following functions
'            public getDataTable(String) as DataTable
'            public ExecSql(String)
'Author:Usman Tahir
'Date:19/5/2005
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Public Class DML
    Private ConStr As String
    Private Conn As SqlConnection
    Public Sub New()
        Try
            'ConStr = "Data Source=itd-02;Initial Catalog=Payroll;User Id=sa;Password=DnvF%138t;"
            ConStr = "Data Source=Usman-PC;Initial Catalog=OPIS;User Id=sa;Password=sa;"
            'ConStr = "Data Source=HP-PC;Initial Catalog=PAYROSIS;User Id=sa;Password=sa;"
            Conn = New SqlConnection(ConStr)
            Conn.Open()
            Conn.Close()
            Authorization = True
        Catch ex As Exception
            MsgBox("Failed to Connect to Database!" & ex.ToString(), MsgBoxStyle.Critical)
            Authorization = False
        End Try
    End Sub

    Public Function getDatabaseInfo() As String
        Return ConStr
    End Function

    Public Function getDataTable(ByVal strQuery As String) As DataTable
        Try
            Conn.Open()
            Dim da As New SqlDataAdapter(strQuery, Conn)
            Dim dt As New DataTable
            da.Fill(dt)
            Conn.Close()
            Return dt
        Catch ex As Exception
            MsgBox("Failed to Execute Select Statement! [" & ex.ToString & "]", MsgBoxStyle.Critical)
            Return Nothing
            Conn.Close()
        End Try
    End Function

    Public Sub execSql(ByVal strQuery As String)
        Try
            Conn.Open()
            Dim dc As New SqlCommand(strQuery, Conn)
            dc.ExecuteNonQuery()
            Conn.Close()
        Catch ex As Exception
            MsgBox("Failed to Execute Statement! [ " & ex.ToString & " ]", MsgBoxStyle.Critical)
            Conn.Close()
        End Try
    End Sub
    Public Function getRef(ByVal strsql As String) As SqlDataAdapter
        Dim da As New SqlDataAdapter(strsql, Conn)
        Return da
    End Function
    Public Sub getDataTableDA(ByRef cmdbuilder As SqlCommandBuilder, ByRef dt As DataTable, ByRef adp As SqlDataAdapter)
        Try
            cmdbuilder.DataAdapter = adp
            Conn.Open()
            adp.Fill(dt)
            Conn.Close()
        Catch ex As Exception
            MsgBox("Error in Table: " & ex.ToString)
            Conn.Close()
        End Try
    End Sub

    Public Sub getDataSetDA(ByRef cmdbuilder As SqlCommandBuilder, ByRef dt As DataSet, ByRef adp As SqlDataAdapter)
        Try
            cmdbuilder.DataAdapter = adp
            Conn.Open()
            adp.Fill(dt)
            Conn.Close()
        Catch ex As Exception
            MsgBox("Error in Table: " & ex.ToString)
            Conn.Close()
        End Try
    End Sub
    Public Sub updateDatatable(ByRef cmd As SqlCommandBuilder, ByRef da As SqlDataAdapter, ByRef dt As DataTable)
        Try
            Conn.Open()
            MsgBox(da.Update(dt))
            Conn.Close()
        Catch ex As Exception
            MsgBox("Error in Table: " & ex.ToString)
            Conn.Close()
        End Try
    End Sub
    Public Sub SaveImageInDB(ByVal img As String, ByVal wp As String)
        Try
            Dim photo() As Byte = GetPhoto(img)
            Dim i As IConvertible
            Dim salesCMD As SqlCommand = New SqlCommand("SaveImage", Conn)
            salesCMD.CommandType = CommandType.StoredProcedure
            Dim myParm As SqlParameter = salesCMD.Parameters.Add("@img", SqlDbType.Binary, photo.Length)
            myParm.Value = photo
            Dim myParm1 As SqlParameter = salesCMD.Parameters.Add("@emp", SqlDbType.VarChar, 50)
            myParm1.Value = wp
            Conn.Open()
            salesCMD.ExecuteNonQuery()
        Catch ex1 As Exception
            MsgBox(" Normal Exception : " & ex1.ToString)
            Conn.Close()
        Finally
            Conn.Close()
        End Try

    End Sub

    Public Shared Function GetPhoto(ByVal filePath As String) As Byte()
        Dim fs As FileStream = New FileStream(filePath, FileMode.Open, FileAccess.Read)
        Dim br As BinaryReader = New BinaryReader(fs)

        Dim photo() As Byte = br.ReadBytes(fs.Length)

        br.Close()
        fs.Close()

        Return photo
    End Function

    Public Function generateId(ByVal str As String) As String
        Try
            Dim dt As DataTable
            Dim temp As Integer
            Dim str1, str2(2) As String
            dt = dbms.getDataTable("Select " & str & " from tblSequence")
            str1 = CType(dt.Rows(0).Item(0), String)
            str2 = Split(str1, "-")
            temp = CType(str2(1), Integer)
            dbms.execSql("Update tblsequence Set " & str & " = '" & str2(0) & "-" & temp + 1 & "'")
            Return str2(0) & "-" & temp + 1
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

End Class
