﻿Public Class frmResource

    Private dtbrowse, dtDeploy, dtEquip As DataTable
    Private dbms As DML

    Private Sub frmResource_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ResourceId, DeployId, EquipmentID, Description, PerMonthRate, Remarks, QTY
        Try
            dbms = New DML()
            Dim str As String

            str = "SELECT '[' + dbo.tblResources.ResourceId + '] ' + dbo.tblResources.Description + ' :  [' + dbo.tblEquipment.EquipmentId + '] ' + dbo.tblEquipment.Description + ' : [' + dbo.tblDeployment.DeployID"
            str = str & " + '] : [' + dbo.tblPosts.PostNumber + '] ' + dbo.tblPosts.Description + ' : [' + dbo.tblLocations.LocationId + '] ' + dbo.tblLocations.Description + ' : [' + dbo.tblContract.ContractId"
            str = str & " + '] ' + dbo.tblContract.ScopeOfWork + ' : [' + dbo.tblCustomer.CustId + '] ' + dbo.tblCustomer.Name AS Expr1, dbo.tblResources.ResourceId, "
            str = str & " dbo.tblResources.DeployId, dbo.tblResources.EquipmentID, dbo.tblResources.Description, dbo.tblResources.PerMonthRate, dbo.tblResources.Remarks,"
            str = str & " dbo.tblResources.QTY"
            str = str & " FROM dbo.tblContract INNER JOIN"
            str = str & " dbo.tblLocations ON dbo.tblContract.ContractId = dbo.tblLocations.ContractId INNER JOIN"
            str = str & " dbo.tblCustomer ON dbo.tblContract.CustId = dbo.tblCustomer.CustId INNER JOIN"
            str = str & " dbo.tblResources INNER JOIN"
            str = str & " dbo.tblEquipment ON dbo.tblResources.EquipmentID = dbo.tblEquipment.EquipmentId INNER JOIN"
            str = str & " dbo.tblDeployment ON dbo.tblResources.DeployId = dbo.tblDeployment.DeployID INNER JOIN"
            str = str & " dbo.tblPosts ON dbo.tblDeployment.PostId = dbo.tblPosts.PostId ON dbo.tblLocations.LocationId = dbo.tblPosts.LocationId"

            dtbrowse = dbms.getDataTable(str)

            dtDeploy = dbms.getDataTable("Select '['+DeployId+'] '+ Remarks as Expr1,DeployId from tblDeployment")
            dtEquip = dbms.getDataTable("Select '['+EquipmentId+'] '+ Description as Expr1,EquipmentId from tblEquipment")

            Me.cboDeployId.DataSource = dtDeploy
            Me.cboDeployId.DisplayMember = "Expr1"
            Me.cboDeployId.ValueMember = "DeployId"

            Me.cboEquipId.DataSource = dtEquip
            Me.cboEquipId.DisplayMember = "Expr1"
            Me.cboEquipId.ValueMember = "EquipmentId"


            Me.cboDeployId.SelectedValue = -1
            Me.cboEquipId.SelectedValue = -1

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("ResourceId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "ResourceId"

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow
        'ResourceId, DeployId, EquipmentID, Description, PerMonthRate, Remarks, QTY
        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtResId.Text = "" & dr("ResourceId")
                Me.cboDeployId.SelectedValue = "" & dr("DeployId")
                Me.cboEquipId.SelectedValue = "" & dr("EquipmentId")
                Me.txtDesc.Text = "" & dr("Description")
                Me.txtRate.Text = "" & dr("PerMonthRate")
                Me.txtRemarks.Text = "" & dr("Remarks")
                Me.txtQty.Text = "" & dr("QTY")

                Me.gbxDetail.Enabled = True
                Me.txtResId.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtResId.Text = ""
                Me.cboDeployId.SelectedValue = -1
                Me.cboEquipId.SelectedValue = -1
                Me.txtDesc.Text = ""
                Me.txtRate.Text = ""
                Me.txtRemarks.Text = ""
                Me.txtQty.Text = ""

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("ResId")
            Me.txtResId.Text = "" & SBUID
            Me.cboDeployId.SelectedValue = -1
            Me.cboEquipId.SelectedValue = -1
            Me.txtDesc.Text = ""
            Me.txtRate.Text = ""
            Me.txtRemarks.Text = ""
            Me.txtQty.Text = ""

            Me.gbxDetail.Enabled = True
            Me.txtResId.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        'Update tblResource Set  DeployId='', EquipmentID='', Description='', PerMonthRate=, Remarks='', QTY= Where ResourceId=''
        'Insert into tblResource (ResourceId, DeployId, EquipmentID, Description, PerMonthRate, Remarks, QTY) values ()

        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("Update tblResources Set  DeployId='" & Me.cboDeployId.SelectedValue & "', EquipmentID='" & Me.cboEquipId.SelectedValue & "', Description='" & Me.txtDesc.Text & "', PerMonthRate=" & Me.txtRate.Text & ", Remarks='" & Me.txtRemarks.Text & "', QTY=" & Me.txtQty.Text & " Where ResourceId='" & Me.txtResId.Text & "'")
                Else
                    dbms.execSql("Insert into tblResources (ResourceId, DeployId, EquipmentID, Description, PerMonthRate, Remarks, QTY) values ('" & Me.txtResId.Text & "','" & Me.cboDeployId.SelectedValue & "','" & Me.cboEquipId.SelectedValue & "','" & Me.txtDesc.Text & "'," & Me.txtRate.Text & ",'" & Me.txtRemarks.Text & "'," & Me.txtQty.Text & ")")
                End If
                Me.txtResId.Text = ""
                Me.cboDeployId.SelectedValue = -1
                Me.cboEquipId.SelectedValue = -1
                Me.txtDesc.Text = ""
                Me.txtRate.Text = ""
                Me.txtRemarks.Text = ""
                Me.txtQty.Text = ""

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        frmResource_Load(Nothing, Nothing)
    End Sub

    Private Sub txtDesc_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDesc.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub txtDesc_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDesc.TextChanged

    End Sub

    Private Sub txtRate_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRate.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtRate_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRate.TextChanged

    End Sub

    Private Sub txtQty_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtQty.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtQty_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtQty.TextChanged

    End Sub

    Private Sub txtRemarks_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRemarks.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub txtRemarks_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRemarks.TextChanged

    End Sub
End Class