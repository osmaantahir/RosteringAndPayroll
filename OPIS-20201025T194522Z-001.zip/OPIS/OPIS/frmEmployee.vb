﻿Public Class frmEmployee
    Private dtbrowse As DataTable

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            ofd.Filter = "Bitmap Size Less than 50KB |*.bmp"
            ofd.InitialDirectory = "c:\"
            ofd.ShowDialog()
            txtPhotoURL.Text = ofd.FileName
            pboEmployee.Image = Image.FromFile(txtPhotoURL.Text)
        Catch ex As Exception
            MsgBox("Please Ensure File Size is less than 50KB and File Exists!")
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        'If txtPhotoURL.Text.Length > 0 Then dbms.SaveImageInDB(txtPhotoURL.Text, txtEmpId.Text)
        If ssp.Items("Mode").Text = "EDITING MODE" Then
            Dim str As String
            str = "Update dbo.tblEmployee SET"
            str = str & " FName='" & Me.txtFName.Text & "',"
            str = str & " LName='" & Me.txtLName.Text & "',"
            str = str & " NIC='" & Me.txtNIC.Text & "',"
            str = str & " Contacts='" & Me.txtContacts.Text & "',"
            str = str & " PermAddress='" & Me.txtPermAdd.Text & "',"
            str = str & " CurrAddress='" & Me.txtCurrAdd.Text & "',"
            str = str & " BasedLocation='" & Me.cboBaseLoc.Text & "',"
            str = str & " DoB='" & Me.dtpDoB.Value & "',"
            str = str & " Married='" & Me.cboMarried.Text & "'"
            str = str & " WHERE EmpId='" & Me.txtEmpId.Text & "'"
            Try
                dbms.execSql(str)
                If txtPhotoURL.Text.Length > 0 Then dbms.SaveImageInDB(txtPhotoURL.Text, txtEmpId.Text)
                MsgBox("Record Successfully Updated!")
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
            Me.gbxBrowse.Enabled = True
            Me.gbxEmployee.Enabled = False
            ssp.Items("Mode").Text = "BROWSE MODE"
        Else
            Dim str As String
            str = "INSERT INTO dbo.tblEmployee ("
            str = str & " EmpId,FName,LName,NIC,Contacts,PermAddress,CurrAddress,BasedLocation,DoB,Married"
            str = str & ") VALUES ("
            str = str & "'" & Me.txtEmpId.Text & "',"
            str = str & "'" & Me.txtFName.Text & "',"
            str = str & "'" & Me.txtLName.Text & "',"
            str = str & "'" & Me.txtNIC.Text & "',"
            str = str & "'" & Me.txtContacts.Text & "',"
            str = str & "'" & Me.txtPermAdd.Text & "',"
            str = str & "'" & Me.txtCurrAdd.Text & "',"
            str = str & "'" & Me.cboBaseLoc.Text & "',"
            str = str & "'" & Me.dtpDoB.Value & "',"
            str = str & "'" & Me.cboMarried.Text & "')"
            Try
                dbms.execSql(str)
                If txtPhotoURL.Text.Length > 0 Then dbms.SaveImageInDB(txtPhotoURL.Text, txtEmpId.Text)
                MsgBox("Record Successfully Inserted!")
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
            Me.gbxBrowse.Enabled = True
            Me.gbxEmployee.Enabled = False
            ssp.Items("Mode").Text = "BROWSE MODE"
        End If
        frmEmployee_Load(Nothing, Nothing)
    End Sub

    Private Sub frmEmployee_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbms = New DML()
        dtbrowse = dbms.getDataTable("Select  EmpId+' --- '+Fname+' --- '+ LName as Expr1,EmpId, FName, LName, NIC, Contacts, PermAddress, CurrAddress, BasedLocation, DoB, Married, Photo from dbo.tblEmployee")

        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("EmpId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "EmpId"

        gbxEmployee.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow

        dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
        If dr Is Nothing Then
            ' Not Found
        Else
            Me.txtEmpId.Text = dr("EmpId")
            Me.txtFName.Text = "" & dr("Fname")
            Me.txtLName.Text = "" & dr("lname")
            Me.txtNIC.Text = "" & dr("NIC")
            Me.txtPermAdd.Text = "" & dr("PermAddress")
            Me.txtCurrAdd.Text = "" & dr("CurrAddress")
            Me.txtContacts.Text = "" & dr("Contacts")
            Me.cboBaseLoc.Text = "" & dr("BasedLocation")
            Me.dtpDoB.Value = "" & dr("DoB")
            Me.cboMarried.Text = "" & dr("Married")
            If dr("Photo") Is System.DBNull.Value Then
                Me.pboEmployee.Image = Nothing
            Else
                Dim bytBLOBData() As Byte = dr("Photo")
                Dim stmBLOBData As New System.IO.MemoryStream(bytBLOBData)
                Me.pboEmployee.Image = Image.FromStream(stmBLOBData)
            End If
            Me.gbxEmployee.Enabled = True
            Me.txtEmpId.Enabled = False
            ssp.Items("Mode").Text = "EDITING MODE"
            Me.gbxBrowse.Enabled = False
        End If
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.gbxBrowse.Enabled = True
        Me.gbxEmployee.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Me.gbxBrowse.Enabled = False
        Me.gbxEmployee.Enabled = True
        Me.txtEmpId.Enabled = True

        Me.txtEmpId.Text = ""
        Me.txtFName.Text = ""
        Me.txtLName.Text = ""
        Me.txtNIC.Text = ""
        Me.txtPermAdd.Text = ""
        Me.txtCurrAdd.Text = ""
        Me.txtContacts.Text = ""
        Me.cboBaseLoc.Text = ""
        Me.dtpDoB.Value = Today
        Me.cboMarried.Text = ""
        Me.pboEmployee.Image = Nothing


        Me.txtEmpId.Focus()
        ssp.Items("Mode").Text = "NEW RECORD"
    End Sub

    Private Sub txtEmpId_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtEmpId.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtFName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFName.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtLName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtLName.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtNIC_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtNIC.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtContacts_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtContacts.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If

    End Sub


    Private Sub txtPermAdd_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPermAdd.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If

    End Sub


    Private Sub txtCurrAdd_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCurrAdd.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If

    End Sub


    Private Sub txtFName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFName.TextChanged

    End Sub
End Class