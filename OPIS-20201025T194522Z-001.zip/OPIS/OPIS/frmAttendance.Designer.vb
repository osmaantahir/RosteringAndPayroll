﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAttendance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAttendance))
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.dtp = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboOffice = New System.Windows.Forms.ComboBox()
        Me.gbxdetail = New System.Windows.Forms.GroupBox()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.gbxBrowse.SuspendLayout()
        Me.gbxdetail.SuspendLayout()
        Me.ssp.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.dtp)
        Me.gbxBrowse.Controls.Add(Me.Label2)
        Me.gbxBrowse.Controls.Add(Me.lblFax)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboOffice)
        Me.gbxBrowse.Location = New System.Drawing.Point(2, 2)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(994, 101)
        Me.gbxBrowse.TabIndex = 53
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'dtp
        '
        Me.dtp.Location = New System.Drawing.Point(71, 59)
        Me.dtp.Name = "dtp"
        Me.dtp.Size = New System.Drawing.Size(788, 20)
        Me.dtp.TabIndex = 48
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 61)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 42
        Me.Label2.Text = "Date"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Location = New System.Drawing.Point(6, 35)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(35, 13)
        Me.lblFax.TabIndex = 40
        Me.lblFax.Text = "Office"
        '
        'cmdGo
        '
        Me.cmdGo.Enabled = False
        Me.cmdGo.Image = CType(resources.GetObject("cmdGo.Image"), System.Drawing.Image)
        Me.cmdGo.Location = New System.Drawing.Point(883, 27)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(94, 52)
        Me.cmdGo.TabIndex = 2
        Me.cmdGo.Text = "New"
        Me.cmdGo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboOffice
        '
        Me.cboOffice.DisplayMember = "CustId"
        Me.cboOffice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOffice.FormattingEnabled = True
        Me.cboOffice.Location = New System.Drawing.Point(67, 27)
        Me.cboOffice.Name = "cboOffice"
        Me.cboOffice.Size = New System.Drawing.Size(792, 21)
        Me.cboOffice.TabIndex = 0
        Me.cboOffice.ValueMember = "CustId"
        '
        'gbxdetail
        '
        Me.gbxdetail.Controls.Add(Me.ssp)
        Me.gbxdetail.Controls.Add(Me.Button3)
        Me.gbxdetail.Controls.Add(Me.Button2)
        Me.gbxdetail.Controls.Add(Me.dgv)
        Me.gbxdetail.Location = New System.Drawing.Point(2, 109)
        Me.gbxdetail.Name = "gbxdetail"
        Me.gbxdetail.Size = New System.Drawing.Size(994, 430)
        Me.gbxdetail.TabIndex = 54
        Me.gbxdetail.TabStop = False
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(3, 405)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(988, 22)
        Me.ssp.TabIndex = 47
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'Button3
        '
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(883, 214)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(94, 204)
        Me.Button3.TabIndex = 46
        Me.Button3.Text = "Cancel"
        Me.Button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(883, 13)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(94, 195)
        Me.Button2.TabIndex = 45
        Me.Button2.Text = "Save"
        Me.Button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button2.UseVisualStyleBackColor = True
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.AllowUserToDeleteRows = False
        Me.dgv.BackgroundColor = System.Drawing.Color.White
        Me.dgv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.GridColor = System.Drawing.Color.Green
        Me.dgv.Location = New System.Drawing.Point(6, 13)
        Me.dgv.Name = "dgv"
        Me.dgv.ReadOnly = True
        Me.dgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgv.Size = New System.Drawing.Size(871, 405)
        Me.dgv.TabIndex = 44
        '
        'frmAttendance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1002, 536)
        Me.Controls.Add(Me.gbxdetail)
        Me.Controls.Add(Me.gbxBrowse)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAttendance"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmAttendance"
        Me.gbxBrowse.ResumeLayout(False)
        Me.gbxBrowse.PerformLayout()
        Me.gbxdetail.ResumeLayout(False)
        Me.gbxdetail.PerformLayout()
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox





    Friend WithEvents Label2 As System.Windows.Forms.Label

    Friend WithEvents lblFax As System.Windows.Forms.Label



    Friend WithEvents cmdGo As System.Windows.Forms.Button

    Friend WithEvents cboOffice As System.Windows.Forms.ComboBox
    Friend WithEvents dtp As System.Windows.Forms.DateTimePicker
    Friend WithEvents gbxdetail As System.Windows.Forms.GroupBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
























End Class
