﻿Public Class frmPayroll
    Private dbms As DML
    Private stOffice, stMonth, stYear As String
    Private dtOffice, dtemp, dtDesig, dtPromo, dtBreakUp As DataTable
    Private intAmount, intSundays, intDaysInMonth, intLeaveHrs, intdutyhours As Integer
    Private dtSunday As Date

    Private Sub frmPayroll_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbms = New DML
        dtOffice = dbms.getDataTable("Select OfficeId+' : '+Description as expr1, OfficeId from tblOffice")
        Me.cboOffice.DataSource = dtOffice
        Me.cboOffice.DisplayMember = "expr1"
        Me.cboOffice.ValueMember = "OfficeId"
        intLeaveHrs = 1
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        'Swap values selected to local variables
        stOffice = Me.cboOffice.SelectedValue
        stMonth = "" & Me.cboMonth.SelectedIndex + 1
        stYear = Me.nupYear.Value

        Dim ij As Integer

        intDaysInMonth = System.DateTime.DaysInMonth(stYear, stMonth)

        For ij = 1 To intDaysInMonth
            dtSunday = stMonth & "/" & ij & "/" & stYear
            If dtSunday.DayOfWeek() = DayOfWeek.Sunday Then
                intSundays = intSundays + 1
            End If
        Next ij

        'Getting Employees with last Posting as per Office Id
        Dim str As String

        str = "SELECT dbo.tblTransfer.EmpId, dbo.tblTransfer.OfficeId, dbo.tblEmployee.FName, dbo.tblEmployee.LName"
        str = str & " FROM dbo.tblTransfer INNER JOIN"
        str = str & " dbo.tblEmployee ON dbo.tblTransfer.EmpId = dbo.tblEmployee.EmpId"
        str = str & " WHERE dbo.tblTransfer.TransferId IN"
        str = str & " (SELECT MAX(DISTINCT TransferId) AS Expr1"
        str = str & " FROM dbo.tblTransfer AS tblTransfer_1"
        str = str & " GROUP BY EmpId) and dbo.tblTransfer.OfficeId='" & stOffice & "'"


        dtemp = dbms.getDataTable(str)


        Dim i As Integer
        Dim stPayroll(3), stPayDetail(3), stDesig As String

        For i = 0 To dtemp.Rows.Count - 1
            intLeaveHrs = 1
            stPayroll(0) = "" & dbms.generateId("PayrollId")                ' Payroll ID
            stPayroll(1) = "" & stMonth & "/1/" & stYear                    ' Payroll Date
            stPayroll(2) = "" & dtemp.Rows(i)("EmpId")                      ' Employee ID
            stPayroll(3) = "" & getWorkHours(stPayroll(2), stPayroll(1))    ' Duty Hours Performed

            stDesig = getDesignation(stPayroll(2))

            dtDesig = dbms.getDataTable("SELECT  * from tblDesignation where DesigId='" & stDesig & "'")

            intdutyhours = dtDesig.Rows(0)("DutyHoursinDay")

            'MsgBox("ID=" & stPayroll(0) & ". Date=" & stPayroll(1) & ", Emp=" & stPayroll(2) & ", Hours=" & stPayroll(3) & ", Desig=" & stDesig)

            dbms.execSql("insert into tblPayroll (PayrollId,Pdate,EmpId,Hrs) values ('" & stPayroll(0) & "','" & stPayroll(1) & "','" & stPayroll(2) & "'," & stPayroll(3) & ")")


            dtBreakUp = dbms.getDataTable("Select * from tblSalaryBreakUp where DesigId='" & stDesig & "'")

            For j = 0 To dtBreakUp.Rows.Count - 1

                stPayDetail(0) = "" & dbms.generateId("PayrollDetailId")
                stPayDetail(1) = "" & stPayroll(0)
                stPayDetail(2) = "" & dtBreakUp.Rows(j)("SalaryBreakUpId")
                stPayDetail(3) = "" & getBreakUp(dtBreakUp.Rows(j)("BreakUpStatus"), dtBreakUp.Rows(j)("Amount"), dtDesig.Rows(0)("DutyHoursinDay"), stPayroll(3))

                'MsgBox("ID=" & stPayDetail(0) & ". PID=" & stPayDetail(1) & ", BreakUpID=" & stPayDetail(2) & ", Amount=" & stPayDetail(3))

                dbms.execSql("insert into tblPayrollDetail (PayrollDetailId,PayrollId,BreakUpID,Amount) values ('" & stPayDetail(0) & "','" & stPayDetail(1) & "','" & stPayDetail(2) & "'," & stPayDetail(3) & ")")

            Next j


        Next i
        MsgBox("Payroll is successfully processed!")
        Me.Close()
    End Sub

    Private Function getWorkHours(ByVal st As String, ByVal st1 As String) As Integer
        Dim hrs = 0, i As Integer
        Dim dt As DataTable
        Dim stStart, stEnd As DateTime
        Dim hrsdiff As TimeSpan

        dt = dbms.getDataTable("Select TimeFrom,TimeTo,StatusID from tblAttendance where (Adate BETWEEN '" & st1 & "' AND '" & stMonth & "/30/" & stYear & "') and EmpId='" & st & "'")
        For i = 0 To dt.Rows.Count - 1
            If CStr(dt.Rows(i)("StatusId")).Contains("L") = True Then intLeaveHrs = intLeaveHrs + 1
            stStart = dt.Rows(i)("TimeFrom")
            stEnd = dt.Rows(i)("TimeTo")
            hrsdiff = stEnd.Subtract(stStart)
            hrs = hrs + hrsdiff.TotalHours
        Next i
        Return hrs
    End Function

    Private Function getBreakUp(ByVal stStatus As String, ByVal intAmount As Integer, ByVal intDutyHrs As Integer, ByVal intDutyPerformedHrs As Integer) As Integer
        Dim intamt, inttemp As Integer

        If stStatus.Equals("Basic") = True Then

            intamt = ((intAmount / (intDaysInMonth - intSundays)) / intDutyHrs)
            inttemp = intamt
            intamt = intamt * intDutyPerformedHrs
            If intLeaveHrs > 1 Then
                inttemp = inttemp * intLeaveHrs * intDutyHrs
                intamt = intamt + inttemp
            End If
            Return intamt

        ElseIf stStatus.Equals("Allowance") = True Then

            intamt = ((intAmount / (intDaysInMonth - intSundays)) / intDutyHrs)
            intamt = intamt * intDutyPerformedHrs
            Return intamt

        ElseIf stStatus.Equals("Deduction") = True Then

            intamt = ((intAmount / (intDaysInMonth - intSundays)) / intDutyHrs)
            intamt = intamt
            Return intamt * -1

        End If
    End Function

    Private Function getDesignation(ByVal stemp As String) As String
        Dim st, stDesig As String

        st = "SELECT DesigId, EmpId"
        st = st & " FROM tblPromotion"
        st = st & " WHERE PromoId IN"
        st = st & " (SELECT MAX(PromoId) AS Expr1"
        st = st & " FROM tblPromotion AS tblPromotion_1"
        st = st & " GROUP BY EmpId) and EmpId='" & stemp & "'"

        dtPromo = dbms.getDataTable(st)

        stDesig = "" & dtPromo.Rows(0)(0)

        Return stDesig
    End Function

End Class