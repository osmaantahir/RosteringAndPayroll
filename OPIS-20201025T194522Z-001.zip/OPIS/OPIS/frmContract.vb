﻿Public Class frmContract
    Private dtbrowse, dtEmp, dtemp1, dtcust As DataTable
    Private dbms As DML

    Private Sub frmContract_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' ContractId, SignOffDate, CommencementDate, ExpiryDate, ScopeOfWork, CompanySigningAuth, CompanyWitness, CustomerSigningAuth, CustomerWitness,ForceMajeaureClause, TPLIndeminfy, Liability, ModeOfPayment, RiskExposure, InvoicingDate, Remarks, CustId

        Try
            dbms = New DML()
            Dim str As String

            str = "SELECT dbo.tblContract.ContractId + ' : [' + dbo.tblCustomer.CustId + '] ' + dbo.tblCustomer.Name + ' : ' + dbo.tblContract.ScopeOfWork AS expr1, dbo.tblContract.ContractId, "
            str = str & " dbo.tblContract.SignOffDate, dbo.tblContract.CommencementDate, dbo.tblContract.ExpiryDate, dbo.tblContract.ScopeOfWork, dbo.tblContract.CompanySigningAuth,"
            str = str & " dbo.tblContract.CompanyWitness, dbo.tblContract.CustomerSigningAuth, dbo.tblContract.CustomerWitness, dbo.tblContract.ForceMajeaureClause,"
            str = str & " dbo.tblContract.TPLIndeminfy, dbo.tblContract.Liability, dbo.tblContract.ModeOfPayment, dbo.tblContract.RiskExposure, dbo.tblContract.InvoicingDate,"
            str = str & " dbo.tblContract.Remarks, dbo.tblContract.CustId"
            str = str & " FROM dbo.tblContract INNER JOIN"
            str = str & " dbo.tblCustomer ON dbo.tblContract.CustId = dbo.tblCustomer.CustId"

            dtbrowse = dbms.getDataTable(str)

            dtEmp = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")
            dtemp1 = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")
            dtcust = dbms.getDataTable("Select '['+CustId+'] '+Name as Expr1,CustId from tblCustomer")

            Me.cboCompanyAuth.DataSource = dtEmp
            Me.cboCompanyAuth.DisplayMember = "Expr1"
            Me.cboCompanyAuth.ValueMember = "EmpId"

            Me.cboCompanyWitness.DataSource = dtemp1
            Me.cboCompanyWitness.DisplayMember = "Expr1"
            Me.cboCompanyWitness.ValueMember = "EmpId"

            Me.cboCustomer.DataSource = dtcust
            Me.cboCustomer.DisplayMember = "Expr1"
            Me.cboCustomer.ValueMember = "CustId"

            Me.cboCompanyAuth.SelectedValue = -1
            Me.cboCompanyWitness.SelectedValue = -1
            Me.cboCustomer.SelectedValue = -1

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("ContractId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "ContractId"

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow
        'ContractId, SignOffDate, CommencementDate, ExpiryDate, ScopeOfWork, CompanySigningAuth,CompanyWitness, CustomerSigningAuth, CustomerWitness, ForceMajeaureClause, TPLIndeminfy, Liability, ModeOfPayment, RiskExposure, InvoicingDate, Remarks, CustId
        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtContractID.Text = "" & dr("ContractId")
                Me.dtpSigningDate.Value = "" & dr("SignOffDate")
                Me.dtpCommence.Value = "" & dr("CommencementDate")
                Me.dtpExpiry.Value = "" & dr("ExpiryDate")
                Me.txtSoW.Text = "" & dr("ScopeOfWork")
                Me.cboCompanyAuth.SelectedValue = "" & dr("CompanySigningAuth")
                Me.cboCompanyWitness.SelectedValue = "" & dr("CompanyWitness")
                Me.txtCustomerAuth.Text = "" & dr("CustomerSigningAuth")
                Me.txtCustomerWitness.Text = "" & dr("CustomerWitness")
                Me.cboForceMaj.Text = "" & dr("ForceMajeaureClause")
                Me.cboTPL.Text = "" & dr("TPLIndeminfy")
                Me.txtLiability.Text = "" & dr("Liability")
                Me.cboModeOfPayment.Text = "" & dr("ModeOfPayment")
                Me.txtRisk.Text = "" & dr("RiskExposure")
                Me.txtDateofInv.Text = "" & dr("InvoicingDate")
                Me.txtRemarks.Text = "" & dr("Remarks")
                Me.cboCustomer.SelectedValue = "" & dr("CustId")


                Me.gbxDetail.Enabled = True
                Me.txtContractID.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtContractID.Text = ""
                Me.dtpSigningDate.Value = Today
                Me.dtpCommence.Value = Today
                Me.dtpExpiry.Value = Today
                Me.txtSoW.Text = ""
                Me.cboCompanyAuth.SelectedValue = -1
                Me.cboCompanyWitness.SelectedValue = -1
                Me.txtCustomerAuth.Text = ""
                Me.txtCustomerWitness.Text = ""
                Me.cboForceMaj.Text = ""
                Me.cboTPL.Text = ""
                Me.txtLiability.Text = ""
                Me.cboModeOfPayment.Text = ""
                Me.txtRisk.Text = ""
                Me.txtDateofInv.Text = ""
                Me.txtRemarks.Text = ""
                Me.cboCustomer.SelectedValue = -1

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("ContractId")
            Me.txtContractID.Text = "" & SBUID
            Me.dtpSigningDate.Value = Today
            Me.dtpCommence.Value = Today
            Me.dtpExpiry.Value = Today
            Me.txtSoW.Text = ""
            Me.cboCompanyAuth.SelectedValue = -1
            Me.cboCompanyWitness.SelectedValue = -1
            Me.txtCustomerAuth.Text = ""
            Me.txtCustomerWitness.Text = ""
            Me.cboForceMaj.Text = ""
            Me.cboTPL.Text = ""
            Me.txtLiability.Text = ""
            Me.cboModeOfPayment.Text = ""
            Me.txtRisk.Text = ""
            Me.txtDateofInv.Text = ""
            Me.txtRemarks.Text = ""
            Me.cboCustomer.SelectedValue = -1


            Me.gbxDetail.Enabled = True
            Me.txtContractID.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        'UPDATE tblContract SET SignOffDate='', CommencementDate='', ExpiryDate='', ScopeOfWork='', CompanySigningAuth='',CompanyWitness='', CustomerSigningAuth='', CustomerWitness='', ForceMajeaureClause='', TPLIndeminfy='', Liability=, ModeOfPayment='', RiskExposure='', InvoicingDate='', Remarks='', CustId='' WHERE ContractId=''

        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("UPDATE tblContract SET SignOffDate='" & Me.dtpSigningDate.Value & "', CommencementDate='" & Me.dtpCommence.Value & "', ExpiryDate='" & Me.dtpExpiry.Value & "', ScopeOfWork='" & Me.txtSoW.Text & "', CompanySigningAuth='" & Me.cboCompanyAuth.SelectedValue & "',CompanyWitness='" & Me.cboCompanyWitness.SelectedValue & "', CustomerSigningAuth='" & Me.txtCustomerAuth.Text & "', CustomerWitness='" & Me.txtCustomerWitness.Text & "', ForceMajeaureClause='" & Me.cboForceMaj.Text & "', TPLIndeminfy='" & Me.cboTPL.Text & "', Liability=" & Me.txtLiability.Text & ", ModeOfPayment='" & Me.cboModeOfPayment.Text & "', RiskExposure='" & Me.txtRisk.Text & "', InvoicingDate='" & Me.txtDateofInv.Text & "', Remarks='" & Me.txtRemarks.Text & "', CustId='" & Me.cboCustomer.SelectedValue & "' WHERE ContractId='" & Me.txtContractID.Text & "'")

                Else
                    dbms.execSql("Insert into tblContract (ContractId, SignOffDate, CommencementDate, ExpiryDate, ScopeOfWork, CompanySigningAuth,CompanyWitness, CustomerSigningAuth, CustomerWitness, ForceMajeaureClause, TPLIndeminfy, Liability, ModeOfPayment, RiskExposure, InvoicingDate, Remarks, CustId) values ( '" & Me.txtContractID.Text & "','" & Me.dtpSigningDate.Value & "','" & Me.dtpCommence.Value & "','" & Me.dtpExpiry.Value & "','" & Me.txtSoW.Text & "','" & Me.cboCompanyAuth.SelectedValue & "','" & Me.cboCompanyWitness.SelectedValue & "','" & Me.txtCustomerAuth.Text & "','" & Me.txtCustomerWitness.Text & "','" & Me.cboForceMaj.Text & "','" & Me.cboTPL.Text & "'," & Me.txtLiability.Text & ",'" & Me.cboModeOfPayment.Text & "','" & Me.txtRisk.Text & "','" & Me.txtDateofInv.Text & "','" & Me.txtRemarks.Text & "','" & Me.cboCustomer.SelectedValue & "')")
                End If
                Me.txtContractID.Text = ""
                Me.dtpSigningDate.Value = Today
                Me.dtpCommence.Value = Today
                Me.dtpExpiry.Value = Today
                Me.txtSoW.Text = ""
                Me.cboCompanyAuth.SelectedValue = -1
                Me.cboCompanyWitness.SelectedValue = -1
                Me.txtCustomerAuth.Text = ""
                Me.txtCustomerWitness.Text = ""
                Me.cboForceMaj.Text = ""
                Me.cboTPL.Text = ""
                Me.txtLiability.Text = ""
                Me.cboModeOfPayment.Text = ""
                Me.txtRisk.Text = ""
                Me.txtDateofInv.Text = ""
                Me.txtRemarks.Text = ""
                Me.cboCustomer.SelectedValue = -1

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        frmContract_Load(Nothing, Nothing)
    End Sub

    Private Sub txtSoW_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSoW.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub



    Private Sub txtCustomerAuth_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCustomerAuth.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub



    Private Sub txtCustomerWitness_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCustomerWitness.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub



    Private Sub txtRisk_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRisk.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub



    Private Sub txtDateofInv_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDateofInv.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub



    Private Sub txtRemarks_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRemarks.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub



    Private Sub txtLiability_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtLiability.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
            e.Handled = True
        End If
    End Sub


    Private Sub txtLiability_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLiability.TextChanged

    End Sub
End Class