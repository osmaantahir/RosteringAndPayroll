﻿Public Class frmRep
    Public rep As Integer

    Private Sub frmRep_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If rep = 1 Then
            Dim hnd As New rptschedule1
            Me.CrystalReportViewer1.ReportSource = hnd
        ElseIf rep = 2 Then
            Dim hnd As New rptemp
            Me.CrystalReportViewer1.ReportSource = hnd
        ElseIf rep = 3 Then
            Dim hnd As New rptCustomer
            Me.CrystalReportViewer1.ReportSource = hnd
        ElseIf rep = 4 Then
            Dim hnd As New rptPayroll
            Me.CrystalReportViewer1.ReportSource = hnd
        End If
    End Sub

End Class