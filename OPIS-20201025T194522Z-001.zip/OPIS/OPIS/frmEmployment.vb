﻿Public Class frmEmployment
    Private dtbrowse, dtEmp, dtemp1, dtemp2 As DataTable
    Private dbms As DML

    Private Sub frmEmployment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            dbms = New DML()
            Dim str As String
            str = "SELECT dbo.tblEmployment.EmploymentId + ' : [' + dbo.tblEmployee.EmpId + '] ' + dbo.tblEmployee.FName + ' ' + dbo.tblEmployee.LName AS expr1, "
            str = str & " dbo.tblEmployment.EmploymentId, dbo.tblEmployment.EmpId, dbo.tblEmployment.DateOfEmployment, dbo.tblEmployment.DateOfDischarge,"
            str = str & " dbo.tblEmployment.Remarks, dbo.tblEmployment.EmploymentApprovedBy, dbo.tblEmployment.ExitInterviewBy, dbo.tblEmployment.ReasonforDischarge,"
            str = str & " dbo.tblEmployment.DisplanaryActionforDischarge"
            str = str & " FROM dbo.tblEmployment INNER JOIN"
            str = str & " dbo.tblEmployee ON dbo.tblEmployment.EmpId = dbo.tblEmployee.EmpId"

            dtbrowse = dbms.getDataTable(str)
            dtEmp = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")
            dtemp1 = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")
            dtemp2 = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")

            Me.cboEmp.DataSource = dtEmp
            Me.cboEmp.DisplayMember = "Expr1"
            Me.cboEmp.ValueMember = "EmpId"

            Me.cboApproved.DataSource = dtemp1
            Me.cboApproved.DisplayMember = "Expr1"
            Me.cboApproved.ValueMember = "EmpId"

            Me.cboExitInterview.DataSource = dtemp2
            Me.cboExitInterview.DisplayMember = "Expr1"
            Me.cboExitInterview.ValueMember = "EmpId"


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("EmploymentId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "EmploymentId"

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow

        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtEmploymentId.Text = "" & dr("EmploymentId")
                Me.cboEmp.SelectedValue = "" & dr("EmpId")
                Me.dtpDoJ.Value = "" & dr("DateOfEmployment")
                Me.dtpDoD.Value = "" & dr("DateOfDischarge")
                Me.txtRemarks.Text = "" & dr("Remarks")
                Me.cboApproved.SelectedValue = "" & dr("EmploymentApprovedBy")
                Me.cboExitInterview.SelectedValue = "" & dr("ExitInterviewBy")
                Me.txtReason.Text = "" & dr("ReasonforDischarge")
                Me.cboAction.Text = "" & dr("DisplanaryActionforDischarge")

                Me.gbxDetail.Enabled = True
                Me.txtEmploymentId.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtEmploymentId.Text = ""
                Me.txtRemarks.Text = ""
                Me.txtReason.Text = ""
                Me.dtpDoJ.Text = Today
                Me.dtpDoD.Text = Today
                Me.cboExitInterview.SelectedValue = -1
                Me.cboAction.Text = ""

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("EmploymentId")
            Me.txtEmploymentId.Text = "" & SBUID
            Me.dtpDoJ.Text = Today
            Me.dtpDoD.Text = Today
            Me.txtRemarks.Text = ""
            Me.txtReason.Text = ""
            Me.cboAction.Text = ""
            Me.cboExitInterview.SelectedValue = -1

            Me.gbxDetail.Enabled = True
            Me.txtEmploymentId.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("Update tblEmployment Set EmpId='" & Me.cboEmp.SelectedValue & "', DateOfEmployment='" & Me.dtpDoJ.Value & "',DateOfDischarge='" & Me.dtpDoD.Value & "',Remarks='" & Me.txtRemarks.Text & "',EmploymentApprovedBy='" & Me.cboApproved.SelectedValue & "',ExitInterviewBy='" & Me.cboExitInterview.SelectedValue & "',ReasonforDischarge='" & Me.txtReason.Text & "',DisplanaryActionforDischarge='" & Me.cboAction.Text & "' where EmploymentId='" & Me.txtEmploymentId.Text & "'")
                Else
                    dbms.execSql("Insert into tblEmployment (EmploymentId,EmpId,DateOfEmployment,DateOfDischarge,Remarks,EmploymentApprovedBy,ExitInterviewBy,ReasonforDischarge,DisplanaryActionforDischarge) values ('" & Me.txtEmploymentId.Text & "','" & Me.cboEmp.SelectedValue & "','" & Me.dtpDoJ.Value & "','" & Me.dtpDoD.Value & "','" & Me.txtRemarks.Text & "','" & Me.cboApproved.SelectedValue & "','" & Me.cboExitInterview.SelectedValue & "','" & Me.txtReason.Text & "','" & Me.cboAction.Text & "')")
                End If
                Me.txtEmploymentId.Text = ""
                Me.txtRemarks.Text = ""
                Me.txtReason.Text = ""
                Me.dtpDoJ.Text = Today
                Me.dtpDoD.Text = Today
                Me.cboExitInterview.SelectedValue = -1
                Me.cboAction.Text = ""

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        frmEmployment_Load(Nothing, Nothing)
    End Sub

    Private Sub txtRemarks_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRemarks.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub txtReason_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtReason.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


End Class