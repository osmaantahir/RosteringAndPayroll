﻿Public Class frmLeave
    Private dtbrowse, dtEmp, dtemp1, dt2 As DataTable
    Private dbms As DML

    Private Sub frmLeave_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' LeaveId, EmpId, DateFrom, DateTo, StatusId, ApprovedBy

        Try
            dbms = New DML()
            Dim str As String
            str = "SELECT dbo.tblLeaves.LeaveId + ' : [' + dbo.tblEmployee.EmpId + '] ' + dbo.tblEmployee.FName + ' ' + dbo.tblEmployee.LName + ' : ' + dbo.tblStatus.Description AS expr1, "
            str = str & " dbo.tblLeaves.LeaveId, dbo.tblLeaves.EmpId, dbo.tblLeaves.DateFrom, dbo.tblLeaves.DateTo, dbo.tblLeaves.StatusId, dbo.tblLeaves.ApprovedBy"
            str = str & " FROM dbo.tblLeaves INNER JOIN"
            str = str & " dbo.tblEmployee ON dbo.tblLeaves.EmpId = dbo.tblEmployee.EmpId INNER JOIN"
            str = str & " dbo.tblStatus ON dbo.tblLeaves.StatusId = dbo.tblStatus.StatusId"

            dtbrowse = dbms.getDataTable(str)
            dtEmp = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")
            dtemp1 = dbms.getDataTable("Select '['+EmpId+'] '+FName+' '+LName as Expr1,EmpId from tblEmployee")
            dt2 = dbms.getDataTable("Select '['+StatusId+'] '+Description+' : '+Payable as Expr1,StatusId from tblStatus")

            Me.cboEmp.DataSource = dtEmp
            Me.cboEmp.DisplayMember = "Expr1"
            Me.cboEmp.ValueMember = "EmpId"

            Me.cboApproved.DataSource = dtemp1
            Me.cboApproved.DisplayMember = "Expr1"
            Me.cboApproved.ValueMember = "EmpId"

            Me.cboStatus.DataSource = dt2
            Me.cboStatus.DisplayMember = "Expr1"
            Me.cboStatus.ValueMember = "StatusId"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("LeaveId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "LeaveId"

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow

        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtLeaveId.Text = "" & dr("LeaveId")
                Me.cboEmp.SelectedValue = "" & dr("EmpId")
                Me.dtpStart.Value = "" & dr("DateFrom")
                Me.dtpEnd.Value = "" & dr("DateTo")
                Me.cboStatus.SelectedValue = "" & dr("StatusId")
                Me.cboApproved.SelectedValue = "" & dr("ApprovedBy")

                Me.gbxDetail.Enabled = True
                Me.txtLeaveId.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtLeaveId.Text = ""
                Me.cboEmp.SelectedValue = -1
                Me.dtpStart.Value = Today
                Me.dtpEnd.Value = Today
                Me.cboStatus.SelectedValue = -1
                Me.cboApproved.SelectedValue = -1

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("LeaveId")
            Me.txtLeaveId.Text = "" & SBUID
            Me.cboEmp.SelectedValue = -1
            Me.dtpStart.Value = Today
            Me.dtpEnd.Value = Today
            Me.cboStatus.SelectedValue = -1
            Me.cboApproved.SelectedValue = -1

            Me.gbxDetail.Enabled = True
            Me.txtLeaveId.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim SBUID As String
        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("Update tblLeaves Set EmpId='" & Me.cboEmp.SelectedValue & "', DateFrom='" & Me.dtpStart.Value & "',DateTo='" & Me.dtpEnd.Value & "',StatusId='" & Me.cboStatus.SelectedValue & "',ApprovedBy='" & Me.cboApproved.SelectedValue & "' where LeaveId='" & Me.txtLeaveId.Text & "'")
                Else
                    dbms.execSql("Insert into tblLeaves (LeaveId, EmpId, DateFrom, DateTo, StatusId, ApprovedBy) values ('" & Me.txtLeaveId.Text & "','" & Me.cboEmp.SelectedValue & "','" & Me.dtpStart.Value & "','" & Me.dtpEnd.Value & "','" & Me.cboStatus.SelectedValue & "','" & Me.cboApproved.SelectedValue & "')")
                End If
                Me.txtLeaveId.Text = ""
                Me.cboEmp.SelectedValue = -1
                Me.dtpStart.Value = Today
                Me.dtpEnd.Value = Today
                Me.cboStatus.SelectedValue = -1
                Me.cboApproved.SelectedValue = -1

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        frmLeave_Load(Nothing, Nothing)
    End Sub
End Class