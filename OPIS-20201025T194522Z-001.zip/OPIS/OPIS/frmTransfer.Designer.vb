﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTransfer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboEmp = New System.Windows.Forms.ComboBox()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblTransferId = New System.Windows.Forms.Label()
        Me.txtTransferId = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.lblOff = New System.Windows.Forms.Label()
        Me.lblRemarks = New System.Windows.Forms.Label()
        Me.lblDoT = New System.Windows.Forms.Label()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.dtpDoT = New System.Windows.Forms.DateTimePicker()
        Me.cboOff = New System.Windows.Forms.ComboBox()
        Me.lblEmp = New System.Windows.Forms.Label()
        Me.gbxBrowse.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.gbxDetail.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboEmp
        '
        Me.cboEmp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEmp.FormattingEnabled = True
        Me.cboEmp.Items.AddRange(New Object() {"Head Office", "Region", "Branch", "Zone", ""})
        Me.cboEmp.Location = New System.Drawing.Point(115, 54)
        Me.cboEmp.Name = "cboEmp"
        Me.cboEmp.Size = New System.Drawing.Size(273, 21)
        Me.cboEmp.TabIndex = 46
        '
        'txtRemarks
        '
        Me.txtRemarks.Location = New System.Drawing.Point(115, 131)
        Me.txtRemarks.MaxLength = 255
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(273, 20)
        Me.txtRemarks.TabIndex = 4
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'lblTransferId
        '
        Me.lblTransferId.AutoSize = True
        Me.lblTransferId.Location = New System.Drawing.Point(10, 34)
        Me.lblTransferId.Name = "lblTransferId"
        Me.lblTransferId.Size = New System.Drawing.Size(60, 13)
        Me.lblTransferId.TabIndex = 13
        Me.lblTransferId.Text = "Transfer ID"
        '
        'txtTransferId
        '
        Me.txtTransferId.Location = New System.Drawing.Point(115, 27)
        Me.txtTransferId.MaxLength = 50
        Me.txtTransferId.Name = "txtTransferId"
        Me.txtTransferId.Size = New System.Drawing.Size(273, 20)
        Me.txtTransferId.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(556, 152)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(-1, 0)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(651, 66)
        Me.gbxBrowse.TabIndex = 42
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(556, 19)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(475, 19)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(450, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 279)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(658, 22)
        Me.ssp.TabIndex = 44
        Me.ssp.Text = "StatusStrip1"
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(475, 152)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'lblOff
        '
        Me.lblOff.AutoSize = True
        Me.lblOff.Location = New System.Drawing.Point(10, 86)
        Me.lblOff.Name = "lblOff"
        Me.lblOff.Size = New System.Drawing.Size(35, 13)
        Me.lblOff.TabIndex = 37
        Me.lblOff.Text = "Office"
        '
        'lblRemarks
        '
        Me.lblRemarks.AutoSize = True
        Me.lblRemarks.Location = New System.Drawing.Point(10, 138)
        Me.lblRemarks.Name = "lblRemarks"
        Me.lblRemarks.Size = New System.Drawing.Size(49, 13)
        Me.lblRemarks.TabIndex = 39
        Me.lblRemarks.Text = "Remarks"
        '
        'lblDoT
        '
        Me.lblDoT.AutoSize = True
        Me.lblDoT.Location = New System.Drawing.Point(10, 112)
        Me.lblDoT.Name = "lblDoT"
        Me.lblDoT.Size = New System.Drawing.Size(86, 13)
        Me.lblDoT.TabIndex = 38
        Me.lblDoT.Text = "Date Of Transfer"
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.dtpDoT)
        Me.gbxDetail.Controls.Add(Me.cboOff)
        Me.gbxDetail.Controls.Add(Me.cboEmp)
        Me.gbxDetail.Controls.Add(Me.lblRemarks)
        Me.gbxDetail.Controls.Add(Me.lblDoT)
        Me.gbxDetail.Controls.Add(Me.lblOff)
        Me.gbxDetail.Controls.Add(Me.lblEmp)
        Me.gbxDetail.Controls.Add(Me.txtRemarks)
        Me.gbxDetail.Controls.Add(Me.lblTransferId)
        Me.gbxDetail.Controls.Add(Me.txtTransferId)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(-1, 74)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(651, 196)
        Me.gbxDetail.TabIndex = 43
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Details"
        '
        'dtpDoT
        '
        Me.dtpDoT.Location = New System.Drawing.Point(115, 106)
        Me.dtpDoT.Name = "dtpDoT"
        Me.dtpDoT.Size = New System.Drawing.Size(273, 20)
        Me.dtpDoT.TabIndex = 48
        '
        'cboOff
        '
        Me.cboOff.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOff.FormattingEnabled = True
        Me.cboOff.Items.AddRange(New Object() {"Head Office", "Region", "Branch", "Zone", ""})
        Me.cboOff.Location = New System.Drawing.Point(115, 78)
        Me.cboOff.Name = "cboOff"
        Me.cboOff.Size = New System.Drawing.Size(273, 21)
        Me.cboOff.TabIndex = 47
        '
        'lblEmp
        '
        Me.lblEmp.AutoSize = True
        Me.lblEmp.Location = New System.Drawing.Point(10, 60)
        Me.lblEmp.Name = "lblEmp"
        Me.lblEmp.Size = New System.Drawing.Size(53, 13)
        Me.lblEmp.TabIndex = 36
        Me.lblEmp.Text = "Employee"
        '
        'frmTransfer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(658, 301)
        Me.Controls.Add(Me.gbxBrowse)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxDetail)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmTransfer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmTransfer"
        Me.gbxBrowse.ResumeLayout(False)
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cboEmp As System.Windows.Forms.ComboBox
    Friend WithEvents txtRemarks As System.Windows.Forms.TextBox



    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblTransferId As System.Windows.Forms.Label
    Friend WithEvents txtTransferId As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip

    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents lblOff As System.Windows.Forms.Label
    Friend WithEvents lblRemarks As System.Windows.Forms.Label
    Friend WithEvents lblDoT As System.Windows.Forms.Label
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox
    Friend WithEvents lblEmp As System.Windows.Forms.Label
    Friend WithEvents cboOff As System.Windows.Forms.ComboBox
    Friend WithEvents dtpDoT As System.Windows.Forms.DateTimePicker
End Class
