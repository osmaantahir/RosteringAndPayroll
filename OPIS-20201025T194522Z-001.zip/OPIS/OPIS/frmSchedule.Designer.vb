﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSchedule
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSchedule))
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.cmdLocation = New System.Windows.Forms.Button()
        Me.cmdContract = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.cboPost = New System.Windows.Forms.ComboBox()
        Me.cboLocation = New System.Windows.Forms.ComboBox()
        Me.cboContract = New System.Windows.Forms.ComboBox()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cmdCust = New System.Windows.Forms.Button()
        Me.cboCustomer = New System.Windows.Forms.ComboBox()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxBrowse.SuspendLayout()
        Me.gbxDetail.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ssp.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.MonthCalendar1)
        Me.gbxBrowse.Controls.Add(Me.Button1)
        Me.gbxBrowse.Controls.Add(Me.cmdLocation)
        Me.gbxBrowse.Controls.Add(Me.cmdContract)
        Me.gbxBrowse.Controls.Add(Me.Label3)
        Me.gbxBrowse.Controls.Add(Me.Label2)
        Me.gbxBrowse.Controls.Add(Me.Label1)
        Me.gbxBrowse.Controls.Add(Me.lblFax)
        Me.gbxBrowse.Controls.Add(Me.cboPost)
        Me.gbxBrowse.Controls.Add(Me.cboLocation)
        Me.gbxBrowse.Controls.Add(Me.cboContract)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cmdCust)
        Me.gbxBrowse.Controls.Add(Me.cboCustomer)
        Me.gbxBrowse.Location = New System.Drawing.Point(12, 9)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(1259, 183)
        Me.gbxBrowse.TabIndex = 52
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'MonthCalendar1
        '
        Me.MonthCalendar1.Location = New System.Drawing.Point(920, 9)
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 47
        '
        'Button1
        '
        Me.Button1.Enabled = False
        Me.Button1.Location = New System.Drawing.Point(848, 124)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(29, 21)
        Me.Button1.TabIndex = 46
        Me.Button1.Text = ">>"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'cmdLocation
        '
        Me.cmdLocation.Enabled = False
        Me.cmdLocation.Location = New System.Drawing.Point(848, 92)
        Me.cmdLocation.Name = "cmdLocation"
        Me.cmdLocation.Size = New System.Drawing.Size(29, 21)
        Me.cmdLocation.TabIndex = 45
        Me.cmdLocation.Text = ">>"
        Me.cmdLocation.UseVisualStyleBackColor = True
        '
        'cmdContract
        '
        Me.cmdContract.Enabled = False
        Me.cmdContract.Location = New System.Drawing.Point(848, 61)
        Me.cmdContract.Name = "cmdContract"
        Me.cmdContract.Size = New System.Drawing.Size(29, 21)
        Me.cmdContract.TabIndex = 44
        Me.cmdContract.Text = ">>"
        Me.cmdContract.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 132)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 13)
        Me.Label3.TabIndex = 43
        Me.Label3.Text = "Post"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 42
        Me.Label2.Text = "Location"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 41
        Me.Label1.Text = "Contract"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Location = New System.Drawing.Point(6, 35)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(51, 13)
        Me.lblFax.TabIndex = 40
        Me.lblFax.Text = "Customer"
        '
        'cboPost
        '
        Me.cboPost.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPost.Enabled = False
        Me.cboPost.FormattingEnabled = True
        Me.cboPost.Location = New System.Drawing.Point(67, 124)
        Me.cboPost.Name = "cboPost"
        Me.cboPost.Size = New System.Drawing.Size(768, 21)
        Me.cboPost.TabIndex = 5
        '
        'cboLocation
        '
        Me.cboLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLocation.Enabled = False
        Me.cboLocation.FormattingEnabled = True
        Me.cboLocation.Location = New System.Drawing.Point(67, 92)
        Me.cboLocation.Name = "cboLocation"
        Me.cboLocation.Size = New System.Drawing.Size(768, 21)
        Me.cboLocation.TabIndex = 4
        '
        'cboContract
        '
        Me.cboContract.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboContract.Enabled = False
        Me.cboContract.FormattingEnabled = True
        Me.cboContract.Location = New System.Drawing.Point(67, 61)
        Me.cboContract.Name = "cboContract"
        Me.cboContract.Size = New System.Drawing.Size(768, 21)
        Me.cboContract.TabIndex = 3
        '
        'cmdGo
        '
        Me.cmdGo.Enabled = False
        Me.cmdGo.Image = CType(resources.GetObject("cmdGo.Image"), System.Drawing.Image)
        Me.cmdGo.Location = New System.Drawing.Point(1159, 9)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(94, 162)
        Me.cmdGo.TabIndex = 2
        Me.cmdGo.Text = "New"
        Me.cmdGo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cmdCust
        '
        Me.cmdCust.Location = New System.Drawing.Point(848, 27)
        Me.cmdCust.Name = "cmdCust"
        Me.cmdCust.Size = New System.Drawing.Size(29, 21)
        Me.cmdCust.TabIndex = 1
        Me.cmdCust.Text = ">>"
        Me.cmdCust.UseVisualStyleBackColor = True
        '
        'cboCustomer
        '
        Me.cboCustomer.DisplayMember = "CustId"
        Me.cboCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCustomer.FormattingEnabled = True
        Me.cboCustomer.Location = New System.Drawing.Point(67, 27)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.Size = New System.Drawing.Size(768, 21)
        Me.cboCustomer.TabIndex = 0
        Me.cboCustomer.ValueMember = "CustId"
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.Button3)
        Me.gbxDetail.Controls.Add(Me.Button2)
        Me.gbxDetail.Controls.Add(Me.dgv)
        Me.gbxDetail.Location = New System.Drawing.Point(12, 179)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(1259, 430)
        Me.gbxDetail.TabIndex = 53
        Me.gbxDetail.TabStop = False
        '
        'Button3
        '
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(1159, 214)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(94, 204)
        Me.Button3.TabIndex = 46
        Me.Button3.Text = "Cancel"
        Me.Button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(1159, 13)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(94, 195)
        Me.Button2.TabIndex = 45
        Me.Button2.Text = "Save"
        Me.Button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button2.UseVisualStyleBackColor = True
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.AllowUserToDeleteRows = False
        Me.dgv.BackgroundColor = System.Drawing.Color.White
        Me.dgv.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        Me.dgv.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.GridColor = System.Drawing.Color.Green
        Me.dgv.Location = New System.Drawing.Point(6, 13)
        Me.dgv.Name = "dgv"
        Me.dgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgv.Size = New System.Drawing.Size(1147, 405)
        Me.dgv.TabIndex = 44
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 601)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(1284, 22)
        Me.ssp.TabIndex = 54
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'frmSchedule
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1284, 623)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxDetail)
        Me.Controls.Add(Me.gbxBrowse)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSchedule"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmSchedule"
        Me.gbxBrowse.ResumeLayout(False)
        Me.gbxBrowse.PerformLayout()
        Me.gbxDetail.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub














































































    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cboPost As System.Windows.Forms.ComboBox
    Friend WithEvents cboLocation As System.Windows.Forms.ComboBox
    Friend WithEvents cboContract As System.Windows.Forms.ComboBox
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cmdCust As System.Windows.Forms.Button
    Friend WithEvents cboCustomer As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label


    Friend WithEvents cmdLocation As System.Windows.Forms.Button
    Friend WithEvents cmdContract As System.Windows.Forms.Button
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox






    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents MonthCalendar1 As System.Windows.Forms.MonthCalendar
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel













































































































































End Class
