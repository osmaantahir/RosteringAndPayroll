﻿Public Class frmSchedule
    Private rowind As Integer
    Private dbms As DML
    Private dtcust, dtContract, dtLocation, dtPost, dtDeploy, dtemp, dtoffice, dtschedule, dt As DataTable
    Public strEmpId As String

    Private Sub frmSchedule_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbms = New DML

        With Me.cboCustomer
            .Enabled = True
            dtcust = dbms.getDataTable("select '['+CustId+'] '+Name as Expr1, CustId as Id  from tblCustomer")
            .DataSource = dtcust
            .DisplayMember = "Expr1"
            .ValueMember = "Id"
            Me.cmdCust.Enabled = True
        End With

        dtemp = dbms.getDataTable("Select EmpId+' ' " & vbCrLf & "+Fname+' '+Lname as expr1 from tblEmployee")

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub


    Private Sub cboBrowse_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCustomer.SelectedIndexChanged
        Me.cboPost.SelectedValue = -1
        Me.cboPost.Enabled = False
        Me.cmdGo.Enabled = False

        Me.cboLocation.SelectedValue = -1
        Me.cboLocation.Enabled = False
        Me.cmdLocation.Enabled = False

        Me.cboContract.SelectedValue = -1
        Me.cboContract.Enabled = False
        Me.cmdContract.Enabled = False
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCust.Click
        With Me.cboContract
            .Enabled = True
            dtContract = dbms.getDataTable("select '['+ContractId+'] '+ScopeOfWork as Expr1, ContractId as Id  from tblContract where CustId='" & Me.cboCustomer.SelectedValue & "'")
            .DataSource = dtContract
            .DisplayMember = "Expr1"
            .ValueMember = "Id"
            Me.cmdContract.Enabled = True
        End With
    End Sub

    Private Sub cmdContract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdContract.Click
        With Me.cboLocation
            .Enabled = True
            dtLocation = dbms.getDataTable("select '['+LocationId+'] '+Description as Expr1, LocationId as Id  from tblLocations where ContractId='" & Me.cboContract.SelectedValue & "'")
            .DataSource = dtLocation
            .DisplayMember = "Expr1"
            .ValueMember = "Id"
            Me.cmdLocation.Enabled = True
        End With

    End Sub

    Private Sub cmdLocation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLocation.Click
        With Me.cboPost
            .Enabled = True
            dtPost = dbms.getDataTable("select '['+PostId+' : '+ PostNumber+'] '+Description as Expr1, PostId as Id  from tblPosts where LocationId='" & Me.cboLocation.SelectedValue & "'")
            .DataSource = dtPost
            .DisplayMember = "Expr1"
            .ValueMember = "Id"
            Me.cmdGo.Enabled = True
        End With
    End Sub

    Private Sub cboLocation_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboLocation.SelectedIndexChanged
        Me.cboPost.SelectedValue = -1
        Me.cboPost.Enabled = False
        Me.cmdGo.Enabled = False
    End Sub

    Private Sub cboContract_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboContract.SelectedIndexChanged
        Me.cboPost.SelectedValue = -1
        Me.cboPost.Enabled = False
        Me.cmdGo.Enabled = False

        Me.cboLocation.SelectedValue = -1
        Me.cboLocation.Enabled = False
        Me.cmdLocation.Enabled = False
    End Sub

    Private Sub cmdGo_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        'MsgBox(" Customer=" & Me.cboCustomer.SelectedValue & " : Contract=" & Me.cboContract.SelectedValue & " : Location=" & Me.cboLocation.SelectedValue & " : Post=" & Me.cboPost.SelectedValue)

        dtDeploy = dbms.getDataTable("Select * from tblDeployment where PostId='" & Me.cboPost.SelectedValue & "'")



        Dim i As Integer
        Dim st(31) As String
        dtschedule = New DataTable("Schedule")

        dtschedule.Columns.Add("Deployment")
        dtschedule.Columns.Add("1st")
        dtschedule.Columns.Add("2nd")
        dtschedule.Columns.Add("3rd")
        dtschedule.Columns.Add("4th")
        dtschedule.Columns.Add("5th")
        dtschedule.Columns.Add("6th")
        dtschedule.Columns.Add("7th")
        dtschedule.Columns.Add("8th")
        dtschedule.Columns.Add("9th")
        dtschedule.Columns.Add("10th")
        dtschedule.Columns.Add("11th")
        dtschedule.Columns.Add("12th")
        dtschedule.Columns.Add("13th")
        dtschedule.Columns.Add("14th")
        dtschedule.Columns.Add("15th")
        dtschedule.Columns.Add("16th")
        dtschedule.Columns.Add("17th")
        dtschedule.Columns.Add("18th")
        dtschedule.Columns.Add("19th")
        dtschedule.Columns.Add("20th")
        dtschedule.Columns.Add("21st")
        dtschedule.Columns.Add("22nd")
        dtschedule.Columns.Add("23rd")
        dtschedule.Columns.Add("24th")
        dtschedule.Columns.Add("25th")
        dtschedule.Columns.Add("26th")
        dtschedule.Columns.Add("27th")
        dtschedule.Columns.Add("28th")
        dtschedule.Columns.Add("29th")
        dtschedule.Columns.Add("30th")
        dtschedule.Columns.Add("31st")

        dgv.DataSource = dtschedule
        dgv.Columns(0).MinimumWidth = 200


        For i = 1 To 31
            dgv.Columns(i).Width = 60
        Next i

        Me.dgv.ReadOnly = True
        dgv.DefaultCellStyle.WrapMode = DataGridViewTriState.True
        Me.dgv.AllowUserToResizeRows = False



        For i = 0 To dtDeploy.Rows.Count - 1
            st(0) = "" & dtDeploy.Rows(i)(0) & " " & dtDeploy.Rows(i)(5) & vbCrLf & dtDeploy.Rows(i)(2) & vbCrLf & "From: " & dtDeploy.Rows(i)(3) & ", To: " & dtDeploy.Rows(i)(4) & vbCrLf & "Armed: " & dtDeploy.Rows(i)(6)
            dtschedule.Rows.Add(st)
            dgv.Rows(i).MinimumHeight = 75
            dgv.Item(0, i).Style.BackColor = Color.DarkGreen
            dgv.Item(0, i).Style.ForeColor = Color.White
        Next i

        Me.gbxDetail.Enabled = True
        ssp.Items("Mode").Text = "EDITING MODE"
        Me.gbxBrowse.Enabled = False

    End Sub

    Private Sub dgv_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellDoubleClick
        If e.ColumnIndex <= 0 Or e.RowIndex >= dtschedule.Rows.Count Or e.RowIndex < 0 Then Exit Sub
        Dim dlg As frmpopup
        Dim strr() As String
        dlg = New frmpopup(dtemp, "expr1", "expr1", "Select Employee from the list!", strEmpId)
        dlg.Owner = Me
        dlg.ShowDialog()
        strr = Split(strEmpId, " ")
        strEmpId = strr(0) & " " & vbCrLf & strr(1) & vbCrLf & strr(2)
        dtschedule.Rows(e.RowIndex)(e.ColumnIndex) = strEmpId
        dgv.Item(e.ColumnIndex, e.RowIndex).Style.BackColor = Color.LightGreen
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim i, j As Integer

        For i = 0 To dtschedule.Rows.Count - 1
            For j = 1 To 31
                If System.String.Compare(dtschedule.Rows(i)(j) & "", "") <> 1 Then
                    MsgBox("Cannot Proceed to Save! " & vbCrLf & "Record is not entered at cell [Column=" & j + 1 & " , Row=" & i + 1 & "]", MsgBoxStyle.OkOnly)
                    dgv.CurrentCell = dgv.Item(j, i)
                    Exit Sub
                End If
            Next j
        Next i

        Dim st(), stDeploy, stEmp, stDate As String

        For i = 0 To dtschedule.Rows.Count - 1
            For j = 1 To 31
                st = Split(dtschedule.Rows(i)(0) & "", " ")
                stDeploy = "" & st(0)
                st = Split(dtschedule.Rows(i)(j) & "", " ")
                stEmp = "" & st(0)
                st = Split(MonthCalendar1.ToString(), " ")
                st = Split(st(3), "/")
                stDate = "" & st(0) & "/" & j & "/" & st(2)
                dbms.execSql("Insert into tblSchedule (DeployID,EmpID,SDate) Values ('" & stDeploy & "','" & stEmp & "','" & stDate & "')")
            Next j
        Next i

        MsgBox("Record is saved!")
        Me.gbxBrowse.Enabled = True
        Me.gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
        dtschedule = Nothing
        dgv.DataSource = Nothing

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.gbxBrowse.Enabled = True
        Me.gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
        dtschedule = Nothing
        dgv.DataSource = Nothing
    End Sub

    Private Sub dgv_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.CellMouseClick

    End Sub


    Private Sub dgv_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles dgv.KeyDown
        If e.KeyCode = Keys.F1 Then
            Clipboard.SetText(dgv.CurrentCell().Value)
        ElseIf e.KeyCode = Keys.F2 Then
            dgv.CurrentCell.Value = Clipboard.GetText
            dgv.CurrentCell.Style.BackColor = Color.LightGreen
        End If
    End Sub
End Class