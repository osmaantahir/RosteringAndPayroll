﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmResource
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.txtDesc = New System.Windows.Forms.TextBox()
        Me.txtRate = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.cboDeployId = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboEquipId = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblCustId = New System.Windows.Forms.Label()
        Me.txtResId = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.gbxDetail.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.gbxBrowse.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.txtDesc)
        Me.gbxDetail.Controls.Add(Me.txtRate)
        Me.gbxDetail.Controls.Add(Me.Label4)
        Me.gbxDetail.Controls.Add(Me.txtQty)
        Me.gbxDetail.Controls.Add(Me.txtRemarks)
        Me.gbxDetail.Controls.Add(Me.cboDeployId)
        Me.gbxDetail.Controls.Add(Me.Label1)
        Me.gbxDetail.Controls.Add(Me.cboEquipId)
        Me.gbxDetail.Controls.Add(Me.Label3)
        Me.gbxDetail.Controls.Add(Me.lblFax)
        Me.gbxDetail.Controls.Add(Me.lblPhone)
        Me.gbxDetail.Controls.Add(Me.lblAddress)
        Me.gbxDetail.Controls.Add(Me.lblCustId)
        Me.gbxDetail.Controls.Add(Me.txtResId)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(-1, 73)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(950, 154)
        Me.gbxDetail.TabIndex = 52
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Details"
        '
        'txtDesc
        '
        Me.txtDesc.Location = New System.Drawing.Point(145, 108)
        Me.txtDesc.MaxLength = 6
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(311, 20)
        Me.txtDesc.TabIndex = 85
        '
        'txtRate
        '
        Me.txtRate.Location = New System.Drawing.Point(633, 27)
        Me.txtRate.MaxLength = 6
        Me.txtRate.Name = "txtRate"
        Me.txtRate.Size = New System.Drawing.Size(311, 20)
        Me.txtRate.TabIndex = 84
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(500, 84)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 13)
        Me.Label4.TabIndex = 83
        Me.Label4.Text = "Quantity"
        '
        'txtQty
        '
        Me.txtQty.Location = New System.Drawing.Point(633, 81)
        Me.txtQty.MaxLength = 3
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(311, 20)
        Me.txtQty.TabIndex = 82
        '
        'txtRemarks
        '
        Me.txtRemarks.Location = New System.Drawing.Point(633, 55)
        Me.txtRemarks.MaxLength = 255
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(311, 20)
        Me.txtRemarks.TabIndex = 79
        '
        'cboDeployId
        '
        Me.cboDeployId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDeployId.FormattingEnabled = True
        Me.cboDeployId.Location = New System.Drawing.Point(145, 51)
        Me.cboDeployId.Name = "cboDeployId"
        Me.cboDeployId.Size = New System.Drawing.Size(311, 21)
        Me.cboDeployId.TabIndex = 77
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(500, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "Remarks"
        '
        'cboEquipId
        '
        Me.cboEquipId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEquipId.FormattingEnabled = True
        Me.cboEquipId.Items.AddRange(New Object() {"Guard", "Supervisor", "Officer", "Manager", "Lady Search", "Male Seach", "K-9 Handler", "Body Guard", "Commando", "Other", ""})
        Me.cboEquipId.Location = New System.Drawing.Point(145, 78)
        Me.cboEquipId.Name = "cboEquipId"
        Me.cboEquipId.Size = New System.Drawing.Size(311, 21)
        Me.cboEquipId.TabIndex = 69
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 13)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "Deployment ID"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Location = New System.Drawing.Point(499, 32)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(82, 13)
        Me.lblFax.TabIndex = 39
        Me.lblFax.Text = "Rate Per Month"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(10, 111)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(60, 13)
        Me.lblPhone.TabIndex = 38
        Me.lblPhone.Text = "Description"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(12, 81)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(71, 13)
        Me.lblAddress.TabIndex = 37
        Me.lblAddress.Text = "Equipment ID"
        '
        'lblCustId
        '
        Me.lblCustId.AutoSize = True
        Me.lblCustId.Location = New System.Drawing.Point(12, 30)
        Me.lblCustId.Name = "lblCustId"
        Me.lblCustId.Size = New System.Drawing.Size(67, 13)
        Me.lblCustId.TabIndex = 13
        Me.lblCustId.Text = "Resource ID"
        '
        'txtResId
        '
        Me.txtResId.Location = New System.Drawing.Point(145, 27)
        Me.txtResId.MaxLength = 50
        Me.txtResId.Name = "txtResId"
        Me.txtResId.Size = New System.Drawing.Size(311, 20)
        Me.txtResId.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(867, 111)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(784, 111)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(772, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(867, 15)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 233)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(986, 22)
        Me.ssp.TabIndex = 53
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(-1, 0)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(950, 66)
        Me.gbxBrowse.TabIndex = 51
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(784, 15)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'frmResource
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(986, 255)
        Me.Controls.Add(Me.gbxDetail)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxBrowse)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmResource"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmResource"
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxBrowse.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtQty As System.Windows.Forms.TextBox


    Friend WithEvents txtRemarks As System.Windows.Forms.TextBox

    Friend WithEvents cboDeployId As System.Windows.Forms.ComboBox

    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboEquipId As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblCustId As System.Windows.Forms.Label
    Friend WithEvents txtResId As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents txtRate As System.Windows.Forms.TextBox
End Class
