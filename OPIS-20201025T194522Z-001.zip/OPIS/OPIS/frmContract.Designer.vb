﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmContract
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblNam = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.txtDateofInv = New System.Windows.Forms.TextBox()
        Me.cboCustomer = New System.Windows.Forms.ComboBox()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.txtRisk = New System.Windows.Forms.TextBox()
        Me.cboModeOfPayment = New System.Windows.Forms.ComboBox()
        Me.txtLiability = New System.Windows.Forms.TextBox()
        Me.cboTPL = New System.Windows.Forms.ComboBox()
        Me.cboForceMaj = New System.Windows.Forms.ComboBox()
        Me.txtCustomerWitness = New System.Windows.Forms.TextBox()
        Me.txtCustomerAuth = New System.Windows.Forms.TextBox()
        Me.cboCompanyWitness = New System.Windows.Forms.ComboBox()
        Me.cboCompanyAuth = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpExpiry = New System.Windows.Forms.DateTimePicker()
        Me.dtpCommence = New System.Windows.Forms.DateTimePicker()
        Me.dtpSigningDate = New System.Windows.Forms.DateTimePicker()
        Me.txtSoW = New System.Windows.Forms.TextBox()
        Me.lblCustId = New System.Windows.Forms.Label()
        Me.txtContractID = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.gbxBrowse.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.gbxDetail.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(4, 1)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(1113, 66)
        Me.gbxBrowse.TabIndex = 39
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(1023, 15)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(940, 15)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(865, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Location = New System.Drawing.Point(11, 134)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(79, 13)
        Me.lblFax.TabIndex = 39
        Me.lblFax.Text = "Scope of Work"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(10, 111)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(61, 13)
        Me.lblPhone.TabIndex = 38
        Me.lblPhone.Text = "Expiry Date"
        '
        'lblNam
        '
        Me.lblNam.AutoSize = True
        Me.lblNam.Location = New System.Drawing.Point(10, 60)
        Me.lblNam.Name = "lblNam"
        Me.lblNam.Size = New System.Drawing.Size(68, 13)
        Me.lblNam.TabIndex = 36
        Me.lblNam.Text = "Signing Date"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(10, 86)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(83, 13)
        Me.lblAddress.TabIndex = 37
        Me.lblAddress.Text = "Commencement"
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 378)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(1129, 22)
        Me.ssp.TabIndex = 41
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.txtDateofInv)
        Me.gbxDetail.Controls.Add(Me.cboCustomer)
        Me.gbxDetail.Controls.Add(Me.txtRemarks)
        Me.gbxDetail.Controls.Add(Me.txtRisk)
        Me.gbxDetail.Controls.Add(Me.cboModeOfPayment)
        Me.gbxDetail.Controls.Add(Me.txtLiability)
        Me.gbxDetail.Controls.Add(Me.cboTPL)
        Me.gbxDetail.Controls.Add(Me.cboForceMaj)
        Me.gbxDetail.Controls.Add(Me.txtCustomerWitness)
        Me.gbxDetail.Controls.Add(Me.txtCustomerAuth)
        Me.gbxDetail.Controls.Add(Me.cboCompanyWitness)
        Me.gbxDetail.Controls.Add(Me.cboCompanyAuth)
        Me.gbxDetail.Controls.Add(Me.Label12)
        Me.gbxDetail.Controls.Add(Me.Label11)
        Me.gbxDetail.Controls.Add(Me.Label10)
        Me.gbxDetail.Controls.Add(Me.Label9)
        Me.gbxDetail.Controls.Add(Me.Label8)
        Me.gbxDetail.Controls.Add(Me.Label7)
        Me.gbxDetail.Controls.Add(Me.Label6)
        Me.gbxDetail.Controls.Add(Me.Label5)
        Me.gbxDetail.Controls.Add(Me.Label4)
        Me.gbxDetail.Controls.Add(Me.Label3)
        Me.gbxDetail.Controls.Add(Me.Label2)
        Me.gbxDetail.Controls.Add(Me.Label1)
        Me.gbxDetail.Controls.Add(Me.dtpExpiry)
        Me.gbxDetail.Controls.Add(Me.dtpCommence)
        Me.gbxDetail.Controls.Add(Me.dtpSigningDate)
        Me.gbxDetail.Controls.Add(Me.lblFax)
        Me.gbxDetail.Controls.Add(Me.lblPhone)
        Me.gbxDetail.Controls.Add(Me.lblAddress)
        Me.gbxDetail.Controls.Add(Me.lblNam)
        Me.gbxDetail.Controls.Add(Me.txtSoW)
        Me.gbxDetail.Controls.Add(Me.lblCustId)
        Me.gbxDetail.Controls.Add(Me.txtContractID)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(4, 74)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(1115, 297)
        Me.gbxDetail.TabIndex = 40
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Details"
        '
        'txtDateofInv
        '
        Me.txtDateofInv.Location = New System.Drawing.Point(789, 151)
        Me.txtDateofInv.MaxLength = 50
        Me.txtDateofInv.Name = "txtDateofInv"
        Me.txtDateofInv.Size = New System.Drawing.Size(311, 20)
        Me.txtDateofInv.TabIndex = 81
        '
        'cboCustomer
        '
        Me.cboCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCustomer.FormattingEnabled = True
        Me.cboCustomer.Location = New System.Drawing.Point(789, 204)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.Size = New System.Drawing.Size(311, 21)
        Me.cboCustomer.TabIndex = 80
        '
        'txtRemarks
        '
        Me.txtRemarks.Location = New System.Drawing.Point(789, 178)
        Me.txtRemarks.MaxLength = 50
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(311, 20)
        Me.txtRemarks.TabIndex = 79
        '
        'txtRisk
        '
        Me.txtRisk.Location = New System.Drawing.Point(789, 126)
        Me.txtRisk.MaxLength = 255
        Me.txtRisk.Name = "txtRisk"
        Me.txtRisk.Size = New System.Drawing.Size(311, 20)
        Me.txtRisk.TabIndex = 77
        '
        'cboModeOfPayment
        '
        Me.cboModeOfPayment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboModeOfPayment.FormattingEnabled = True
        Me.cboModeOfPayment.Items.AddRange(New Object() {"Cross Cheque in PKR", "Cross Cheque in USD", "Cross Cheque in Other", "DD in PKR", "DD in USD", "DD in Other", "Cash in PKR", "Other", ""})
        Me.cboModeOfPayment.Location = New System.Drawing.Point(789, 99)
        Me.cboModeOfPayment.Name = "cboModeOfPayment"
        Me.cboModeOfPayment.Size = New System.Drawing.Size(311, 21)
        Me.cboModeOfPayment.TabIndex = 76
        '
        'txtLiability
        '
        Me.txtLiability.Location = New System.Drawing.Point(789, 73)
        Me.txtLiability.MaxLength = 7
        Me.txtLiability.Name = "txtLiability"
        Me.txtLiability.Size = New System.Drawing.Size(311, 20)
        Me.txtLiability.TabIndex = 75
        '
        'cboTPL
        '
        Me.cboTPL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTPL.FormattingEnabled = True
        Me.cboTPL.Items.AddRange(New Object() {"Yes", "No", ""})
        Me.cboTPL.Location = New System.Drawing.Point(789, 46)
        Me.cboTPL.Name = "cboTPL"
        Me.cboTPL.Size = New System.Drawing.Size(311, 21)
        Me.cboTPL.TabIndex = 74
        '
        'cboForceMaj
        '
        Me.cboForceMaj.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboForceMaj.FormattingEnabled = True
        Me.cboForceMaj.Items.AddRange(New Object() {"Yes", "No", ""})
        Me.cboForceMaj.Location = New System.Drawing.Point(789, 19)
        Me.cboForceMaj.Name = "cboForceMaj"
        Me.cboForceMaj.Size = New System.Drawing.Size(311, 21)
        Me.cboForceMaj.TabIndex = 73
        '
        'txtCustomerWitness
        '
        Me.txtCustomerWitness.Location = New System.Drawing.Point(205, 237)
        Me.txtCustomerWitness.MaxLength = 50
        Me.txtCustomerWitness.Name = "txtCustomerWitness"
        Me.txtCustomerWitness.Size = New System.Drawing.Size(311, 20)
        Me.txtCustomerWitness.TabIndex = 72
        '
        'txtCustomerAuth
        '
        Me.txtCustomerAuth.Location = New System.Drawing.Point(205, 211)
        Me.txtCustomerAuth.MaxLength = 50
        Me.txtCustomerAuth.Name = "txtCustomerAuth"
        Me.txtCustomerAuth.Size = New System.Drawing.Size(311, 20)
        Me.txtCustomerAuth.TabIndex = 71
        '
        'cboCompanyWitness
        '
        Me.cboCompanyWitness.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCompanyWitness.FormattingEnabled = True
        Me.cboCompanyWitness.Location = New System.Drawing.Point(205, 184)
        Me.cboCompanyWitness.Name = "cboCompanyWitness"
        Me.cboCompanyWitness.Size = New System.Drawing.Size(311, 21)
        Me.cboCompanyWitness.TabIndex = 70
        '
        'cboCompanyAuth
        '
        Me.cboCompanyAuth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCompanyAuth.FormattingEnabled = True
        Me.cboCompanyAuth.Location = New System.Drawing.Point(205, 157)
        Me.cboCompanyAuth.Name = "cboCompanyAuth"
        Me.cboCompanyAuth.Size = New System.Drawing.Size(311, 21)
        Me.cboCompanyAuth.TabIndex = 69
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(595, 207)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(51, 13)
        Me.Label12.TabIndex = 67
        Me.Label12.Text = "Customer"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(594, 181)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(49, 13)
        Me.Label11.TabIndex = 66
        Me.Label11.Text = "Remarks"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(595, 158)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 13)
        Me.Label10.TabIndex = 65
        Me.Label10.Text = "Date of Invoice"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(595, 129)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(75, 13)
        Me.Label9.TabIndex = 64
        Me.Label9.Text = "Risk Exposure"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(595, 102)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(90, 13)
        Me.Label8.TabIndex = 63
        Me.Label8.Text = "Mode of Payment"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(595, 76)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 13)
        Me.Label7.TabIndex = 62
        Me.Label7.Text = "Liability"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(594, 49)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(169, 13)
        Me.Label6.TabIndex = 61
        Me.Label6.Text = "Third Party Liability Indemnification"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(595, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 13)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "Force Majeure"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 240)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 13)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "Customer Witness"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 214)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(133, 13)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "Customer Signing Authority"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 187)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 13)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "Company Witness"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 160)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(133, 13)
        Me.Label1.TabIndex = 56
        Me.Label1.Text = "Company Signing Authority"
        '
        'dtpExpiry
        '
        Me.dtpExpiry.Location = New System.Drawing.Point(205, 105)
        Me.dtpExpiry.Name = "dtpExpiry"
        Me.dtpExpiry.Size = New System.Drawing.Size(311, 20)
        Me.dtpExpiry.TabIndex = 55
        '
        'dtpCommence
        '
        Me.dtpCommence.Location = New System.Drawing.Point(205, 80)
        Me.dtpCommence.Name = "dtpCommence"
        Me.dtpCommence.Size = New System.Drawing.Size(311, 20)
        Me.dtpCommence.TabIndex = 54
        '
        'dtpSigningDate
        '
        Me.dtpSigningDate.Location = New System.Drawing.Point(205, 54)
        Me.dtpSigningDate.Name = "dtpSigningDate"
        Me.dtpSigningDate.Size = New System.Drawing.Size(311, 20)
        Me.dtpSigningDate.TabIndex = 53
        '
        'txtSoW
        '
        Me.txtSoW.Location = New System.Drawing.Point(205, 131)
        Me.txtSoW.MaxLength = 255
        Me.txtSoW.Name = "txtSoW"
        Me.txtSoW.Size = New System.Drawing.Size(311, 20)
        Me.txtSoW.TabIndex = 4
        '
        'lblCustId
        '
        Me.lblCustId.AutoSize = True
        Me.lblCustId.Location = New System.Drawing.Point(10, 30)
        Me.lblCustId.Name = "lblCustId"
        Me.lblCustId.Size = New System.Drawing.Size(61, 13)
        Me.lblCustId.TabIndex = 13
        Me.lblCustId.Text = "Contract ID"
        '
        'txtContractID
        '
        Me.txtContractID.Location = New System.Drawing.Point(205, 27)
        Me.txtContractID.MaxLength = 50
        Me.txtContractID.Name = "txtContractID"
        Me.txtContractID.Size = New System.Drawing.Size(311, 20)
        Me.txtContractID.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(1023, 253)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(940, 252)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'frmContract
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1129, 400)
        Me.Controls.Add(Me.gbxBrowse)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxDetail)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmContract"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmContract"
        Me.gbxBrowse.ResumeLayout(False)
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub





    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox

    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents lblNam As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel




    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox





    Friend WithEvents txtSoW As System.Windows.Forms.TextBox



    Friend WithEvents lblCustId As System.Windows.Forms.Label
    Friend WithEvents txtContractID As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents dtpExpiry As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpCommence As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpSigningDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label

    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtLiability As System.Windows.Forms.TextBox
    Friend WithEvents cboTPL As System.Windows.Forms.ComboBox
    Friend WithEvents cboForceMaj As System.Windows.Forms.ComboBox
    Friend WithEvents txtCustomerWitness As System.Windows.Forms.TextBox
    Friend WithEvents txtCustomerAuth As System.Windows.Forms.TextBox
    Friend WithEvents cboCompanyWitness As System.Windows.Forms.ComboBox
    Friend WithEvents cboCompanyAuth As System.Windows.Forms.ComboBox

    Friend WithEvents cboCustomer As System.Windows.Forms.ComboBox
    Friend WithEvents txtRemarks As System.Windows.Forms.TextBox

    Friend WithEvents txtRisk As System.Windows.Forms.TextBox
    Friend WithEvents cboModeOfPayment As System.Windows.Forms.ComboBox
    Friend WithEvents txtDateofInv As System.Windows.Forms.TextBox
End Class
