﻿Public Class frmPromotion

    Private dtbrowse, dtEmp, dtDesig As DataTable
    Private dbms As DML

    Private Sub frmPromotion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            dbms = New DML()
            Dim str As String
            str = "SELECT tblPromotion.PromoId + ' : ' + tblEmployee.FName + ' ' +tblEmployee.LName+ ' : ' +tblDesignation.Description as Expr1, tblPromotion.PromoId, tblPromotion.EmpId, tblPromotion.DesigId, tblPromotion.DateOfPromotion, tblPromotion.Remarks, tblPromotion.SpecialAllowance"
            str = str & " FROM tblPromotion INNER JOIN"
            str = str & " tblDesignation ON tblPromotion.DesigId = tblDesignation.DesigId INNER JOIN"
            str = str & " tblEmployee ON tblPromotion.EmpId = tblEmployee.EmpId"
            dtbrowse = dbms.getDataTable(str)

            dtEmp = dbms.getDataTable("Select EmpId,EmpId+' : '+FName+''+LName as Expr1 from tblEmployee")
            dtDesig = dbms.getDataTable("Select DesigId,DesigId+' : '+Description as Expr1 from tblDesignation")

            Me.cboEmployee.DataSource = dtEmp
            Me.cboEmployee.DisplayMember = "Expr1"
            Me.cboEmployee.ValueMember = "EmpId"

            Me.cboDesignation.DataSource = dtDesig
            Me.cboDesignation.DisplayMember = "Expr1"
            Me.cboDesignation.ValueMember = "DesigId"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("PromoId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "PromoId"

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow

        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtPromoId.Text = dr("PromoId")
                Me.cboEmployee.SelectedValue = "" & dr("EmpId")
                Me.cboDesignation.SelectedValue = "" & dr("DesigId")
                Me.dtpWEF.Text = dr("DateOfPromotion")
                Me.txtRemarks.Text = dr("Remarks")
                Me.txtSpecialAllowance.Text = dr("SpecialAllowance")

                Me.gbxDetail.Enabled = True
                Me.txtPromoId.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtPromoId.Text = ""
                Me.txtRemarks.Text = ""
                Me.cboEmployee.Text = ""
                Me.txtSpecialAllowance.Text = ""
                Me.dtpWEF.Text = Today
                Me.cboDesignation.Text = ""

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("PromoId")
            Me.txtPromoId.Text = "" & SBUID
            Me.cboEmployee.Text = ""
            Me.cboDesignation.Text = ""
            Me.dtpWEF.Text = Today
            Me.txtRemarks.Text = ""
            Me.txtSpecialAllowance.Text = ""

            Me.gbxDetail.Enabled = True
            Me.txtPromoId.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("Update tblPromotion Set EmpId='" & Me.cboEmployee.SelectedValue & "', DesigId='" & Me.cboDesignation.SelectedValue & "',DateOfPromotion='" & Me.dtpWEF.Value & "',Remarks='" & Me.txtRemarks.Text & "',SpecialAllowance=" & Me.txtSpecialAllowance.Text & " where PromoId='" & Me.txtPromoId.Text & "'")
                Else
                    dbms.execSql("Insert into tblPromotion (PromoId,EmpId,DesigId,DateOfPromotion,Remarks,SpecialAllowance) values ('" & Me.txtPromoId.Text & "','" & Me.cboEmployee.SelectedValue & "','" & Me.cboDesignation.SelectedValue & "','" & Me.dtpWEF.Value & "','" & Me.txtRemarks.Text & "'," & Me.txtSpecialAllowance.Text & ")")
                End If
                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        frmPromotion_Load(Nothing, Nothing)
    End Sub

    Private Sub txtRemarks_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtRemarks.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 65 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 97 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub txtSpecialAllowance_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSpecialAllowance.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtRemarks_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRemarks.TextChanged

    End Sub
End Class