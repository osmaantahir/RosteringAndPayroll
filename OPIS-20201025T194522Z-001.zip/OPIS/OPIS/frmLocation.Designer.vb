﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLocation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtDesc = New System.Windows.Forms.TextBox()
        Me.cboOffice = New System.Windows.Forms.ComboBox()
        Me.cboContract = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblNam = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.lblCustId = New System.Windows.Forms.Label()
        Me.txtLocID = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.txtFax = New System.Windows.Forms.TextBox()
        Me.txtContactPerson = New System.Windows.Forms.TextBox()
        Me.txtAdd = New System.Windows.Forms.TextBox()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.gbxDetail.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.gbxBrowse.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(145, 184)
        Me.txtEmail.MaxLength = 50
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(311, 20)
        Me.txtEmail.TabIndex = 72
        '
        'txtDesc
        '
        Me.txtDesc.Location = New System.Drawing.Point(145, 52)
        Me.txtDesc.MaxLength = 50
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(311, 20)
        Me.txtDesc.TabIndex = 71
        '
        'cboOffice
        '
        Me.cboOffice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOffice.FormattingEnabled = True
        Me.cboOffice.Location = New System.Drawing.Point(145, 237)
        Me.cboOffice.Name = "cboOffice"
        Me.cboOffice.Size = New System.Drawing.Size(311, 21)
        Me.cboOffice.TabIndex = 70
        '
        'cboContract
        '
        Me.cboContract.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboContract.FormattingEnabled = True
        Me.cboContract.Location = New System.Drawing.Point(145, 78)
        Me.cboContract.Name = "cboContract"
        Me.cboContract.Size = New System.Drawing.Size(311, 21)
        Me.cboContract.TabIndex = 69
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 240)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "Office"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 13)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "Description"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 187)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "Email"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 160)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 13)
        Me.Label1.TabIndex = 56
        Me.Label1.Text = "Fax"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Location = New System.Drawing.Point(11, 134)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(38, 13)
        Me.lblFax.TabIndex = 39
        Me.lblFax.Text = "Phone"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(10, 111)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(80, 13)
        Me.lblPhone.TabIndex = 38
        Me.lblPhone.Text = "Contact Person"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(10, 86)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(47, 13)
        Me.lblAddress.TabIndex = 37
        Me.lblAddress.Text = "Contract"
        '
        'lblNam
        '
        Me.lblNam.AutoSize = True
        Me.lblNam.Location = New System.Drawing.Point(12, 213)
        Me.lblNam.Name = "lblNam"
        Me.lblNam.Size = New System.Drawing.Size(45, 13)
        Me.lblNam.TabIndex = 36
        Me.lblNam.Text = "Address"
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(145, 131)
        Me.txtPhone.MaxLength = 255
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(311, 20)
        Me.txtPhone.TabIndex = 4
        '
        'lblCustId
        '
        Me.lblCustId.AutoSize = True
        Me.lblCustId.Location = New System.Drawing.Point(12, 30)
        Me.lblCustId.Name = "lblCustId"
        Me.lblCustId.Size = New System.Drawing.Size(62, 13)
        Me.lblCustId.TabIndex = 13
        Me.lblCustId.Text = "Location ID"
        '
        'txtLocID
        '
        Me.txtLocID.Location = New System.Drawing.Point(145, 27)
        Me.txtLocID.MaxLength = 50
        Me.txtLocID.Name = "txtLocID"
        Me.txtLocID.Size = New System.Drawing.Size(311, 20)
        Me.txtLocID.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(605, 252)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.txtFax)
        Me.gbxDetail.Controls.Add(Me.txtContactPerson)
        Me.gbxDetail.Controls.Add(Me.txtAdd)
        Me.gbxDetail.Controls.Add(Me.txtEmail)
        Me.gbxDetail.Controls.Add(Me.txtDesc)
        Me.gbxDetail.Controls.Add(Me.cboOffice)
        Me.gbxDetail.Controls.Add(Me.cboContract)
        Me.gbxDetail.Controls.Add(Me.Label4)
        Me.gbxDetail.Controls.Add(Me.Label3)
        Me.gbxDetail.Controls.Add(Me.Label2)
        Me.gbxDetail.Controls.Add(Me.Label1)
        Me.gbxDetail.Controls.Add(Me.lblFax)
        Me.gbxDetail.Controls.Add(Me.lblPhone)
        Me.gbxDetail.Controls.Add(Me.lblAddress)
        Me.gbxDetail.Controls.Add(Me.lblNam)
        Me.gbxDetail.Controls.Add(Me.txtPhone)
        Me.gbxDetail.Controls.Add(Me.lblCustId)
        Me.gbxDetail.Controls.Add(Me.txtLocID)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(4, 74)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(693, 297)
        Me.gbxDetail.TabIndex = 43
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Details"
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(145, 157)
        Me.txtFax.MaxLength = 50
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(311, 20)
        Me.txtFax.TabIndex = 75
        '
        'txtContactPerson
        '
        Me.txtContactPerson.Location = New System.Drawing.Point(145, 105)
        Me.txtContactPerson.MaxLength = 50
        Me.txtContactPerson.Name = "txtContactPerson"
        Me.txtContactPerson.Size = New System.Drawing.Size(311, 20)
        Me.txtContactPerson.TabIndex = 74
        '
        'txtAdd
        '
        Me.txtAdd.Location = New System.Drawing.Point(145, 210)
        Me.txtAdd.MaxLength = 255
        Me.txtAdd.Name = "txtAdd"
        Me.txtAdd.Size = New System.Drawing.Size(311, 20)
        Me.txtAdd.TabIndex = 73
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(522, 252)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(605, 15)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(522, 15)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(510, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 379)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(709, 22)
        Me.ssp.TabIndex = 44
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(4, 1)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(693, 66)
        Me.gbxBrowse.TabIndex = 42
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'frmLocation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(709, 401)
        Me.Controls.Add(Me.gbxDetail)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxBrowse)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLocation"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmLocation"
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxBrowse.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub








    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents cboOffice As System.Windows.Forms.ComboBox
    Friend WithEvents cboContract As System.Windows.Forms.ComboBox








    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label



    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblNam As System.Windows.Forms.Label
    Friend WithEvents txtPhone As System.Windows.Forms.TextBox
    Friend WithEvents lblCustId As System.Windows.Forms.Label
    Friend WithEvents txtLocID As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtContactPerson As System.Windows.Forms.TextBox
    Friend WithEvents txtAdd As System.Windows.Forms.TextBox
End Class
