﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDesignation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.gbxEmployee = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.txtSDesc = New System.Windows.Forms.TextBox()
        Me.dgvSalaryBreakUp = New System.Windows.Forms.DataGridView()
        Me.cboBillable = New System.Windows.Forms.ComboBox()
        Me.lblBillable = New System.Windows.Forms.Label()
        Me.lblDesc = New System.Windows.Forms.Label()
        Me.lblDesigID = New System.Windows.Forms.Label()
        Me.txtDesc = New System.Windows.Forms.TextBox()
        Me.txtDesigId = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.cboDutyHrs = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.gbxBrowse.SuspendLayout()
        Me.gbxEmployee.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgvSalaryBreakUp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ssp.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(4, 2)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(651, 69)
        Me.gbxBrowse.TabIndex = 0
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(556, 19)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(475, 19)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(450, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'gbxEmployee
        '
        Me.gbxEmployee.Controls.Add(Me.Label4)
        Me.gbxEmployee.Controls.Add(Me.cboDutyHrs)
        Me.gbxEmployee.Controls.Add(Me.GroupBox1)
        Me.gbxEmployee.Controls.Add(Me.cboBillable)
        Me.gbxEmployee.Controls.Add(Me.lblBillable)
        Me.gbxEmployee.Controls.Add(Me.lblDesc)
        Me.gbxEmployee.Controls.Add(Me.lblDesigID)
        Me.gbxEmployee.Controls.Add(Me.txtDesc)
        Me.gbxEmployee.Controls.Add(Me.txtDesigId)
        Me.gbxEmployee.Controls.Add(Me.cmdCancel)
        Me.gbxEmployee.Controls.Add(Me.cmdSave)
        Me.gbxEmployee.Location = New System.Drawing.Point(4, 77)
        Me.gbxEmployee.Name = "gbxEmployee"
        Me.gbxEmployee.Size = New System.Drawing.Size(651, 452)
        Me.gbxEmployee.TabIndex = 1
        Me.gbxEmployee.TabStop = False
        Me.gbxEmployee.Text = "Employee Details"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnEdit)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.btnRemove)
        Me.GroupBox1.Controls.Add(Me.btnAdd)
        Me.GroupBox1.Controls.Add(Me.cboStatus)
        Me.GroupBox1.Controls.Add(Me.txtAmount)
        Me.GroupBox1.Controls.Add(Me.txtSDesc)
        Me.GroupBox1.Controls.Add(Me.dgvSalaryBreakUp)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 136)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(620, 274)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Salary Break Up"
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(414, 72)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(200, 24)
        Me.btnEdit.TabIndex = 8
        Me.btnEdit.Text = "Edit in Grid"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(449, 25)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Allowance"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(263, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Amount"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Description"
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(212, 71)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(200, 24)
        Me.btnRemove.TabIndex = 7
        Me.btnRemove.Text = "Remove from Grid"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(6, 72)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(200, 23)
        Me.btnAdd.TabIndex = 6
        Me.btnAdd.Text = "Add to Grid"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'cboStatus
        '
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Items.AddRange(New Object() {"Basic", "Allowance", "Deduction", ""})
        Me.cboStatus.Location = New System.Drawing.Point(452, 41)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(162, 21)
        Me.cboStatus.TabIndex = 5
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(266, 42)
        Me.txtAmount.MaxLength = 6
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(177, 20)
        Me.txtAmount.TabIndex = 4
        '
        'txtSDesc
        '
        Me.txtSDesc.Location = New System.Drawing.Point(6, 41)
        Me.txtSDesc.MaxLength = 50
        Me.txtSDesc.Name = "txtSDesc"
        Me.txtSDesc.Size = New System.Drawing.Size(254, 20)
        Me.txtSDesc.TabIndex = 3
        '
        'dgvSalaryBreakUp
        '
        Me.dgvSalaryBreakUp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSalaryBreakUp.Location = New System.Drawing.Point(6, 102)
        Me.dgvSalaryBreakUp.Name = "dgvSalaryBreakUp"
        Me.dgvSalaryBreakUp.Size = New System.Drawing.Size(608, 166)
        Me.dgvSalaryBreakUp.TabIndex = 9
        '
        'cboBillable
        '
        Me.cboBillable.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBillable.FormattingEnabled = True
        Me.cboBillable.Items.AddRange(New Object() {"Yes", "No", ""})
        Me.cboBillable.Location = New System.Drawing.Point(115, 79)
        Me.cboBillable.Name = "cboBillable"
        Me.cboBillable.Size = New System.Drawing.Size(341, 21)
        Me.cboBillable.TabIndex = 3
        '
        'lblBillable
        '
        Me.lblBillable.AutoSize = True
        Me.lblBillable.Location = New System.Drawing.Point(10, 86)
        Me.lblBillable.Name = "lblBillable"
        Me.lblBillable.Size = New System.Drawing.Size(40, 13)
        Me.lblBillable.TabIndex = 15
        Me.lblBillable.Text = "Billable"
        '
        'lblDesc
        '
        Me.lblDesc.AutoSize = True
        Me.lblDesc.Location = New System.Drawing.Point(10, 60)
        Me.lblDesc.Name = "lblDesc"
        Me.lblDesc.Size = New System.Drawing.Size(60, 13)
        Me.lblDesc.TabIndex = 14
        Me.lblDesc.Text = "Description"
        '
        'lblDesigID
        '
        Me.lblDesigID.AutoSize = True
        Me.lblDesigID.Location = New System.Drawing.Point(10, 34)
        Me.lblDesigID.Name = "lblDesigID"
        Me.lblDesigID.Size = New System.Drawing.Size(77, 13)
        Me.lblDesigID.TabIndex = 13
        Me.lblDesigID.Text = "Designation ID"
        '
        'txtDesc
        '
        Me.txtDesc.Location = New System.Drawing.Point(115, 53)
        Me.txtDesc.MaxLength = 50
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.Size = New System.Drawing.Size(341, 20)
        Me.txtDesc.TabIndex = 2
        '
        'txtDesigId
        '
        Me.txtDesigId.Location = New System.Drawing.Point(115, 27)
        Me.txtDesigId.MaxLength = 50
        Me.txtDesigId.Name = "txtDesigId"
        Me.txtDesigId.Size = New System.Drawing.Size(341, 20)
        Me.txtDesigId.TabIndex = 1
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(556, 410)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 6
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(475, 409)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 5
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 543)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(669, 22)
        Me.ssp.TabIndex = 32
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'cboDutyHrs
        '
        Me.cboDutyHrs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDutyHrs.FormattingEnabled = True
        Me.cboDutyHrs.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"})
        Me.cboDutyHrs.Location = New System.Drawing.Point(115, 106)
        Me.cboDutyHrs.Name = "cboDutyHrs"
        Me.cboDutyHrs.Size = New System.Drawing.Size(341, 21)
        Me.cboDutyHrs.TabIndex = 16
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 111)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Daily Duty Hours"
        '
        'frmDesignation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(669, 565)
        Me.Controls.Add(Me.gbxBrowse)
        Me.Controls.Add(Me.gbxEmployee)
        Me.Controls.Add(Me.ssp)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDesignation"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Designation"
        Me.gbxBrowse.ResumeLayout(False)
        Me.gbxEmployee.ResumeLayout(False)
        Me.gbxEmployee.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dgvSalaryBreakUp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox
    Friend WithEvents gbxEmployee As System.Windows.Forms.GroupBox



    Friend WithEvents cboBillable As System.Windows.Forms.ComboBox










    Friend WithEvents lblBillable As System.Windows.Forms.Label
    Friend WithEvents lblDesc As System.Windows.Forms.Label
    Friend WithEvents lblDesigID As System.Windows.Forms.Label





    Friend WithEvents txtDesc As System.Windows.Forms.TextBox
    Friend WithEvents txtDesigId As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dgvSalaryBreakUp As System.Windows.Forms.DataGridView
    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox
    Friend WithEvents txtAmount As System.Windows.Forms.TextBox
    Friend WithEvents txtSDesc As System.Windows.Forms.TextBox
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cboDutyHrs As System.Windows.Forms.ComboBox


End Class
