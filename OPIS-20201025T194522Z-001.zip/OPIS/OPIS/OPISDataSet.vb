﻿Partial Class OPISDataSet
    Partial Class qryCustomerDataTable

        Private Sub qryCustomerDataTable_ColumnChanging(ByVal sender As System.Object, ByVal e As System.Data.DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.CustIdColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class

End Class
