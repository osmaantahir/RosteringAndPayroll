﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEmployment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtpDoD = New System.Windows.Forms.DateTimePicker()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboEmp = New System.Windows.Forms.ComboBox()
        Me.lblRemarks = New System.Windows.Forms.Label()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.txtReason = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboAction = New System.Windows.Forms.ComboBox()
        Me.cboExitInterview = New System.Windows.Forms.ComboBox()
        Me.cboApproved = New System.Windows.Forms.ComboBox()
        Me.dtpDoJ = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblDoT = New System.Windows.Forms.Label()
        Me.lblOff = New System.Windows.Forms.Label()
        Me.lblEmp = New System.Windows.Forms.Label()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.lblTransferId = New System.Windows.Forms.Label()
        Me.txtEmploymentId = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.gbxDetail.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.gbxBrowse.SuspendLayout()
        Me.SuspendLayout()
        '
        'dtpDoD
        '
        Me.dtpDoD.Location = New System.Drawing.Point(153, 106)
        Me.dtpDoD.Name = "dtpDoD"
        Me.dtpDoD.Size = New System.Drawing.Size(273, 20)
        Me.dtpDoD.TabIndex = 48
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(556, 19)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(475, 19)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboEmp
        '
        Me.cboEmp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEmp.FormattingEnabled = True
        Me.cboEmp.Location = New System.Drawing.Point(153, 54)
        Me.cboEmp.Name = "cboEmp"
        Me.cboEmp.Size = New System.Drawing.Size(273, 21)
        Me.cboEmp.TabIndex = 46
        '
        'lblRemarks
        '
        Me.lblRemarks.AutoSize = True
        Me.lblRemarks.Location = New System.Drawing.Point(10, 138)
        Me.lblRemarks.Name = "lblRemarks"
        Me.lblRemarks.Size = New System.Drawing.Size(49, 13)
        Me.lblRemarks.TabIndex = 39
        Me.lblRemarks.Text = "Remarks"
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.txtReason)
        Me.gbxDetail.Controls.Add(Me.Label4)
        Me.gbxDetail.Controls.Add(Me.cboAction)
        Me.gbxDetail.Controls.Add(Me.cboExitInterview)
        Me.gbxDetail.Controls.Add(Me.cboApproved)
        Me.gbxDetail.Controls.Add(Me.dtpDoJ)
        Me.gbxDetail.Controls.Add(Me.Label3)
        Me.gbxDetail.Controls.Add(Me.Label2)
        Me.gbxDetail.Controls.Add(Me.Label1)
        Me.gbxDetail.Controls.Add(Me.dtpDoD)
        Me.gbxDetail.Controls.Add(Me.cboEmp)
        Me.gbxDetail.Controls.Add(Me.lblRemarks)
        Me.gbxDetail.Controls.Add(Me.lblDoT)
        Me.gbxDetail.Controls.Add(Me.lblOff)
        Me.gbxDetail.Controls.Add(Me.lblEmp)
        Me.gbxDetail.Controls.Add(Me.txtRemarks)
        Me.gbxDetail.Controls.Add(Me.lblTransferId)
        Me.gbxDetail.Controls.Add(Me.txtEmploymentId)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(6, 79)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(651, 289)
        Me.gbxDetail.TabIndex = 46
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Details"
        '
        'txtReason
        '
        Me.txtReason.Location = New System.Drawing.Point(153, 216)
        Me.txtReason.MaxLength = 255
        Me.txtReason.Name = "txtReason"
        Me.txtReason.Size = New System.Drawing.Size(273, 20)
        Me.txtReason.TabIndex = 57
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 219)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 13)
        Me.Label4.TabIndex = 56
        Me.Label4.Text = "Reason for Discharge"
        '
        'cboAction
        '
        Me.cboAction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAction.FormattingEnabled = True
        Me.cboAction.Items.AddRange(New Object() {"Breach of Code of Conduct", "Customer Complaint", "Punctuality", "Criminal Offense", "Breach of Information Security", "Industrial Espionage", ""})
        Me.cboAction.Location = New System.Drawing.Point(153, 243)
        Me.cboAction.Name = "cboAction"
        Me.cboAction.Size = New System.Drawing.Size(273, 21)
        Me.cboAction.TabIndex = 55
        '
        'cboExitInterview
        '
        Me.cboExitInterview.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboExitInterview.FormattingEnabled = True
        Me.cboExitInterview.Location = New System.Drawing.Point(153, 185)
        Me.cboExitInterview.Name = "cboExitInterview"
        Me.cboExitInterview.Size = New System.Drawing.Size(273, 21)
        Me.cboExitInterview.TabIndex = 54
        '
        'cboApproved
        '
        Me.cboApproved.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboApproved.FormattingEnabled = True
        Me.cboApproved.Location = New System.Drawing.Point(153, 158)
        Me.cboApproved.Name = "cboApproved"
        Me.cboApproved.Size = New System.Drawing.Size(273, 21)
        Me.cboApproved.TabIndex = 53
        '
        'dtpDoJ
        '
        Me.dtpDoJ.Location = New System.Drawing.Point(153, 79)
        Me.dtpDoJ.Name = "dtpDoJ"
        Me.dtpDoJ.Size = New System.Drawing.Size(273, 20)
        Me.dtpDoJ.TabIndex = 52
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 246)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 13)
        Me.Label3.TabIndex = 51
        Me.Label3.Text = "Disciplanary Action"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 188)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 13)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Exit Interview By"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 161)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 13)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "Employment Approved By"
        '
        'lblDoT
        '
        Me.lblDoT.AutoSize = True
        Me.lblDoT.Location = New System.Drawing.Point(10, 112)
        Me.lblDoT.Name = "lblDoT"
        Me.lblDoT.Size = New System.Drawing.Size(95, 13)
        Me.lblDoT.TabIndex = 38
        Me.lblDoT.Text = "Date Of Discharge"
        '
        'lblOff
        '
        Me.lblOff.AutoSize = True
        Me.lblOff.Location = New System.Drawing.Point(10, 86)
        Me.lblOff.Name = "lblOff"
        Me.lblOff.Size = New System.Drawing.Size(78, 13)
        Me.lblOff.TabIndex = 37
        Me.lblOff.Text = "Date of Joining"
        '
        'lblEmp
        '
        Me.lblEmp.AutoSize = True
        Me.lblEmp.Location = New System.Drawing.Point(10, 60)
        Me.lblEmp.Name = "lblEmp"
        Me.lblEmp.Size = New System.Drawing.Size(53, 13)
        Me.lblEmp.TabIndex = 36
        Me.lblEmp.Text = "Employee"
        '
        'txtRemarks
        '
        Me.txtRemarks.Location = New System.Drawing.Point(153, 131)
        Me.txtRemarks.MaxLength = 255
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(273, 20)
        Me.txtRemarks.TabIndex = 4
        '
        'lblTransferId
        '
        Me.lblTransferId.AutoSize = True
        Me.lblTransferId.Location = New System.Drawing.Point(10, 34)
        Me.lblTransferId.Name = "lblTransferId"
        Me.lblTransferId.Size = New System.Drawing.Size(78, 13)
        Me.lblTransferId.TabIndex = 13
        Me.lblTransferId.Text = "Employment ID"
        '
        'txtEmploymentId
        '
        Me.txtEmploymentId.Location = New System.Drawing.Point(153, 27)
        Me.txtEmploymentId.MaxLength = 50
        Me.txtEmploymentId.Name = "txtEmploymentId"
        Me.txtEmploymentId.Size = New System.Drawing.Size(273, 20)
        Me.txtEmploymentId.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(556, 240)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(475, 240)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 405)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(664, 22)
        Me.ssp.TabIndex = 47
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(450, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(6, 5)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(651, 66)
        Me.gbxBrowse.TabIndex = 45
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'frmEmployment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(664, 427)
        Me.Controls.Add(Me.gbxDetail)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxBrowse)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmEmployment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmEmployment"
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxBrowse.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dtpDoD As System.Windows.Forms.DateTimePicker

    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboEmp As System.Windows.Forms.ComboBox
    Friend WithEvents lblRemarks As System.Windows.Forms.Label
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox
    Friend WithEvents lblDoT As System.Windows.Forms.Label
    Friend WithEvents lblOff As System.Windows.Forms.Label
    Friend WithEvents lblEmp As System.Windows.Forms.Label
    Friend WithEvents txtRemarks As System.Windows.Forms.TextBox
    Friend WithEvents lblTransferId As System.Windows.Forms.Label
    Friend WithEvents txtEmploymentId As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboAction As System.Windows.Forms.ComboBox
    Friend WithEvents cboExitInterview As System.Windows.Forms.ComboBox
    Friend WithEvents cboApproved As System.Windows.Forms.ComboBox
    Friend WithEvents dtpDoJ As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtReason As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
