﻿Public Class frmAttendance
    Private dtoffice, dtemp, dtgrid, dtstatus, dtdeploy, dtLeaves As DataTable
    Public strstatus, strdeploy, strfrom, strto As String
    Private dbms As DML

    Private Sub frmAttendance_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbms = New DML
        dtoffice = dbms.getDataTable("Select '['+OfficeId+'] '+Description as expr1,officeid from tbloffice")
        With cboOffice
            .DataSource = dtoffice
            .DisplayMember = "expr1"
            .ValueMember = "Officeid"
        End With
        cmdGo.Enabled = True
        gbxdetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim str As String

        str = "SELECT dbo.tblTransfer.EmpId, dbo.tblTransfer.OfficeId, dbo.tblEmployee.FName, dbo.tblEmployee.LName"
        str = str & " FROM dbo.tblTransfer INNER JOIN"
        str = str & " dbo.tblEmployee ON dbo.tblTransfer.EmpId = dbo.tblEmployee.EmpId"
        str = str & " WHERE dbo.tblTransfer.TransferId IN"
        str = str & " (SELECT MAX(DISTINCT TransferId) AS Expr1"
        str = str & " FROM dbo.tblTransfer AS tblTransfer_1"
        str = str & " GROUP BY EmpId) and dbo.tblTransfer.OfficeId='" & Me.cboOffice.SelectedValue & "'"

        dtemp = dbms.getDataTable(str)

        dtstatus = dbms.getDataTable("Select StatusId+':'+Description+':'+Payable as expr1 from tblStatus")

        str = "SELECT dbo.tblDeployment.DeployID + ':' + dbo.tblDeployment.Remarks + ':' + dbo.tblPosts.PostNumber + ':' + dbo.tblLocations.LocationId + ':' + dbo.tblLocations.Description"
        str = str & " + ':' + dbo.tblLocations.OfficeId AS Expr1"
        str = str & " FROM dbo.tblDeployment INNER JOIN"
        str = str & " dbo.tblPosts ON dbo.tblDeployment.PostId = dbo.tblPosts.PostId INNER JOIN"
        str = str & " dbo.tblLocations ON dbo.tblPosts.LocationId = dbo.tblLocations.LocationId"
        str = str & " Where dbo.tblLocations.OfficeId='" & Me.cboOffice.SelectedValue & "'"

        dtdeploy = dbms.getDataTable(str)

        dtgrid = New DataTable("AttendGrid")

        dtgrid.Columns.Add("Emp")
        dtgrid.Columns.Add("Adate")
        dtgrid.Columns.Add("TimeFrom")
        dtgrid.Columns.Add("TimeTo")
        dtgrid.Columns.Add("Status")
        dtgrid.Columns.Add("Deploy")

        dgv.DataSource = dtgrid
        dgv.DefaultCellStyle.WrapMode = DataGridViewTriState.True
        Me.dgv.AllowUserToResizeRows = False
        dgv.Columns(0).MinimumWidth = 100
        dgv.Columns(1).MinimumWidth = 100
        dgv.Columns(2).MinimumWidth = 100
        dgv.Columns(3).MinimumWidth = 100
        dgv.Columns(4).MinimumWidth = 100
        dgv.Columns(5).MinimumWidth = 250

        Dim i As Integer
        Dim st(5) As String

        For i = 0 To dtemp.Rows.Count - 1
            st(0) = "" & dtemp.Rows(i)(0) & " " & vbCrLf & dtemp.Rows(i)(2) & vbCrLf & dtemp.Rows(i)(3)
            st(1) = dtp.Value.Date

            dtLeaves = dbms.getDataTable("Select * from tblLeaves where (EmpId='" & dtemp.Rows(i)(0) & "') and ('" & Me.dtp.Value & "' BETWEEN DateFrom and DateTo)")

            If dtLeaves.Rows.Count > 0 Then
                st(2) = "" & Me.dtp.Value
                st(3) = "" & Me.dtp.Value
                st(4) = "" & dtLeaves.Rows(0)("StatusId")
                st(5) = ""

            End If

            dtgrid.Rows.Add(st)

            If dtLeaves.Rows.Count > 0 Then
                dgv.Item(2, i).Style.BackColor = Color.LightGreen
                dgv.Item(3, i).Style.BackColor = Color.LightGreen
                dgv.Item(4, i).Style.BackColor = Color.LightGreen
                dgv.Item(5, i).Style.BackColor = Color.LightGreen
                dtLeaves = Nothing
            End If

            dgv.Rows(i).MinimumHeight = 55
            dgv.Item(0, i).Style.BackColor = Color.DarkGreen
            dgv.Item(0, i).Style.ForeColor = Color.White
            dgv.Item(1, i).Style.BackColor = Color.LightGreen
        Next i

        Me.gbxdetail.Enabled = True
        ssp.Items("Mode").Text = "EDITING MODE"
        Me.gbxBrowse.Enabled = False

    End Sub

    Private Sub dgv_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellDoubleClick

        If e.ColumnIndex <= 0 Or e.RowIndex >= dtgrid.Rows.Count Or e.RowIndex < 0 Then Exit Sub
        Dim dlg As frmPopupAtt
        Dim st() As String
        dlg = New frmPopupAtt("Duty Performed From", "Duty Performed Till", "Attendance Status", "Duty Performed at", dtstatus, dtdeploy)
        dlg.Owner = Me

        If dlg.ShowDialog() <> 1 Then Exit Sub

        dtgrid.Rows(e.RowIndex)(2) = strfrom

        dtgrid.Rows(e.RowIndex)(3) = strto

        st = Split(strstatus, ":")
        dtgrid.Rows(e.RowIndex)(4) = st(0) & " " & vbCrLf & st(1) & vbCrLf & st(2)

        st = Split(strdeploy, ":")
        dtgrid.Rows(e.RowIndex)(5) = st(0) & " " & st(1) & vbCrLf & st(2) & vbCrLf & "[" & st(3) & "] " & st(4)

        dgv.Item(2, e.RowIndex).Style.BackColor = Color.LightGreen
        dgv.Item(3, e.RowIndex).Style.BackColor = Color.LightGreen
        dgv.Item(4, e.RowIndex).Style.BackColor = Color.LightGreen
        dgv.Item(5, e.RowIndex).Style.BackColor = Color.LightGreen
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim st(), stDeploy, stStatus, StTo, stFrom, stAdate, stEmp, stAid As String
        Dim i, j, tempInt As Integer
        Dim SBUID As String
        Dim dttemp As DataTable

        For i = 0 To dtgrid.Rows.Count - 1
            If System.String.Compare(dtgrid.Rows(i)(4) & "", "") <> 1 Then
                MsgBox("Cannot Proceed to Save! " & vbCrLf & "Record is not entered at row=" & i + 1, MsgBoxStyle.OkOnly)
                Exit Sub
            End If
        Next i

        For i = 0 To dtgrid.Rows.Count - 1
            SBUID = dbms.generateId("AttendId")
            stAid = "" & SBUID
            st = Split(dtgrid.Rows(i)(0), " ")
            stEmp = st(0)
            stAdate = dtgrid.Rows(i)(1)
            stFrom = dtgrid.Rows(i)(2)
            StTo = dtgrid.Rows(i)(3)
            st = Split(dtgrid.Rows(i)(4), " ")
            stStatus = st(0)
            st = Split(dtgrid.Rows(i)(5), " ")
            stDeploy = st(0)
            dttemp = dbms.getDataTable("select * from tblAttendance where Adate='" & stAdate & "' and EmpId='" & stEmp & "'")
            For j = 0 To dttemp.Rows.Count - 1
                If TimeClash(stFrom, StTo, dttemp.Rows(j)("TimeFrom"), dttemp.Rows(j)("TimeTo")) = 1 Then
                    MsgBox("Time Clash in the Duty Timings!" & vbCrLf & "Employee=" & stEmp & vbCrLf & "You attempt to save [" & stFrom & " - " & StTo & "] " & vbCrLf & "Already Saved Duty Performed was [" & dttemp.Rows(j)("TimeFrom") & " - " & dttemp.Rows(j)("TimeTo") & "]", MsgBoxStyle.OkOnly)
                    If MsgBox("Do you want to replace this record with previously saved record?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                        dbms.execSql("UPDATE tblAttendance SET Adate='" & stAdate & "',EmpId='" & stEmp & "',TimeFrom='" & stFrom & "',TimeTo='" & StTo & "',StatusID='" & stStatus & "',DeployId='" & stDeploy & "' WHERE AttendanceId='" & dttemp.Rows(j)("AttendanceId") & "'")
                    Else
                        tempInt = 1
                    End If
                Else
                End If
            Next j
            If tempInt = 1 Then
                tempInt = 0
            Else
                dbms.execSql("INSERT INTO tblAttendance (AttendanceId,Adate,EmpId,TimeFrom,TimeTo,StatusID,DeployId) values ('" & stAid & "','" & stAdate & "','" & stEmp & "','" & stFrom & "','" & StTo & "','" & stStatus & "','" & stDeploy & "')")
                MsgBox("Records Successfully Saved!" & vbCrLf & "('" & stAid & "','" & stAdate & "','" & stEmp & "','" & stFrom & "','" & StTo & "','" & stStatus & "','" & stDeploy & "')", MsgBoxStyle.OkOnly)
            End If
        Next i

        Me.gbxBrowse.Enabled = True
        Me.gbxdetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
        dtgrid = Nothing
        dgv.DataSource = Nothing

    End Sub

    Private Function TimeClash(ByVal stFrom1 As String, ByVal stTo1 As String, ByVal stFrom2 As String, ByVal stTo2 As String) As Integer
        If System.DateTime.Compare(stFrom1, stFrom2) = 1 And System.DateTime.Compare(stFrom1, stTo2) = -1 Then
            Return 1
        ElseIf System.DateTime.Compare(stTo1, stFrom2) = 1 And System.DateTime.Compare(stTo1, stTo2) = -1 Then
            Return 1
        ElseIf System.DateTime.Compare(stFrom2, stFrom1) = 1 And System.DateTime.Compare(stFrom2, stTo1) = -1 Then
            Return 1
        ElseIf System.DateTime.Compare(stTo2, stFrom1) = 1 And System.DateTime.Compare(stTo2, stTo1) = -1 Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.gbxBrowse.Enabled = True
        Me.gbxdetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
        dtgrid = Nothing
        dgv.DataSource = Nothing
    End Sub
End Class