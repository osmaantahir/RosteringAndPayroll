﻿Module Connect

    Public dbms As New DML()
    Public Authorization As Boolean = False
    Public md As New MDI()
    Public User, Usertype As String


    Public Function generateId(ByVal str As String) As Integer
        Try
            Dim dt As DataTable
            Dim temp As Integer
            dt = dbms.getDataTable("Select " & str & " from tblSequence")
            temp = CType(dt.Rows(0).Item(0), Integer)
            dbms.execSql("Update tblsequence Set " & str & " = " & temp + 1)
            Return temp
        Catch ex As Exception
        End Try
    End Function

    Public Sub main()
        Dim hnd As New splash
        hnd.ShowDialog()
        Dim hnd1 As New Logon
        hnd1.ShowDialog()
        If Authorization Then
            md.ShowDialog()
        End If

    End Sub

End Module
