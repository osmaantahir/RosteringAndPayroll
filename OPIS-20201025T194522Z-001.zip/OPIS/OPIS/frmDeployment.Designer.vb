﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDeployment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.cboDesig = New System.Windows.Forms.ComboBox()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.dtpEnds = New System.Windows.Forms.DateTimePicker()
        Me.dtpStarts = New System.Windows.Forms.DateTimePicker()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.cboArmed = New System.Windows.Forms.ComboBox()
        Me.cboPost = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblCustId = New System.Windows.Forms.Label()
        Me.txtDeployID = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.txtRate = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ssp.SuspendLayout()
        Me.gbxDetail.SuspendLayout()
        Me.gbxBrowse.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(772, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 245)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(961, 22)
        Me.ssp.TabIndex = 50
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'cboDesig
        '
        Me.cboDesig.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDesig.FormattingEnabled = True
        Me.cboDesig.Items.AddRange(New Object() {"Guard", "Supervisor", "Officer", "Manager", "Lady Search", "Male Seach", "K-9 Handler", "Body Guard", "Commando", "Other", ""})
        Me.cboDesig.Location = New System.Drawing.Point(145, 78)
        Me.cboDesig.Name = "cboDesig"
        Me.cboDesig.Size = New System.Drawing.Size(311, 21)
        Me.cboDesig.TabIndex = 69
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(784, 15)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 13)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "Post"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Location = New System.Drawing.Point(11, 134)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(48, 13)
        Me.lblFax.TabIndex = 39
        Me.lblFax.Text = "Ends On"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(10, 111)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(60, 13)
        Me.lblPhone.TabIndex = 38
        Me.lblPhone.Text = "Starts From"
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(867, 15)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(12, 81)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(63, 13)
        Me.lblAddress.TabIndex = 37
        Me.lblAddress.Text = "Designation"
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.Label4)
        Me.gbxDetail.Controls.Add(Me.txtRate)
        Me.gbxDetail.Controls.Add(Me.dtpEnds)
        Me.gbxDetail.Controls.Add(Me.dtpStarts)
        Me.gbxDetail.Controls.Add(Me.txtRemarks)
        Me.gbxDetail.Controls.Add(Me.cboArmed)
        Me.gbxDetail.Controls.Add(Me.cboPost)
        Me.gbxDetail.Controls.Add(Me.Label2)
        Me.gbxDetail.Controls.Add(Me.Label1)
        Me.gbxDetail.Controls.Add(Me.cboDesig)
        Me.gbxDetail.Controls.Add(Me.Label3)
        Me.gbxDetail.Controls.Add(Me.lblFax)
        Me.gbxDetail.Controls.Add(Me.lblPhone)
        Me.gbxDetail.Controls.Add(Me.lblAddress)
        Me.gbxDetail.Controls.Add(Me.lblCustId)
        Me.gbxDetail.Controls.Add(Me.txtDeployID)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(-1, 73)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(950, 165)
        Me.gbxDetail.TabIndex = 49
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Details"
        '
        'dtpEnds
        '
        Me.dtpEnds.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpEnds.Location = New System.Drawing.Point(145, 131)
        Me.dtpEnds.Name = "dtpEnds"
        Me.dtpEnds.Size = New System.Drawing.Size(311, 20)
        Me.dtpEnds.TabIndex = 81
        '
        'dtpStarts
        '
        Me.dtpStarts.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpStarts.Location = New System.Drawing.Point(145, 105)
        Me.dtpStarts.Name = "dtpStarts"
        Me.dtpStarts.Size = New System.Drawing.Size(311, 20)
        Me.dtpStarts.TabIndex = 80
        '
        'txtRemarks
        '
        Me.txtRemarks.Location = New System.Drawing.Point(633, 23)
        Me.txtRemarks.MaxLength = 255
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(311, 20)
        Me.txtRemarks.TabIndex = 79
        '
        'cboArmed
        '
        Me.cboArmed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboArmed.FormattingEnabled = True
        Me.cboArmed.Items.AddRange(New Object() {"Yes", "No", ""})
        Me.cboArmed.Location = New System.Drawing.Point(633, 52)
        Me.cboArmed.Name = "cboArmed"
        Me.cboArmed.Size = New System.Drawing.Size(311, 21)
        Me.cboArmed.TabIndex = 78
        '
        'cboPost
        '
        Me.cboPost.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPost.FormattingEnabled = True
        Me.cboPost.Location = New System.Drawing.Point(145, 51)
        Me.cboPost.Name = "cboPost"
        Me.cboPost.Size = New System.Drawing.Size(311, 21)
        Me.cboPost.TabIndex = 77
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(500, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 13)
        Me.Label2.TabIndex = 76
        Me.Label2.Text = "Armed"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(500, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "Remarks"
        '
        'lblCustId
        '
        Me.lblCustId.AutoSize = True
        Me.lblCustId.Location = New System.Drawing.Point(12, 30)
        Me.lblCustId.Name = "lblCustId"
        Me.lblCustId.Size = New System.Drawing.Size(80, 13)
        Me.lblCustId.TabIndex = 13
        Me.lblCustId.Text = "Deploy/Shift ID"
        '
        'txtDeployID
        '
        Me.txtDeployID.Location = New System.Drawing.Point(145, 27)
        Me.txtDeployID.MaxLength = 50
        Me.txtDeployID.Name = "txtDeployID"
        Me.txtDeployID.Size = New System.Drawing.Size(311, 20)
        Me.txtDeployID.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(867, 123)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(784, 122)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(-1, 0)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(950, 66)
        Me.gbxBrowse.TabIndex = 48
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'txtRate
        '
        Me.txtRate.Location = New System.Drawing.Point(633, 81)
        Me.txtRate.MaxLength = 6
        Me.txtRate.Name = "txtRate"
        Me.txtRate.Size = New System.Drawing.Size(311, 20)
        Me.txtRate.TabIndex = 82
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(500, 84)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 13)
        Me.Label4.TabIndex = 83
        Me.Label4.Text = "Rate Of Service"
        '
        'frmDeployment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(961, 267)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxDetail)
        Me.Controls.Add(Me.gbxBrowse)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDeployment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmDeployment"
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.gbxBrowse.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox


    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents cboDesig As System.Windows.Forms.ComboBox
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox

    Friend WithEvents lblCustId As System.Windows.Forms.Label
    Friend WithEvents txtDeployID As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboPost As System.Windows.Forms.ComboBox
    Friend WithEvents txtRemarks As System.Windows.Forms.TextBox
    Friend WithEvents cboArmed As System.Windows.Forms.ComboBox
    Friend WithEvents dtpEnds As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpStarts As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtRate As System.Windows.Forms.TextBox
End Class
