﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPromotion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.lblDesig = New System.Windows.Forms.Label()
        Me.lblEmployee = New System.Windows.Forms.Label()
        Me.lblPromoId = New System.Windows.Forms.Label()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.txtPromoId = New System.Windows.Forms.TextBox()
        Me.cboEmployee = New System.Windows.Forms.ComboBox()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.lblSpecialAllowance = New System.Windows.Forms.Label()
        Me.lblRemarks = New System.Windows.Forms.Label()
        Me.lblDoP = New System.Windows.Forms.Label()
        Me.dtpWEF = New System.Windows.Forms.DateTimePicker()
        Me.cboDesignation = New System.Windows.Forms.ComboBox()
        Me.txtSpecialAllowance = New System.Windows.Forms.TextBox()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.gbxBrowse.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.gbxDetail.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(4, 2)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(651, 66)
        Me.gbxBrowse.TabIndex = 33
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(556, 19)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(475, 19)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(450, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'lblDesig
        '
        Me.lblDesig.AutoSize = True
        Me.lblDesig.Location = New System.Drawing.Point(10, 86)
        Me.lblDesig.Name = "lblDesig"
        Me.lblDesig.Size = New System.Drawing.Size(63, 13)
        Me.lblDesig.TabIndex = 15
        Me.lblDesig.Text = "Designation"
        '
        'lblEmployee
        '
        Me.lblEmployee.AutoSize = True
        Me.lblEmployee.Location = New System.Drawing.Point(10, 60)
        Me.lblEmployee.Name = "lblEmployee"
        Me.lblEmployee.Size = New System.Drawing.Size(53, 13)
        Me.lblEmployee.TabIndex = 14
        Me.lblEmployee.Text = "Employee"
        '
        'lblPromoId
        '
        Me.lblPromoId.AutoSize = True
        Me.lblPromoId.Location = New System.Drawing.Point(10, 34)
        Me.lblPromoId.Name = "lblPromoId"
        Me.lblPromoId.Size = New System.Drawing.Size(67, 13)
        Me.lblPromoId.TabIndex = 13
        Me.lblPromoId.Text = "Reference #"
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(475, 207)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 5
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 340)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(660, 22)
        Me.ssp.TabIndex = 35
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(556, 208)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 6
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'txtPromoId
        '
        Me.txtPromoId.Location = New System.Drawing.Point(115, 27)
        Me.txtPromoId.MaxLength = 50
        Me.txtPromoId.Name = "txtPromoId"
        Me.txtPromoId.Size = New System.Drawing.Size(341, 20)
        Me.txtPromoId.TabIndex = 1
        '
        'cboEmployee
        '
        Me.cboEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEmployee.FormattingEnabled = True
        Me.cboEmployee.Location = New System.Drawing.Point(115, 57)
        Me.cboEmployee.Name = "cboEmployee"
        Me.cboEmployee.Size = New System.Drawing.Size(341, 21)
        Me.cboEmployee.TabIndex = 3
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.lblSpecialAllowance)
        Me.gbxDetail.Controls.Add(Me.lblRemarks)
        Me.gbxDetail.Controls.Add(Me.lblDoP)
        Me.gbxDetail.Controls.Add(Me.dtpWEF)
        Me.gbxDetail.Controls.Add(Me.cboDesignation)
        Me.gbxDetail.Controls.Add(Me.txtSpecialAllowance)
        Me.gbxDetail.Controls.Add(Me.txtRemarks)
        Me.gbxDetail.Controls.Add(Me.cboEmployee)
        Me.gbxDetail.Controls.Add(Me.lblDesig)
        Me.gbxDetail.Controls.Add(Me.lblEmployee)
        Me.gbxDetail.Controls.Add(Me.lblPromoId)
        Me.gbxDetail.Controls.Add(Me.txtPromoId)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(4, 74)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(651, 256)
        Me.gbxDetail.TabIndex = 34
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Promotion or Demotion Details"
        '
        'lblSpecialAllowance
        '
        Me.lblSpecialAllowance.AutoSize = True
        Me.lblSpecialAllowance.Location = New System.Drawing.Point(10, 181)
        Me.lblSpecialAllowance.Name = "lblSpecialAllowance"
        Me.lblSpecialAllowance.Size = New System.Drawing.Size(94, 13)
        Me.lblSpecialAllowance.TabIndex = 22
        Me.lblSpecialAllowance.Text = "Special Allowance"
        '
        'lblRemarks
        '
        Me.lblRemarks.AutoSize = True
        Me.lblRemarks.Location = New System.Drawing.Point(10, 155)
        Me.lblRemarks.Name = "lblRemarks"
        Me.lblRemarks.Size = New System.Drawing.Size(49, 13)
        Me.lblRemarks.TabIndex = 21
        Me.lblRemarks.Text = "Remarks"
        '
        'lblDoP
        '
        Me.lblDoP.AutoSize = True
        Me.lblDoP.Location = New System.Drawing.Point(10, 128)
        Me.lblDoP.Name = "lblDoP"
        Me.lblDoP.Size = New System.Drawing.Size(75, 13)
        Me.lblDoP.TabIndex = 20
        Me.lblDoP.Text = "Effective Date"
        '
        'dtpWEF
        '
        Me.dtpWEF.Location = New System.Drawing.Point(115, 122)
        Me.dtpWEF.Name = "dtpWEF"
        Me.dtpWEF.Size = New System.Drawing.Size(341, 20)
        Me.dtpWEF.TabIndex = 19
        '
        'cboDesignation
        '
        Me.cboDesignation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDesignation.FormattingEnabled = True
        Me.cboDesignation.Location = New System.Drawing.Point(115, 86)
        Me.cboDesignation.Name = "cboDesignation"
        Me.cboDesignation.Size = New System.Drawing.Size(341, 21)
        Me.cboDesignation.TabIndex = 18
        '
        'txtSpecialAllowance
        '
        Me.txtSpecialAllowance.Location = New System.Drawing.Point(115, 174)
        Me.txtSpecialAllowance.MaxLength = 6
        Me.txtSpecialAllowance.Name = "txtSpecialAllowance"
        Me.txtSpecialAllowance.Size = New System.Drawing.Size(341, 20)
        Me.txtSpecialAllowance.TabIndex = 17
        '
        'txtRemarks
        '
        Me.txtRemarks.Location = New System.Drawing.Point(115, 148)
        Me.txtRemarks.MaxLength = 50
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(341, 20)
        Me.txtRemarks.TabIndex = 16
        '
        'frmPromotion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(660, 362)
        Me.Controls.Add(Me.gbxBrowse)
        Me.Controls.Add(Me.ssp)
        Me.Controls.Add(Me.gbxDetail)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmPromotion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmPromotion"
        Me.gbxBrowse.ResumeLayout(False)
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox
    Friend WithEvents lblDesig As System.Windows.Forms.Label
    Friend WithEvents lblEmployee As System.Windows.Forms.Label
    Friend WithEvents lblPromoId As System.Windows.Forms.Label

    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents txtPromoId As System.Windows.Forms.TextBox
    Friend WithEvents cboEmployee As System.Windows.Forms.ComboBox
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox
    Friend WithEvents txtSpecialAllowance As System.Windows.Forms.TextBox
    Friend WithEvents txtRemarks As System.Windows.Forms.TextBox
    Friend WithEvents cboDesignation As System.Windows.Forms.ComboBox
    Friend WithEvents lblDoP As System.Windows.Forms.Label
    Friend WithEvents dtpWEF As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblSpecialAllowance As System.Windows.Forms.Label
    Friend WithEvents lblRemarks As System.Windows.Forms.Label
End Class
