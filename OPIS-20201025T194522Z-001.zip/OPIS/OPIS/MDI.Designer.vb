﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDI
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MDI))
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ApplicationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AuthorizationPriviligesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.QuitApplicationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HumanResourcesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmploymentRecruitmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LeavesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FinesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DesignationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PromotionDemotionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransferToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OfficeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormsToolStripMenuItem = New System.Windows.Forms.ToolStripSeparator()
        Me.CustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContractsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LocationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PostsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeploymentShiftsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResourceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ScheduleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PayrollToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScheduleToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EstablishmentListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerLocationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalarySheetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RiskAssessmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ThreatsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RisksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GapsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecommendationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
        Me.SurveyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IdentifiedGapsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecommendedSafeguardsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 463)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1158, 22)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.Blue
        Me.ToolStripStatusLabel1.Image = CType(resources.GetObject("ToolStripStatusLabel1.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Padding = New System.Windows.Forms.Padding(0, 0, 10, 0)
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(147, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.Color.Red
        Me.ToolStripStatusLabel2.Image = CType(resources.GetObject("ToolStripStatusLabel2.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(137, 17)
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStripStatusLabel3.Image = CType(resources.GetObject("ToolStripStatusLabel3.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(137, 17)
        Me.ToolStripStatusLabel3.Text = "ToolStripStatusLabel3"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApplicationToolStripMenuItem, Me.HumanResourcesToolStripMenuItem, Me.ReportsToolStripMenuItem1, Me.RiskAssessmentToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1158, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ApplicationToolStripMenuItem
        '
        Me.ApplicationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem, Me.AuthorizationPriviligesToolStripMenuItem, Me.AddUserToolStripMenuItem, Me.ToolStripMenuItem2, Me.QuitApplicationToolStripMenuItem})
        Me.ApplicationToolStripMenuItem.Image = CType(resources.GetObject("ApplicationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ApplicationToolStripMenuItem.Name = "ApplicationToolStripMenuItem"
        Me.ApplicationToolStripMenuItem.Size = New System.Drawing.Size(96, 20)
        Me.ApplicationToolStripMenuItem.Text = "Application"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'AuthorizationPriviligesToolStripMenuItem
        '
        Me.AuthorizationPriviligesToolStripMenuItem.Name = "AuthorizationPriviligesToolStripMenuItem"
        Me.AuthorizationPriviligesToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.AuthorizationPriviligesToolStripMenuItem.Text = "Authorization / Priviliges"
        '
        'AddUserToolStripMenuItem
        '
        Me.AddUserToolStripMenuItem.Name = "AddUserToolStripMenuItem"
        Me.AddUserToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.AddUserToolStripMenuItem.Text = "Add User"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(201, 6)
        '
        'QuitApplicationToolStripMenuItem
        '
        Me.QuitApplicationToolStripMenuItem.Name = "QuitApplicationToolStripMenuItem"
        Me.QuitApplicationToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.QuitApplicationToolStripMenuItem.Text = "Quit Application"
        '
        'HumanResourcesToolStripMenuItem
        '
        Me.HumanResourcesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EmploymentRecruitmentToolStripMenuItem, Me.SetupToolStripMenuItem, Me.LeavesToolStripMenuItem, Me.FinesToolStripMenuItem, Me.DesignationToolStripMenuItem, Me.PromotionDemotionToolStripMenuItem, Me.TransferToolStripMenuItem, Me.OfficeToolStripMenuItem, Me.FormsToolStripMenuItem, Me.CustomerToolStripMenuItem, Me.ContractsToolStripMenuItem, Me.LocationToolStripMenuItem, Me.PostsToolStripMenuItem, Me.DeploymentShiftsToolStripMenuItem, Me.ResourceToolStripMenuItem, Me.ToolStripMenuItem1, Me.ScheduleToolStripMenuItem, Me.AttendanceToolStripMenuItem, Me.PayrollToolStripMenuItem})
        Me.HumanResourcesToolStripMenuItem.Image = CType(resources.GetObject("HumanResourcesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.HumanResourcesToolStripMenuItem.Name = "HumanResourcesToolStripMenuItem"
        Me.HumanResourcesToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.HumanResourcesToolStripMenuItem.Text = "Forms"
        '
        'EmploymentRecruitmentToolStripMenuItem
        '
        Me.EmploymentRecruitmentToolStripMenuItem.Name = "EmploymentRecruitmentToolStripMenuItem"
        Me.EmploymentRecruitmentToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D1), System.Windows.Forms.Keys)
        Me.EmploymentRecruitmentToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.EmploymentRecruitmentToolStripMenuItem.Text = "Employment / Discharge"
        '
        'SetupToolStripMenuItem
        '
        Me.SetupToolStripMenuItem.Image = CType(resources.GetObject("SetupToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SetupToolStripMenuItem.Name = "SetupToolStripMenuItem"
        Me.SetupToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D2), System.Windows.Forms.Keys)
        Me.SetupToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.SetupToolStripMenuItem.Text = "Employee"
        '
        'LeavesToolStripMenuItem
        '
        Me.LeavesToolStripMenuItem.Name = "LeavesToolStripMenuItem"
        Me.LeavesToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D3), System.Windows.Forms.Keys)
        Me.LeavesToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.LeavesToolStripMenuItem.Text = "Leaves"
        '
        'FinesToolStripMenuItem
        '
        Me.FinesToolStripMenuItem.Name = "FinesToolStripMenuItem"
        Me.FinesToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D4), System.Windows.Forms.Keys)
        Me.FinesToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.FinesToolStripMenuItem.Text = "Fines"
        '
        'DesignationToolStripMenuItem
        '
        Me.DesignationToolStripMenuItem.Name = "DesignationToolStripMenuItem"
        Me.DesignationToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D5), System.Windows.Forms.Keys)
        Me.DesignationToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.DesignationToolStripMenuItem.Text = "Designation"
        '
        'PromotionDemotionToolStripMenuItem
        '
        Me.PromotionDemotionToolStripMenuItem.Name = "PromotionDemotionToolStripMenuItem"
        Me.PromotionDemotionToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D6), System.Windows.Forms.Keys)
        Me.PromotionDemotionToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.PromotionDemotionToolStripMenuItem.Text = "Positional Status"
        '
        'TransferToolStripMenuItem
        '
        Me.TransferToolStripMenuItem.Name = "TransferToolStripMenuItem"
        Me.TransferToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D7), System.Windows.Forms.Keys)
        Me.TransferToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.TransferToolStripMenuItem.Text = "Transfer"
        '
        'OfficeToolStripMenuItem
        '
        Me.OfficeToolStripMenuItem.Name = "OfficeToolStripMenuItem"
        Me.OfficeToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D8), System.Windows.Forms.Keys)
        Me.OfficeToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.OfficeToolStripMenuItem.Text = "Office"
        '
        'FormsToolStripMenuItem
        '
        Me.FormsToolStripMenuItem.Name = "FormsToolStripMenuItem"
        Me.FormsToolStripMenuItem.Size = New System.Drawing.Size(242, 6)
        '
        'CustomerToolStripMenuItem
        '
        Me.CustomerToolStripMenuItem.Image = CType(resources.GetObject("CustomerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CustomerToolStripMenuItem.Name = "CustomerToolStripMenuItem"
        Me.CustomerToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D1), System.Windows.Forms.Keys)
        Me.CustomerToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.CustomerToolStripMenuItem.Text = "Customer"
        '
        'ContractsToolStripMenuItem
        '
        Me.ContractsToolStripMenuItem.Name = "ContractsToolStripMenuItem"
        Me.ContractsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D2), System.Windows.Forms.Keys)
        Me.ContractsToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.ContractsToolStripMenuItem.Text = "Contracts"
        '
        'LocationToolStripMenuItem
        '
        Me.LocationToolStripMenuItem.Image = CType(resources.GetObject("LocationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LocationToolStripMenuItem.Name = "LocationToolStripMenuItem"
        Me.LocationToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D3), System.Windows.Forms.Keys)
        Me.LocationToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.LocationToolStripMenuItem.Text = "Location"
        '
        'PostsToolStripMenuItem
        '
        Me.PostsToolStripMenuItem.Name = "PostsToolStripMenuItem"
        Me.PostsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D4), System.Windows.Forms.Keys)
        Me.PostsToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.PostsToolStripMenuItem.Text = "Posts"
        '
        'DeploymentShiftsToolStripMenuItem
        '
        Me.DeploymentShiftsToolStripMenuItem.Name = "DeploymentShiftsToolStripMenuItem"
        Me.DeploymentShiftsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D5), System.Windows.Forms.Keys)
        Me.DeploymentShiftsToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.DeploymentShiftsToolStripMenuItem.Text = "Deployment / Shifts"
        '
        'ResourceToolStripMenuItem
        '
        Me.ResourceToolStripMenuItem.Name = "ResourceToolStripMenuItem"
        Me.ResourceToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D6), System.Windows.Forms.Keys)
        Me.ResourceToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.ResourceToolStripMenuItem.Text = "Resource"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(242, 6)
        '
        'ScheduleToolStripMenuItem
        '
        Me.ScheduleToolStripMenuItem.Image = CType(resources.GetObject("ScheduleToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ScheduleToolStripMenuItem.Name = "ScheduleToolStripMenuItem"
        Me.ScheduleToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D7), System.Windows.Forms.Keys)
        Me.ScheduleToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.ScheduleToolStripMenuItem.Text = "Schedule"
        '
        'AttendanceToolStripMenuItem
        '
        Me.AttendanceToolStripMenuItem.Image = CType(resources.GetObject("AttendanceToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AttendanceToolStripMenuItem.Name = "AttendanceToolStripMenuItem"
        Me.AttendanceToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D8), System.Windows.Forms.Keys)
        Me.AttendanceToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.AttendanceToolStripMenuItem.Text = "Attendance"
        '
        'PayrollToolStripMenuItem
        '
        Me.PayrollToolStripMenuItem.Name = "PayrollToolStripMenuItem"
        Me.PayrollToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D9), System.Windows.Forms.Keys)
        Me.PayrollToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.PayrollToolStripMenuItem.Text = "Payroll"
        '
        'ReportsToolStripMenuItem1
        '
        Me.ReportsToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ScheduleToolStripMenuItem1, Me.EstablishmentListToolStripMenuItem, Me.CustomerLocationsToolStripMenuItem, Me.SalarySheetToolStripMenuItem})
        Me.ReportsToolStripMenuItem1.Image = CType(resources.GetObject("ReportsToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ReportsToolStripMenuItem1.Name = "ReportsToolStripMenuItem1"
        Me.ReportsToolStripMenuItem1.Size = New System.Drawing.Size(75, 20)
        Me.ReportsToolStripMenuItem1.Text = "Reports"
        '
        'ScheduleToolStripMenuItem1
        '
        Me.ScheduleToolStripMenuItem1.Name = "ScheduleToolStripMenuItem1"
        Me.ScheduleToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.ScheduleToolStripMenuItem1.Text = "Schedule"
        '
        'EstablishmentListToolStripMenuItem
        '
        Me.EstablishmentListToolStripMenuItem.Name = "EstablishmentListToolStripMenuItem"
        Me.EstablishmentListToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.EstablishmentListToolStripMenuItem.Text = "Establishment List"
        '
        'CustomerLocationsToolStripMenuItem
        '
        Me.CustomerLocationsToolStripMenuItem.Name = "CustomerLocationsToolStripMenuItem"
        Me.CustomerLocationsToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.CustomerLocationsToolStripMenuItem.Text = "Customer Locations"
        '
        'SalarySheetToolStripMenuItem
        '
        Me.SalarySheetToolStripMenuItem.Name = "SalarySheetToolStripMenuItem"
        Me.SalarySheetToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SalarySheetToolStripMenuItem.Text = "Salary Sheet"
        '
        'RiskAssessmentToolStripMenuItem
        '
        Me.RiskAssessmentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ThreatsToolStripMenuItem, Me.RisksToolStripMenuItem, Me.GapsToolStripMenuItem, Me.RecommendationsToolStripMenuItem, Me.ToolStripMenuItem3, Me.SurveyToolStripMenuItem, Me.IdentifiedGapsToolStripMenuItem, Me.RecommendedSafeguardsToolStripMenuItem})
        Me.RiskAssessmentToolStripMenuItem.Name = "RiskAssessmentToolStripMenuItem"
        Me.RiskAssessmentToolStripMenuItem.Size = New System.Drawing.Size(105, 20)
        Me.RiskAssessmentToolStripMenuItem.Text = "Risk Assessment"
        '
        'ThreatsToolStripMenuItem
        '
        Me.ThreatsToolStripMenuItem.Name = "ThreatsToolStripMenuItem"
        Me.ThreatsToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.ThreatsToolStripMenuItem.Text = "Threats"
        '
        'RisksToolStripMenuItem
        '
        Me.RisksToolStripMenuItem.Name = "RisksToolStripMenuItem"
        Me.RisksToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.RisksToolStripMenuItem.Text = "Risks"
        '
        'GapsToolStripMenuItem
        '
        Me.GapsToolStripMenuItem.Name = "GapsToolStripMenuItem"
        Me.GapsToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.GapsToolStripMenuItem.Text = "Gaps"
        '
        'RecommendationsToolStripMenuItem
        '
        Me.RecommendationsToolStripMenuItem.Name = "RecommendationsToolStripMenuItem"
        Me.RecommendationsToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.RecommendationsToolStripMenuItem.Text = "Counter Measure"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(213, 6)
        '
        'SurveyToolStripMenuItem
        '
        Me.SurveyToolStripMenuItem.Name = "SurveyToolStripMenuItem"
        Me.SurveyToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.SurveyToolStripMenuItem.Text = "Survey"
        '
        'IdentifiedGapsToolStripMenuItem
        '
        Me.IdentifiedGapsToolStripMenuItem.Name = "IdentifiedGapsToolStripMenuItem"
        Me.IdentifiedGapsToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.IdentifiedGapsToolStripMenuItem.Text = "Identified Gaps"
        '
        'RecommendedSafeguardsToolStripMenuItem
        '
        Me.RecommendedSafeguardsToolStripMenuItem.Name = "RecommendedSafeguardsToolStripMenuItem"
        Me.RecommendedSafeguardsToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.RecommendedSafeguardsToolStripMenuItem.Text = "Recommended Safeguards"
        '
        'MDI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(1158, 485)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MDI"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "Libertine Global Solutions - Operations Payroll Information System [Trial Version" & _
            "]"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ApplicationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HumanResourcesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormsToolStripMenuItem As System.Windows.Forms.ToolStripSeparator

    Friend WithEvents DesignationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PromotionDemotionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OfficeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransferToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmploymentRecruitmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LeavesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FinesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContractsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LocationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PostsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeploymentShiftsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResourceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScheduleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AttendanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AuthorizationPriviligesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents QuitApplicationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ScheduleToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EstablishmentListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerLocationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PayrollToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalarySheetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RiskAssessmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ThreatsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RisksToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GapsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecommendationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SurveyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IdentifiedGapsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecommendedSafeguardsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem































End Class
