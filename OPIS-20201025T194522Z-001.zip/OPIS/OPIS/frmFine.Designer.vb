﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFine
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFine))
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtFineAmount = New System.Windows.Forms.TextBox()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.cboImposed = New System.Windows.Forms.ComboBox()
        Me.dtpFineDate = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboEmp = New System.Windows.Forms.ComboBox()
        Me.lblOff = New System.Windows.Forms.Label()
        Me.lblEmp = New System.Windows.Forms.Label()
        Me.lblTransferId = New System.Windows.Forms.Label()
        Me.txtFineId = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.gbxDetail.SuspendLayout()
        Me.gbxBrowse.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.Label3)
        Me.gbxDetail.Controls.Add(Me.txtFineAmount)
        Me.gbxDetail.Controls.Add(Me.txtRemarks)
        Me.gbxDetail.Controls.Add(Me.cboImposed)
        Me.gbxDetail.Controls.Add(Me.dtpFineDate)
        Me.gbxDetail.Controls.Add(Me.Label2)
        Me.gbxDetail.Controls.Add(Me.Label1)
        Me.gbxDetail.Controls.Add(Me.cboEmp)
        Me.gbxDetail.Controls.Add(Me.lblOff)
        Me.gbxDetail.Controls.Add(Me.lblEmp)
        Me.gbxDetail.Controls.Add(Me.lblTransferId)
        Me.gbxDetail.Controls.Add(Me.txtFineId)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(6, 76)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(651, 233)
        Me.gbxDetail.TabIndex = 52
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Details"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 164)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 57
        Me.Label3.Text = "Amount"
        '
        'txtFineAmount
        '
        Me.txtFineAmount.Location = New System.Drawing.Point(153, 161)
        Me.txtFineAmount.MaxLength = 6
        Me.txtFineAmount.Name = "txtFineAmount"
        Me.txtFineAmount.Size = New System.Drawing.Size(273, 20)
        Me.txtFineAmount.TabIndex = 56
        Me.txtFineAmount.Text = "0"
        Me.txtFineAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtRemarks
        '
        Me.txtRemarks.Location = New System.Drawing.Point(153, 105)
        Me.txtRemarks.MaxLength = 50
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(273, 20)
        Me.txtRemarks.TabIndex = 55
        '
        'cboImposed
        '
        Me.cboImposed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboImposed.FormattingEnabled = True
        Me.cboImposed.Location = New System.Drawing.Point(153, 132)
        Me.cboImposed.Name = "cboImposed"
        Me.cboImposed.Size = New System.Drawing.Size(273, 21)
        Me.cboImposed.TabIndex = 53
        '
        'dtpFineDate
        '
        Me.dtpFineDate.Location = New System.Drawing.Point(153, 79)
        Me.dtpFineDate.Name = "dtpFineDate"
        Me.dtpFineDate.Size = New System.Drawing.Size(273, 20)
        Me.dtpFineDate.TabIndex = 52
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 135)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Imposed By"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 108)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "Remarks"
        '
        'cboEmp
        '
        Me.cboEmp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEmp.FormattingEnabled = True
        Me.cboEmp.Location = New System.Drawing.Point(153, 54)
        Me.cboEmp.Name = "cboEmp"
        Me.cboEmp.Size = New System.Drawing.Size(273, 21)
        Me.cboEmp.TabIndex = 46
        '
        'lblOff
        '
        Me.lblOff.AutoSize = True
        Me.lblOff.Location = New System.Drawing.Point(10, 86)
        Me.lblOff.Name = "lblOff"
        Me.lblOff.Size = New System.Drawing.Size(67, 13)
        Me.lblOff.TabIndex = 37
        Me.lblOff.Text = "Date Of Fine"
        '
        'lblEmp
        '
        Me.lblEmp.AutoSize = True
        Me.lblEmp.Location = New System.Drawing.Point(10, 60)
        Me.lblEmp.Name = "lblEmp"
        Me.lblEmp.Size = New System.Drawing.Size(53, 13)
        Me.lblEmp.TabIndex = 36
        Me.lblEmp.Text = "Employee"
        '
        'lblTransferId
        '
        Me.lblTransferId.AutoSize = True
        Me.lblTransferId.Location = New System.Drawing.Point(10, 34)
        Me.lblTransferId.Name = "lblTransferId"
        Me.lblTransferId.Size = New System.Drawing.Size(41, 13)
        Me.lblTransferId.TabIndex = 13
        Me.lblTransferId.Text = "Fine ID"
        '
        'txtFineId
        '
        Me.txtFineId.Location = New System.Drawing.Point(153, 27)
        Me.txtFineId.MaxLength = 50
        Me.txtFineId.Name = "txtFineId"
        Me.txtFineId.Size = New System.Drawing.Size(273, 20)
        Me.txtFineId.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(556, 189)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(475, 188)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(556, 19)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(6, 2)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(651, 66)
        Me.gbxBrowse.TabIndex = 51
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(475, 19)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(450, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 312)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(662, 22)
        Me.ssp.TabIndex = 53
        Me.ssp.Text = "StatusStrip1"
        '
        'frmFine
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(662, 334)
        Me.Controls.Add(Me.gbxDetail)
        Me.Controls.Add(Me.gbxBrowse)
        Me.Controls.Add(Me.ssp)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmFine"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fines"
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.gbxBrowse.ResumeLayout(False)
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox

    Friend WithEvents cboImposed As System.Windows.Forms.ComboBox
    Friend WithEvents dtpFineDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label

    Friend WithEvents cboEmp As System.Windows.Forms.ComboBox

    Friend WithEvents lblOff As System.Windows.Forms.Label
    Friend WithEvents lblEmp As System.Windows.Forms.Label
    Friend WithEvents lblTransferId As System.Windows.Forms.Label
    Friend WithEvents txtFineId As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents txtRemarks As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtFineAmount As System.Windows.Forms.TextBox
End Class
