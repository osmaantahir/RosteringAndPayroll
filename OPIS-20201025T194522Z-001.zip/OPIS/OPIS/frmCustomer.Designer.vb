﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxBrowse = New System.Windows.Forms.GroupBox()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cboBrowse = New System.Windows.Forms.ComboBox()
        Me.lblCustId = New System.Windows.Forms.Label()
        Me.txtCustId = New System.Windows.Forms.TextBox()
        Me.gbxDetail = New System.Windows.Forms.GroupBox()
        Me.lblNames = New System.Windows.Forms.Label()
        Me.lblCells = New System.Windows.Forms.Label()
        Me.lblEmails = New System.Windows.Forms.Label()
        Me.lblOPS = New System.Windows.Forms.Label()
        Me.lblINF = New System.Windows.Forms.Label()
        Me.lblDM = New System.Windows.Forms.Label()
        Me.lblFax = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblNam = New System.Windows.Forms.Label()
        Me.txtOPSCell = New System.Windows.Forms.TextBox()
        Me.txtINFCell = New System.Windows.Forms.TextBox()
        Me.txtDMCell = New System.Windows.Forms.TextBox()
        Me.txtOPSEmail = New System.Windows.Forms.TextBox()
        Me.txtINFEmail = New System.Windows.Forms.TextBox()
        Me.txtDMEmail = New System.Windows.Forms.TextBox()
        Me.txtOPSName = New System.Windows.Forms.TextBox()
        Me.txtINFName = New System.Windows.Forms.TextBox()
        Me.txtDMName = New System.Windows.Forms.TextBox()
        Me.txtFax = New System.Windows.Forms.TextBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.txtAdd = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.ssp = New System.Windows.Forms.StatusStrip()
        Me.Mode = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxBrowse.SuspendLayout()
        Me.gbxDetail.SuspendLayout()
        Me.ssp.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxBrowse
        '
        Me.gbxBrowse.Controls.Add(Me.cmdNew)
        Me.gbxBrowse.Controls.Add(Me.cmdGo)
        Me.gbxBrowse.Controls.Add(Me.cboBrowse)
        Me.gbxBrowse.Location = New System.Drawing.Point(4, 1)
        Me.gbxBrowse.Name = "gbxBrowse"
        Me.gbxBrowse.Size = New System.Drawing.Size(651, 66)
        Me.gbxBrowse.TabIndex = 0
        Me.gbxBrowse.TabStop = False
        Me.gbxBrowse.Text = "Browse"
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(556, 19)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(77, 37)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'cmdGo
        '
        Me.cmdGo.Location = New System.Drawing.Point(475, 19)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.Size = New System.Drawing.Size(77, 37)
        Me.cmdGo.TabIndex = 1
        Me.cmdGo.Text = "Go"
        Me.cmdGo.UseVisualStyleBackColor = True
        '
        'cboBrowse
        '
        Me.cboBrowse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrowse.FormattingEnabled = True
        Me.cboBrowse.Location = New System.Drawing.Point(6, 31)
        Me.cboBrowse.Name = "cboBrowse"
        Me.cboBrowse.Size = New System.Drawing.Size(450, 21)
        Me.cboBrowse.TabIndex = 0
        '
        'lblCustId
        '
        Me.lblCustId.AutoSize = True
        Me.lblCustId.Location = New System.Drawing.Point(10, 34)
        Me.lblCustId.Name = "lblCustId"
        Me.lblCustId.Size = New System.Drawing.Size(65, 13)
        Me.lblCustId.TabIndex = 13
        Me.lblCustId.Text = "Customer ID"
        '
        'txtCustId
        '
        Me.txtCustId.Location = New System.Drawing.Point(115, 27)
        Me.txtCustId.MaxLength = 50
        Me.txtCustId.Name = "txtCustId"
        Me.txtCustId.Size = New System.Drawing.Size(273, 20)
        Me.txtCustId.TabIndex = 0
        '
        'gbxDetail
        '
        Me.gbxDetail.Controls.Add(Me.lblNames)
        Me.gbxDetail.Controls.Add(Me.lblCells)
        Me.gbxDetail.Controls.Add(Me.lblEmails)
        Me.gbxDetail.Controls.Add(Me.lblOPS)
        Me.gbxDetail.Controls.Add(Me.lblINF)
        Me.gbxDetail.Controls.Add(Me.lblDM)
        Me.gbxDetail.Controls.Add(Me.lblFax)
        Me.gbxDetail.Controls.Add(Me.lblPhone)
        Me.gbxDetail.Controls.Add(Me.lblAddress)
        Me.gbxDetail.Controls.Add(Me.lblNam)
        Me.gbxDetail.Controls.Add(Me.txtOPSCell)
        Me.gbxDetail.Controls.Add(Me.txtINFCell)
        Me.gbxDetail.Controls.Add(Me.txtDMCell)
        Me.gbxDetail.Controls.Add(Me.txtOPSEmail)
        Me.gbxDetail.Controls.Add(Me.txtINFEmail)
        Me.gbxDetail.Controls.Add(Me.txtDMEmail)
        Me.gbxDetail.Controls.Add(Me.txtOPSName)
        Me.gbxDetail.Controls.Add(Me.txtINFName)
        Me.gbxDetail.Controls.Add(Me.txtDMName)
        Me.gbxDetail.Controls.Add(Me.txtFax)
        Me.gbxDetail.Controls.Add(Me.txtPhone)
        Me.gbxDetail.Controls.Add(Me.txtAdd)
        Me.gbxDetail.Controls.Add(Me.txtName)
        Me.gbxDetail.Controls.Add(Me.lblCustId)
        Me.gbxDetail.Controls.Add(Me.txtCustId)
        Me.gbxDetail.Controls.Add(Me.cmdCancel)
        Me.gbxDetail.Controls.Add(Me.cmdSave)
        Me.gbxDetail.Location = New System.Drawing.Point(4, 75)
        Me.gbxDetail.Name = "gbxDetail"
        Me.gbxDetail.Size = New System.Drawing.Size(651, 349)
        Me.gbxDetail.TabIndex = 2
        Me.gbxDetail.TabStop = False
        Me.gbxDetail.Text = "Promotion or Demotion Details"
        '
        'lblNames
        '
        Me.lblNames.AutoSize = True
        Me.lblNames.Location = New System.Drawing.Point(112, 190)
        Me.lblNames.Name = "lblNames"
        Me.lblNames.Size = New System.Drawing.Size(83, 13)
        Me.lblNames.TabIndex = 45
        Me.lblNames.Text = "Name of Person"
        '
        'lblCells
        '
        Me.lblCells.AutoSize = True
        Me.lblCells.Location = New System.Drawing.Point(437, 190)
        Me.lblCells.Name = "lblCells"
        Me.lblCells.Size = New System.Drawing.Size(138, 13)
        Me.lblCells.TabIndex = 44
        Me.lblCells.Text = "Contact Telephone Number"
        '
        'lblEmails
        '
        Me.lblEmails.AutoSize = True
        Me.lblEmails.Location = New System.Drawing.Point(279, 190)
        Me.lblEmails.Name = "lblEmails"
        Me.lblEmails.Size = New System.Drawing.Size(113, 13)
        Me.lblEmails.TabIndex = 43
        Me.lblEmails.Text = "Contact Email Address"
        '
        'lblOPS
        '
        Me.lblOPS.AutoSize = True
        Me.lblOPS.Location = New System.Drawing.Point(10, 264)
        Me.lblOPS.Name = "lblOPS"
        Me.lblOPS.Size = New System.Drawing.Size(58, 13)
        Me.lblOPS.TabIndex = 42
        Me.lblOPS.Text = "Operations"
        '
        'lblINF
        '
        Me.lblINF.AutoSize = True
        Me.lblINF.Location = New System.Drawing.Point(10, 239)
        Me.lblINF.Name = "lblINF"
        Me.lblINF.Size = New System.Drawing.Size(54, 13)
        Me.lblINF.TabIndex = 41
        Me.lblINF.Text = "Influencer"
        '
        'lblDM
        '
        Me.lblDM.AutoSize = True
        Me.lblDM.Location = New System.Drawing.Point(10, 213)
        Me.lblDM.Name = "lblDM"
        Me.lblDM.Size = New System.Drawing.Size(81, 13)
        Me.lblDM.TabIndex = 40
        Me.lblDM.Text = "Decision Maker"
        '
        'lblFax
        '
        Me.lblFax.AutoSize = True
        Me.lblFax.Location = New System.Drawing.Point(10, 138)
        Me.lblFax.Name = "lblFax"
        Me.lblFax.Size = New System.Drawing.Size(24, 13)
        Me.lblFax.TabIndex = 39
        Me.lblFax.Text = "Fax"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Location = New System.Drawing.Point(10, 112)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(38, 13)
        Me.lblPhone.TabIndex = 38
        Me.lblPhone.Text = "Phone"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(10, 86)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblAddress.TabIndex = 37
        Me.lblAddress.Text = "Address"
        '
        'lblNam
        '
        Me.lblNam.AutoSize = True
        Me.lblNam.Location = New System.Drawing.Point(10, 60)
        Me.lblNam.Name = "lblNam"
        Me.lblNam.Size = New System.Drawing.Size(35, 13)
        Me.lblNam.TabIndex = 36
        Me.lblNam.Text = "Name"
        '
        'txtOPSCell
        '
        Me.txtOPSCell.Location = New System.Drawing.Point(440, 258)
        Me.txtOPSCell.MaxLength = 50
        Me.txtOPSCell.Name = "txtOPSCell"
        Me.txtOPSCell.Size = New System.Drawing.Size(158, 20)
        Me.txtOPSCell.TabIndex = 13
        '
        'txtINFCell
        '
        Me.txtINFCell.Location = New System.Drawing.Point(440, 232)
        Me.txtINFCell.MaxLength = 50
        Me.txtINFCell.Name = "txtINFCell"
        Me.txtINFCell.Size = New System.Drawing.Size(158, 20)
        Me.txtINFCell.TabIndex = 10
        '
        'txtDMCell
        '
        Me.txtDMCell.Location = New System.Drawing.Point(440, 206)
        Me.txtDMCell.MaxLength = 50
        Me.txtDMCell.Name = "txtDMCell"
        Me.txtDMCell.Size = New System.Drawing.Size(158, 20)
        Me.txtDMCell.TabIndex = 7
        '
        'txtOPSEmail
        '
        Me.txtOPSEmail.Location = New System.Drawing.Point(282, 258)
        Me.txtOPSEmail.MaxLength = 50
        Me.txtOPSEmail.Name = "txtOPSEmail"
        Me.txtOPSEmail.Size = New System.Drawing.Size(152, 20)
        Me.txtOPSEmail.TabIndex = 12
        '
        'txtINFEmail
        '
        Me.txtINFEmail.Location = New System.Drawing.Point(282, 232)
        Me.txtINFEmail.MaxLength = 50
        Me.txtINFEmail.Name = "txtINFEmail"
        Me.txtINFEmail.Size = New System.Drawing.Size(152, 20)
        Me.txtINFEmail.TabIndex = 9
        '
        'txtDMEmail
        '
        Me.txtDMEmail.Location = New System.Drawing.Point(282, 206)
        Me.txtDMEmail.MaxLength = 50
        Me.txtDMEmail.Name = "txtDMEmail"
        Me.txtDMEmail.Size = New System.Drawing.Size(152, 20)
        Me.txtDMEmail.TabIndex = 6
        '
        'txtOPSName
        '
        Me.txtOPSName.Location = New System.Drawing.Point(115, 257)
        Me.txtOPSName.MaxLength = 50
        Me.txtOPSName.Name = "txtOPSName"
        Me.txtOPSName.Size = New System.Drawing.Size(161, 20)
        Me.txtOPSName.TabIndex = 11
        '
        'txtINFName
        '
        Me.txtINFName.Location = New System.Drawing.Point(115, 232)
        Me.txtINFName.MaxLength = 50
        Me.txtINFName.Name = "txtINFName"
        Me.txtINFName.Size = New System.Drawing.Size(161, 20)
        Me.txtINFName.TabIndex = 8
        '
        'txtDMName
        '
        Me.txtDMName.Location = New System.Drawing.Point(115, 206)
        Me.txtDMName.MaxLength = 50
        Me.txtDMName.Name = "txtDMName"
        Me.txtDMName.Size = New System.Drawing.Size(161, 20)
        Me.txtDMName.TabIndex = 5
        '
        'txtFax
        '
        Me.txtFax.Location = New System.Drawing.Point(115, 131)
        Me.txtFax.MaxLength = 50
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(273, 20)
        Me.txtFax.TabIndex = 4
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(115, 105)
        Me.txtPhone.MaxLength = 50
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(273, 20)
        Me.txtPhone.TabIndex = 3
        '
        'txtAdd
        '
        Me.txtAdd.Location = New System.Drawing.Point(115, 79)
        Me.txtAdd.MaxLength = 50
        Me.txtAdd.Name = "txtAdd"
        Me.txtAdd.Size = New System.Drawing.Size(273, 20)
        Me.txtAdd.TabIndex = 2
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(115, 53)
        Me.txtName.MaxLength = 50
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(273, 20)
        Me.txtName.TabIndex = 1
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(556, 302)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(77, 34)
        Me.cmdCancel.TabIndex = 15
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(475, 301)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(77, 35)
        Me.cmdSave.TabIndex = 14
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'ssp
        '
        Me.ssp.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Mode})
        Me.ssp.Location = New System.Drawing.Point(0, 432)
        Me.ssp.Name = "ssp"
        Me.ssp.Size = New System.Drawing.Size(665, 22)
        Me.ssp.TabIndex = 38
        Me.ssp.Text = "StatusStrip1"
        '
        'Mode
        '
        Me.Mode.Name = "Mode"
        Me.Mode.Size = New System.Drawing.Size(121, 17)
        Me.Mode.Text = "ToolStripStatusLabel1"
        '
        'frmCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(665, 454)
        Me.Controls.Add(Me.gbxBrowse)
        Me.Controls.Add(Me.gbxDetail)
        Me.Controls.Add(Me.ssp)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmCustomer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmCustomer"
        Me.gbxBrowse.ResumeLayout(False)
        Me.gbxDetail.ResumeLayout(False)
        Me.gbxDetail.PerformLayout()
        Me.ssp.ResumeLayout(False)
        Me.ssp.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub







    Friend WithEvents gbxBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents cmdGo As System.Windows.Forms.Button
    Friend WithEvents cboBrowse As System.Windows.Forms.ComboBox



    Friend WithEvents lblCustId As System.Windows.Forms.Label
    Friend WithEvents txtCustId As System.Windows.Forms.TextBox
    Friend WithEvents gbxDetail As System.Windows.Forms.GroupBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents ssp As System.Windows.Forms.StatusStrip
    Friend WithEvents Mode As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents txtOPSCell As System.Windows.Forms.TextBox
    Friend WithEvents txtINFCell As System.Windows.Forms.TextBox
    Friend WithEvents txtDMCell As System.Windows.Forms.TextBox
    Friend WithEvents txtOPSEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtINFEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtDMEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtOPSName As System.Windows.Forms.TextBox
    Friend WithEvents txtINFName As System.Windows.Forms.TextBox
    Friend WithEvents txtDMName As System.Windows.Forms.TextBox
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents txtPhone As System.Windows.Forms.TextBox
    Friend WithEvents txtAdd As System.Windows.Forms.TextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblNam As System.Windows.Forms.Label



    Friend WithEvents lblNames As System.Windows.Forms.Label
    Friend WithEvents lblCells As System.Windows.Forms.Label
    Friend WithEvents lblEmails As System.Windows.Forms.Label
    Friend WithEvents lblOPS As System.Windows.Forms.Label
    Friend WithEvents lblINF As System.Windows.Forms.Label
    Friend WithEvents lblDM As System.Windows.Forms.Label
    Friend WithEvents lblFax As System.Windows.Forms.Label
    Friend WithEvents lblPhone As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
End Class
