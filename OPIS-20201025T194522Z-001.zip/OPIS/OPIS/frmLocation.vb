﻿Public Class frmLocation
    Private dtbrowse, dtContract, dtOffice As DataTable
    Private dbms As DML

    Private Sub frmLocation_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' LocationId, Address, ContractId, ContactPerson, Phone, Fax, Email, Description, OfficeId

        Try
            dbms = New DML()
            Dim str As String

            str = "SELECT '[' + dbo.tblLocations.LocationId + ']  ' + dbo.tblLocations.Description + ' : [' + dbo.tblLocations.ContractId + '] ' + dbo.tblOffice.Description + ' : [' + dbo.tblCustomer.CustId"
            str = str & " + '] ' + dbo.tblCustomer.Name AS Expr1, dbo.tblLocations.LocationId, dbo.tblLocations.Address, dbo.tblLocations.ContractId, dbo.tblLocations.ContactPerson, "
            str = str & " dbo.tblLocations.Phone, dbo.tblLocations.Fax, dbo.tblLocations.Email, dbo.tblLocations.Description, dbo.tblLocations.OfficeId"
            str = str & " FROM dbo.tblLocations INNER JOIN"
            str = str & " dbo.tblContract ON dbo.tblLocations.ContractId = dbo.tblContract.ContractId INNER JOIN"
            str = str & " dbo.tblCustomer ON dbo.tblContract.CustId = dbo.tblCustomer.CustId INNER JOIN"
            str = str & " dbo.tblOffice ON dbo.tblLocations.OfficeId = dbo.tblOffice.OfficeId"

            dtbrowse = dbms.getDataTable(str)

            dtContract = dbms.getDataTable("Select '['+ContractId+'] '+ScopeOfWork+' : '+CustId as Expr1,ContractId from tblContract")
            dtOffice = dbms.getDataTable("Select '['+OfficeId+'] '+Description as Expr1,OfficeId from tblOffice")

            Me.cboContract.DataSource = dtContract
            Me.cboContract.DisplayMember = "Expr1"
            Me.cboContract.ValueMember = "ContractId"

            Me.cboOffice.DataSource = dtOffice
            Me.cboOffice.DisplayMember = "Expr1"
            Me.cboOffice.ValueMember = "OfficeId"

            Me.cboContract.SelectedValue = -1
            Me.cboOffice.SelectedValue = -1

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Dim dc(1) As DataColumn
        dc(0) = dtbrowse.Columns("LocationId")
        dtbrowse.PrimaryKey = dc
        dc = Nothing

        cboBrowse.DataSource = dtbrowse
        cboBrowse.DisplayMember = "Expr1"
        cboBrowse.ValueMember = "LocationId"

        gbxDetail.Enabled = False
        ssp.Items("Mode").Text = "BROWSE MODE"
    End Sub

    Private Sub cmdGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGo.Click
        Dim dr As DataRow
        ' LocationId, Address, ContractId, ContactPerson, Phone, Fax, Email, Description, OfficeId
        Try
            dr = dtbrowse.Rows.Find(cboBrowse.SelectedValue)
            If dr Is Nothing Then
                ' Not Found
            Else
                Me.txtLocID.Text = "" & dr("LocationId")
                Me.txtAdd.Text = "" & dr("Address")
                Me.cboContract.SelectedValue = "" & dr("ContractId")
                Me.txtContactPerson.Text = "" & dr("ContactPerson")
                Me.txtPhone.Text = "" & dr("Phone")
                Me.txtFax.Text = "" & dr("Fax")
                Me.txtEmail.Text = "" & dr("Email")
                Me.txtDesc.Text = "" & dr("Description")
                Me.cboOffice.SelectedValue = "" & dr("OfficeId")


                Me.gbxDetail.Enabled = True
                Me.txtLocID.Enabled = False
                ssp.Items("Mode").Text = "EDITING MODE"
                Me.gbxBrowse.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Try
            If MsgBox("Please confirm to Cancel?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.txtLocID.Text = ""
                Me.txtAdd.Text = ""
                Me.cboContract.SelectedValue = -1
                Me.txtContactPerson.Text = ""
                Me.txtPhone.Text = ""
                Me.txtFax.Text = ""
                Me.txtEmail.Text = ""
                Me.txtDesc.Text = ""
                Me.cboOffice.SelectedValue = -1

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        Dim SBUID As String
        Try
            SBUID = dbms.generateId("LocationId")
            Me.txtLocID.Text = "" & SBUID
            Me.txtAdd.Text = ""
            Me.cboContract.SelectedValue = -1
            Me.txtContactPerson.Text = ""
            Me.txtPhone.Text = ""
            Me.txtFax.Text = ""
            Me.txtEmail.Text = ""
            Me.txtDesc.Text = ""
            Me.cboOffice.SelectedValue = -1


            Me.gbxDetail.Enabled = True
            Me.txtLocID.Enabled = False
            ssp.Items("Mode").Text = "NEW RECORD"
            Me.gbxBrowse.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        ' Update tblLocation Set Address='', ContractId='', ContactPerson='', Phone='', Fax='', Email='', Description='', OfficeId='' Where LocationId=''
        ' Insert into tblLocation (LocationId, Address, ContractId, ContactPerson, Phone, Fax, Email, Description, OfficeId) Values ()

        Try
            If MsgBox("Please confirm to Save Designation?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If ssp.Items("Mode").Text = "EDITING MODE" Then
                    dbms.execSql("Update tblLocations Set Address='" & Me.txtAdd.Text & "', ContractId='" & Me.cboContract.SelectedValue & "', ContactPerson='" & Me.txtContactPerson.Text & "', Phone='" & Me.txtPhone.Text & "', Fax='" & Me.txtFax.Text & "', Email='" & Me.txtEmail.Text & "', Description='" & Me.txtDesc.Text & "', OfficeId='" & Me.cboOffice.SelectedValue & "' Where LocationId='" & Me.txtLocID.Text & "'")
                Else
                    dbms.execSql("Insert into tblLocations (LocationId, Address, ContractId, ContactPerson, Phone, Fax, Email, Description, OfficeId) Values ('" & Me.txtLocID.Text & "','" & Me.txtAdd.Text & "','" & Me.cboContract.SelectedValue & "','" & Me.txtContactPerson.Text & "','" & Me.txtPhone.Text & "','" & Me.txtFax.Text & "','" & Me.txtEmail.Text & "','" & Me.txtDesc.Text & "','" & Me.cboOffice.SelectedValue & "')")
                End If
                Me.txtLocID.Text = ""
                Me.txtAdd.Text = ""
                Me.cboContract.SelectedValue = -1
                Me.txtContactPerson.Text = ""
                Me.txtPhone.Text = ""
                Me.txtFax.Text = ""
                Me.txtEmail.Text = ""
                Me.txtDesc.Text = ""
                Me.cboOffice.SelectedValue = -1

                Me.gbxBrowse.Enabled = True
                Me.gbxDetail.Enabled = False
                ssp.Items("Mode").Text = "BROWSE MODE"
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        frmLocation_Load(Nothing, Nothing)
    End Sub

    Private Sub txtDesc_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDesc.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtContactPerson_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtContactPerson.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtPhone_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPhone.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
            e.Handled = True
        End If
    End Sub


    Private Sub txtFax_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFax.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 47 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
            e.Handled = True
        End If
    End Sub


    Private Sub txtEmail_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtEmail.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtAdd_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtAdd.KeyPress
        If Microsoft.VisualBasic.Asc(e.KeyChar) < 64 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 90 Then
            If Microsoft.VisualBasic.Asc(e.KeyChar) < 95 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 122 Then
                If Microsoft.VisualBasic.Asc(e.KeyChar) < 46 Or Microsoft.VisualBasic.Asc(e.KeyChar) > 58 Then
                    If Microsoft.VisualBasic.Asc(e.KeyChar) <> 45 And Microsoft.VisualBasic.Asc(e.KeyChar) <> 32 Then
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub


    Private Sub txtFax_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFax.TextChanged

    End Sub
End Class