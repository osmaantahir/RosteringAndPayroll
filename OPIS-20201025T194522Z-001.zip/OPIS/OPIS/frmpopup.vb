﻿Public Class frmpopup

    Private dt As DataTable
    Private str As String
    Public frm As frmSchedule

    Public Sub New(ByVal pdt As DataTable, ByVal lblDisplayMember As String, ByVal lblValueMember As String, ByVal lblPrompt As String, ByRef stemp As String)
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        Me.Label1.Text = lblPrompt
        dt = pdt
        Me.ComboBox1.DataSource = dt
        Me.ComboBox1.DisplayMember = lblDisplayMember
        Me.ComboBox1.ValueMember = lblValueMember
        'frm = Owner
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CType(Owner, frmSchedule).strEmpId = Me.ComboBox1.SelectedValue
        Me.Close()
    End Sub
End Class